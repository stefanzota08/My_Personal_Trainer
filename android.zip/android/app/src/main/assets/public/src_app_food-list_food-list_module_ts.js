"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_food-list_food-list_module_ts"],{

/***/ 7877:
/*!*******************************************************!*\
  !*** ./src/app/food-list/food-list-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FoodListPageRoutingModule": () => (/* binding */ FoodListPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _food_list_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./food-list.page */ 8510);




const routes = [
    {
        path: '',
        component: _food_list_page__WEBPACK_IMPORTED_MODULE_0__.FoodListPage,
    },
];
let FoodListPageRoutingModule = class FoodListPageRoutingModule {
};
FoodListPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], FoodListPageRoutingModule);



/***/ }),

/***/ 5257:
/*!***********************************************!*\
  !*** ./src/app/food-list/food-list.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FoodListPageModule": () => (/* binding */ FoodListPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _food_list_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./food-list-routing.module */ 7877);
/* harmony import */ var _food_list_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./food-list.page */ 8510);
/* harmony import */ var ng2_search_filter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ng2-search-filter */ 9991);








let FoodListPageModule = class FoodListPageModule {
};
FoodListPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _food_list_routing_module__WEBPACK_IMPORTED_MODULE_0__.FoodListPageRoutingModule,
            ng2_search_filter__WEBPACK_IMPORTED_MODULE_2__.Ng2SearchPipeModule,
        ],
        declarations: [_food_list_page__WEBPACK_IMPORTED_MODULE_1__.FoodListPage],
    })
], FoodListPageModule);



/***/ }),

/***/ 8510:
/*!*********************************************!*\
  !*** ./src/app/food-list/food-list.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FoodListPage": () => (/* binding */ FoodListPage)
/* harmony export */ });
/* harmony import */ var D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _food_list_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./food-list.page.html?ngResource */ 1391);
/* harmony import */ var _food_list_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./food-list.page.scss?ngResource */ 1375);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_food_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/food.service */ 9785);







let FoodListPage = class FoodListPage {
  constructor(loadingController, alertController, foodService) {
    this.loadingController = loadingController;
    this.alertController = alertController;
    this.foodService = foodService;
    this.searchKeyword = null;
    this.foodList = null;
    this.cerealFlour = null;
  }

  ngOnInit() {
    this.getFoodList();
  }

  getFoodList() {
    var _this = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const loading = yield _this.loadingController.create({
        showBackdrop: false,
        cssClass: 'custom-loading'
      });
      yield loading.present();
      _this.foodList = yield _this.foodService.getFoodList();
      yield loading.dismiss();
    })();
  }

  addMeal(item) {
    var _this2 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let itemValues = {
        kcal: parseFloat(item.kcal) * (item.inputData / 100),
        carbs: parseFloat(item.carbs) * (item.inputData / 100),
        protein: parseFloat(item.protein) * (item.inputData / 100),
        fats: parseFloat(item.fats) * (item.inputData / 100)
      };
      const loading = yield _this2.loadingController.create({
        showBackdrop: false,
        cssClass: 'custom-loading'
      });
      yield loading.present();
      const kcalLeft = yield _this2.foodService.addMeal(itemValues);
      yield loading.dismiss();

      if (kcalLeft === true) {
        _this2.successAlert();
      } else {
        _this2.errorAlert(kcalLeft);
      }
    })();
  }

  enterQuantityAlert(item) {
    var _this3 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this3.alertController.create({
        header: item.name,
        message: 'Enter quantity',
        buttons: [{
          text: 'Add meal',
          role: 'confirm',
          handler: inputData => _this3.addMeal({ ...item,
            inputData: parseInt(inputData[0])
          })
        }],
        inputs: [{
          type: 'number',
          placeholder: 'e.g 120g',
          min: 1,
          max: 9999
        }],
        cssClass: 'alert-input',
        animated: true
      });
      yield alert.present();
    })();
  }

  successAlert() {
    var _this4 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this4.alertController.create({
        message: 'Successfully added item',
        cssClass: 'alert-input',
        animated: true
      });
      yield alert.present();
    })();
  }

  errorAlert(error) {
    var _this5 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this5.alertController.create({
        message: error,
        cssClass: 'alert-input',
        animated: true
      });
      yield alert.present();
    })();
  }

};

FoodListPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.LoadingController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AlertController
}, {
  type: _services_food_service__WEBPACK_IMPORTED_MODULE_3__.FoodService
}];

FoodListPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
  selector: 'app-food-list',
  template: _food_list_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_food_list_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], FoodListPage);


/***/ }),

/***/ 1375:
/*!**********************************************************!*\
  !*** ./src/app/food-list/food-list.page.scss?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "ion-content {\n  --ion-background-color: #005b74;\n  --offset-bottom: 0px !important;\n}\n\nion-card {\n  --background: #fff !important;\n  border-radius: 0.8rem !important;\n}\n\n.sc-ion-searchbar-md-h {\n  --background: #fff !important;\n  --border-radius: 0.8rem !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvb2QtbGlzdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSwrQkFBQTtFQUNBLCtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSw2QkFBQTtFQUNBLGdDQUFBO0FBQ0Y7O0FBRUE7RUFDRSw2QkFBQTtFQUNBLGtDQUFBO0FBQ0YiLCJmaWxlIjoiZm9vZC1saXN0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcclxuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAjMDA1Yjc0O1xyXG4gIC0tb2Zmc2V0LWJvdHRvbTogMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1jYXJkIHtcclxuICAtLWJhY2tncm91bmQ6ICNmZmYgIWltcG9ydGFudDtcclxuICBib3JkZXItcmFkaXVzOiAwLjhyZW0gIWltcG9ydGFudDtcclxufVxyXG5cclxuLnNjLWlvbi1zZWFyY2hiYXItbWQtaCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjZmZmICFpbXBvcnRhbnQ7XHJcbiAgLS1ib3JkZXItcmFkaXVzOiAwLjhyZW0gIWltcG9ydGFudDtcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 1391:
/*!**********************************************************!*\
  !*** ./src/app/food-list/food-list.page.html?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "<ion-content [fullscreen]=\"true\">\n  <ion-searchbar\n    placeholder=\"Try 'Oatmeal'\"\n    [(ngModel)]=\"searchKeyword\"\n    showCancelButton=\"focus\"\n    animated\n  ></ion-searchbar>\n\n  <div style=\"height: 100px !important\">\n    <ion-list>\n      <ng-container *ngFor=\"let item of foodList | filter:searchKeyword\">\n        <ion-card (click)=\"enterQuantityAlert(item)\">\n          <ion-card-header>\n            <ion-card-title>{{ item.name }}</ion-card-title>\n          </ion-card-header>\n          <ion-card-content>{{ item.kcal + ' kcal/100g' }}</ion-card-content>\n        </ion-card>\n      </ng-container>\n    </ion-list>\n  </div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_food-list_food-list_module_ts.js.map