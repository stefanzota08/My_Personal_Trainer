"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_full-workout-flow_full-workout-flow_module_ts-src_app_services_user-data_service_ts"],{

/***/ 5130:
/*!***********************************************************************!*\
  !*** ./src/app/full-workout-flow/full-workout-flow-routing.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FullWorkoutFlowPageRoutingModule": () => (/* binding */ FullWorkoutFlowPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _full_workout_flow_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./full-workout-flow.page */ 197);




const routes = [
    {
        path: '',
        component: _full_workout_flow_page__WEBPACK_IMPORTED_MODULE_0__.FullWorkoutFlowPage
    }
];
let FullWorkoutFlowPageRoutingModule = class FullWorkoutFlowPageRoutingModule {
};
FullWorkoutFlowPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], FullWorkoutFlowPageRoutingModule);



/***/ }),

/***/ 7352:
/*!***************************************************************!*\
  !*** ./src/app/full-workout-flow/full-workout-flow.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FullWorkoutFlowPageModule": () => (/* binding */ FullWorkoutFlowPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _full_workout_flow_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./full-workout-flow-routing.module */ 5130);
/* harmony import */ var _full_workout_flow_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./full-workout-flow.page */ 197);
/* harmony import */ var angular_svg_round_progressbar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! angular-svg-round-progressbar */ 8841);








let FullWorkoutFlowPageModule = class FullWorkoutFlowPageModule {
};
FullWorkoutFlowPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _full_workout_flow_routing_module__WEBPACK_IMPORTED_MODULE_0__.FullWorkoutFlowPageRoutingModule,
            angular_svg_round_progressbar__WEBPACK_IMPORTED_MODULE_7__.RoundProgressModule,
        ],
        declarations: [_full_workout_flow_page__WEBPACK_IMPORTED_MODULE_1__.FullWorkoutFlowPage],
    })
], FullWorkoutFlowPageModule);



/***/ }),

/***/ 197:
/*!*************************************************************!*\
  !*** ./src/app/full-workout-flow/full-workout-flow.page.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FullWorkoutFlowPage": () => (/* binding */ FullWorkoutFlowPage)
/* harmony export */ });
/* harmony import */ var D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _full_workout_flow_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./full-workout-flow.page.html?ngResource */ 8295);
/* harmony import */ var _full_workout_flow_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./full-workout-flow.page.scss?ngResource */ 5293);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_workout_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/workout-data.service */ 7026);
/* harmony import */ var _services_workout_state_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/workout-state.service */ 674);
/* harmony import */ var _services_user_info_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/user-info.service */ 5360);










let FullWorkoutFlowPage = class FullWorkoutFlowPage {
  constructor(workoutState, workoutDataService, router, alertController, userInfoService) {
    this.workoutState = workoutState;
    this.workoutDataService = workoutDataService;
    this.router = router;
    this.alertController = alertController;
    this.userInfoService = userInfoService;
    this.current = 100;
    this.total = 100;
    this.stroke = 6;
    this.strokeMacro = 6;
    this.radius = 125;
    this.responsive = true;
    this.clockwise = true;
    this.color = '#efefef';
    this.background = 'rgba(255,255,255,.25)';
    this.animation = 'linearEase';
    this.animationDelay = 0;
    this.realCurrent = 0;
    this.duration = null;
    this.isTimerModalOpen = false;
    this.isWorkoutDone = false;
    this.timer = '00:';
    this.timerInterval = null;
    this.timerIntervalFullWorkout = null;
    this.nrOfSecondsFullWorkout = 0;
    this.seconds = null;
    this.todayWorkout = null;
    this.bodyPart = null;
    this.dayIndex = null;
    this.exerciseIndex = 0;
    this.completedExercises = [];
    this.totalWorkoutTime = '';
  }

  ngOnInit() {
    this.workoutState.currentWorkoutData.subscribe(data => {
      this.todayWorkout = data.todayWorkout;
      this.bodyPart = data.bodyPart;
      this.dayIndex = data.dayIndex;
    });
    this.timerIntervalFullWorkout = setInterval(() => {
      this.nrOfSecondsFullWorkout += 1;
    }, 1000);
    this.openTimerModal(5000);
  }

  getOverlayStyle(textSize) {
    const transform = 'translateY(-50%) ' + 'translateX(-50%)';
    return {
      top: '50%',
      bottom: 'auto',
      left: '50%',
      transform,
      fontSize: textSize + 'px'
    };
  }

  openTimerModal(duration) {
    this.duration = duration;
    this.isTimerModalOpen = true;
    this.updateTimerUI();
  }

  closeTimerModal() {
    this.isTimerModalOpen = false;
    clearInterval(this.timerInterval);
    console.log(this.todayWorkout, this.bodyPart);
  }

  updateTimerUI() {
    this.timer = '00:';
    this.seconds = this.duration / 1000; // nr de secunde

    let initialTimer = this.timer; // timer-ul gol (00:__)

    this.timer += this.seconds >= 10 ? this.seconds.toString() : '0' + this.seconds.toString(); // timer-ul initial (00:05) daca avem 5000 duration sau (00:30) daca avem 30000 duration

    this.timerInterval = setInterval(() => {
      this.seconds -= 1;

      if (this.seconds >= 10) {
        this.timer = initialTimer + this.seconds.toString();
      } else {
        this.timer = initialTimer + '0' + this.seconds.toString();
      }

      if (this.seconds <= 0) {
        // daca am ajuns la secunda 0 inchidem modalul si intervalul
        clearInterval(this.timerInterval);
        this.closeTimerModal();
      }
    }, 1000);
  }

  loadNextExercise() {
    this.completedExercises.push(this.todayWorkout[this.exerciseIndex]);

    if (this.exerciseIndex !== this.todayWorkout.length - 1) {
      this.openTimerModal(30000);
      this.exerciseIndex += 1;
    } else {
      this.endWorkout();
    }
  }

  endWorkout() {
    this.isWorkoutDone = true;
    clearInterval(this.timerIntervalFullWorkout);

    if (this.nrOfSecondsFullWorkout < 10) {
      this.totalWorkoutTime = '00:0' + this.nrOfSecondsFullWorkout.toString();
    } else if (this.nrOfSecondsFullWorkout < 60) {
      this.totalWorkoutTime = '00:' + this.nrOfSecondsFullWorkout.toString();
    } else {
      let minutes = Math.floor(this.nrOfSecondsFullWorkout / 60);
      let seconds = this.nrOfSecondsFullWorkout % 60;
      this.totalWorkoutTime = (minutes < 10 ? '0' + minutes.toString() : minutes.toString()) + ':' + (seconds < 10 ? '0' + seconds.toString() : seconds.toString());
    }

    let workoutInformation = {
      bodyPart: this.bodyPart,
      time: this.totalWorkoutTime,
      exercisesNr: this.completedExercises.length
    };
    this.workoutDataService.addWorkout(workoutInformation);
    this.workoutDataService.setDayAsCompleted(this.dayIndex, this.bodyPart);
  }

  skipExercise() {
    if (this.exerciseIndex !== this.todayWorkout.length - 1) {
      this.exerciseIndex += 1;
    } else {
      this.endWorkout();
    }
  }

  previousExercise() {
    if (this.exerciseIndex > 0) {
      this.exerciseIndex -= 1;
    }
  }

  navigateToHomePage() {
    this.isWorkoutDone = false;
    this.router.navigateByUrl('/tabs/home', {
      replaceUrl: true
    });
  }

  exitWorkout() {
    const rateOfCompletion = this.completedExercises.length / this.todayWorkout.length * 100;
    console.log(rateOfCompletion);
    this.router.navigateByUrl('/tabs/home', {
      replaceUrl: true
    });
  }

  openUpdateInfoModal() {
    var _this = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this.alertController.create({
        header: 'Info',
        message: 'Weight update',
        buttons: [{
          text: 'Cancel',
          role: 'cancel',
          handler: () => {}
        }, {
          text: 'OK',
          role: 'confirm',
          handler: inputData => {
            _this.updateInfo(inputData);
          }
        }],
        inputs: [{
          type: 'number',
          placeholder: 'Your current weight',
          label: 'Weight',
          min: 1,
          max: 9999
        }]
      });
      yield alert.present();
    })();
  }

  updateInfo(inputData) {
    console.log(inputData[0]);

    if (inputData[0]) {
      this.userInfoService.updateUserInfo({
        weight: Number(inputData[0])
      });
      this.navigateToHomePage();
    }
  }

};

FullWorkoutFlowPage.ctorParameters = () => [{
  type: _services_workout_state_service__WEBPACK_IMPORTED_MODULE_4__.WorkoutStateService
}, {
  type: _services_workout_data_service__WEBPACK_IMPORTED_MODULE_3__.WorkoutDataService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController
}, {
  type: _services_user_info_service__WEBPACK_IMPORTED_MODULE_5__.UserInfoService
}];

FullWorkoutFlowPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-full-workout-flow',
  template: _full_workout_flow_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_full_workout_flow_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], FullWorkoutFlowPage);


/***/ }),

/***/ 5944:
/*!***********************************************!*\
  !*** ./src/app/services/user-data.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserDataService": () => (/* binding */ UserDataService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 4505);



let UserDataService = class UserDataService {
    constructor() {
        this.userData = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject({
            firstName: null,
            lastName: null,
            email: null,
            genderIsFemale: null,
            heightInCm: null,
            heightInInches: null,
            weight: null,
            age: null,
            goal: null,
            activeLevel: null,
            fatPercentage: null,
            neckCircumference: null,
            waistCircumference: null,
            hipCircumference: null,
            BMR: null,
            totalKcal: null,
            totalCarbs: null,
            totalProtein: null,
            totalFats: null,
            leanBodyMass: null,
        });
        this.currentUserData = this.userData.asObservable();
    }
    updateUserData(data) {
        this.userData.next({ ...this.userData.value, ...data });
    }
    log10(val) {
        return Math.log(val) / Math.log(10);
    }
    calculateKcalAndMacro(data) {
        console.log(data);
        let fatPercentage = null;
        let leanBodyMass = null;
        let BMR = null;
        let totalKcal = null;
        let totalProtein = null;
        let totalFats = null;
        let totalCarbs = null;
        // If we have the fat percentage
        if (data.fatPercentage) {
            fatPercentage = data.fatPercentage;
            leanBodyMass = (data.weight * (100 - data.fatPercentage)) / 100;
            BMR = 370 + 21.6 * leanBodyMass;
        }
        // if we calculated our fat percentage through measurements
        else if ((data.genderIsFemale && data.hipCircumference) ||
            (!data.genderIsFemale && data.waistCircumference)) {
            // we calculate the fat percentage using neck/waist/hip measurements
            fatPercentage = data.genderIsFemale
                ? 163.205 *
                    this.log10(data.waistCircumference +
                        data.hipCircumference -
                        data.neckCircumference) -
                    97.684 * this.log10(data.heightInInches) -
                    78.387
                : 86.01 * this.log10(data.waistCircumference - data.neckCircumference) -
                    70.041 * this.log10(data.heightInInches) +
                    36.76;
            // we aprox the result to 1 decimal
            fatPercentage = Math.round(fatPercentage * 10) / 10;
            // we calculate the lean mass
            leanBodyMass = (data.weight * (100 - fatPercentage)) / 100;
            // calculate the BMR using FIRST formula
            BMR = 370 + 21.6 * leanBodyMass;
        }
        // if we don't have the fat percentage set up
        else {
            // we calculate the BMR using SECOND formula
            BMR = 10 * data.weight + 6.25 * data.heightInCm - 5 * data.age + 5;
            if (data.genderIsFemale) {
                BMR -= 166; // we substract 166 kcal if user is a woman
            }
        }
        // multiply BMR by activity level
        totalKcal = Math.round(BMR * data.activeLevel);
        // substract or add calories regarding the goal
        switch (data.goal) {
            case -1:
                totalKcal -= 300;
                break;
            case 1:
                totalKcal += 300;
                break;
        }
        //  fats = 30% of total calories
        totalFats = Math.round((0.3 * totalKcal) / 9);
        if (data.age < 18) {
            totalProtein = Math.round(data.weight);
        }
        else if (18 <= data.age && data.age < 35) {
            totalProtein = Math.round(data.weight * 1.4);
        }
        else if (35 <= data.age && data.age < 45) {
            totalProtein = Math.round(data.weight * 1.5);
        }
        else {
            totalProtein = Math.round(data.weight * 1.6);
        }
        totalCarbs = Math.round((totalKcal - totalFats * 9 - totalProtein * 4) / 4);
        const result = {
            ...data,
            fatPercentage,
            leanBodyMass,
            BMR,
            totalKcal,
            totalProtein,
            totalCarbs,
            totalFats,
        };
        return result;
    }
};
UserDataService.ctorParameters = () => [];
UserDataService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root',
    })
], UserDataService);



/***/ }),

/***/ 5293:
/*!**************************************************************************!*\
  !*** ./src/app/full-workout-flow/full-workout-flow.page.scss?ngResource ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = ".modal-title {\n  text-align: center;\n  color: #efefef;\n  font-family: Roboto-Medium;\n  font-size: 25px;\n}\n\n.current {\n  position: absolute;\n  line-height: 1;\n  text-align: center;\n  color: #efefef;\n  z-index: 2;\n  font-family: Roboto-Medium;\n}\n\n.circle-wrapper {\n  padding: 0 4rem;\n  margin-bottom: 2rem;\n}\n\n.add-rest,\n.skip-rest {\n  color: #efefef;\n  font-family: Roboto-Medium;\n  font-size: 25px;\n}\n\n.add-rest {\n  text-align: end;\n}\n\n.skip-rest {\n  text-align: start;\n}\n\n.next-exercise {\n  height: 7rem;\n  width: 100%;\n  border-radius: 1rem 1rem 0rem 0rem;\n  background-color: #fff;\n  position: fixed;\n  bottom: 0;\n}\n\n.next-exercise .next-gif-image {\n  height: 7rem;\n}\n\n.next-exercise .next-info {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n}\n\n.next-exercise .next-exercise-name {\n  font-family: \"Roboto-Bold\";\n  font-size: 16px;\n  color: #444444;\n  text-transform: uppercase;\n  margin-left: 4rem;\n}\n\n.next-exercise .next-exercise-reps {\n  font-family: \"Roboto-Bold\";\n  font-size: 16px;\n  text-transform: uppercase;\n  color: rgba(0, 0, 0, 0.5);\n  margin-left: 4rem;\n  margin-top: -0.5rem;\n}\n\nion-modal ion-content {\n  --background: #005b74;\n}\n\nion-card {\n  --background-color: #fff;\n}\n\n.ion-no-margin {\n  margin: 0px !important;\n}\n\n.split-bar {\n  margin-left: 50%;\n  width: 0px;\n  height: 3rem;\n  border-left: 1px solid #efefef;\n  align-items: center;\n}\n\n.timer-ui {\n  margin-top: calc((100% - 7rem) / 2);\n}\n\n.gif-image {\n  height: 50vh;\n  object-fit: cover;\n  border-bottom: 2px solid #005b74;\n}\n\n.exercise-title {\n  text-align: center;\n  font-size: 24px;\n  font-family: Roboto-Bold;\n  color: #444;\n  text-transform: uppercase;\n}\n\n.exercise-reps {\n  text-align: center;\n  font-size: 36px;\n  font-family: Roboto-Bold;\n  color: rgba(0, 0, 0, 0.4);\n  text-transform: uppercase;\n}\n\n.done-button {\n  padding: 0 3rem;\n  height: 3rem;\n  font-size: 18px;\n  --border-radius: 1rem;\n  margin-bottom: 1rem;\n}\n\n.split-bar-2 {\n  margin-left: 50%;\n  width: 0px;\n  height: 3rem;\n  border-left: 1px solid rgba(0, 0, 0, 0.2);\n  align-items: center;\n}\n\n.bottom-buttons {\n  position: fixed;\n  width: 100%;\n  height: 5rem;\n  bottom: 0;\n}\n\n.text-and-buttons {\n  margin-top: calc((50vh - 5rem) / 2);\n  transform: translate(0%, -50%);\n}\n\n.workout-done-modal {\n  color: white;\n}\n\n.workout-done-modal .workout-done-header {\n  margin-top: 7rem;\n  text-align: center;\n  color: #efefef;\n  font-family: Roboto-Bold;\n  font-size: 40px;\n  text-transform: uppercase;\n}\n\n.workout-done-modal .workout-done-header {\n  text-align: center;\n  color: #efefef;\n  font-family: Roboto-Bold;\n  font-size: 26px;\n  text-transform: uppercase;\n}\n\n.workout-done-modal .workout-done-subheader {\n  text-align: center;\n  color: #efefef;\n  font-family: Roboto-Bold;\n  font-size: 18px;\n  text-transform: uppercase;\n}\n\n.workout-done-modal .completed-exercises,\n.workout-done-modal .completed-exercises-value,\n.workout-done-modal .total-time,\n.workout-done-modal .total-time-value {\n  text-align: center;\n  color: #005b74;\n  font-family: Roboto-Bold;\n  text-transform: initial;\n}\n\n.workout-done-modal .completed-exercises-value {\n  font-size: 35px;\n}\n\n.workout-done-modal .total-time-value {\n  font-size: 50px;\n}\n\n.workout-done-modal .completed-exercises {\n  font-size: 25px;\n}\n\n.workout-done-modal .total-time {\n  font-size: 25px;\n}\n\n.back-icon {\n  font-size: 40px;\n  margin-left: 1rem;\n  margin-top: 1rem;\n  position: fixed;\n  color: #444;\n}\n\n.footer-card {\n  --background-color: #fff;\n  margin: 0;\n  position: fixed;\n  width: 100%;\n  bottom: 0;\n  border-radius: 1rem 1rem 0rem 0rem;\n}\n\n.footer-card .footer-title {\n  text-align: center;\n  color: #454545;\n  font-family: Roboto-Bold;\n  font-size: 16px;\n  text-transform: initial;\n}\n\n.footer-card .footer-button {\n  height: 3rem;\n  font-family: Roboto-Regular;\n  font-size: 16px;\n  --border-radius: 1rem;\n  margin: 0 2rem;\n}\n\n.footer-card .no-thanks-button {\n  text-align: center;\n  color: #005b74;\n  font-family: Roboto-Regular;\n  font-size: 14px;\n  text-transform: initial;\n  z-index: 5;\n}\n\n.middle-card {\n  margin-top: calc((100vh - 54px - 7rem - 180px) / 2);\n  transform: translate(0%, -50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZ1bGwtd29ya291dC1mbG93LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLDBCQUFBO0VBQ0EsZUFBQTtBQUNGOztBQUVBO0VBQ0Usa0JBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EsVUFBQTtFQUNBLDBCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0VBQ0EsbUJBQUE7QUFDRjs7QUFFQTs7RUFFRSxjQUFBO0VBQ0EsMEJBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0FBQ0Y7O0FBRUE7RUFDRSxpQkFBQTtBQUNGOztBQUVBO0VBQ0UsWUFBQTtFQUNBLFdBQUE7RUFDQSxrQ0FBQTtFQUNBLHNCQUFBO0VBQ0EsZUFBQTtFQUNBLFNBQUE7QUFDRjs7QUFDRTtFQUNFLFlBQUE7QUFDSjs7QUFFRTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0FBQUo7O0FBR0U7RUFDRSwwQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EseUJBQUE7RUFDQSxpQkFBQTtBQURKOztBQUlFO0VBQ0UsMEJBQUE7RUFDQSxlQUFBO0VBQ0EseUJBQUE7RUFDQSx5QkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUFGSjs7QUFPRTtFQUNFLHFCQUFBO0FBSko7O0FBUUE7RUFDRSx3QkFBQTtBQUxGOztBQVFBO0VBQ0Usc0JBQUE7QUFMRjs7QUFRQTtFQUNFLGdCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0FBTEY7O0FBUUE7RUFDRSxtQ0FBQTtBQUxGOztBQVFBO0VBQ0UsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0NBQUE7QUFMRjs7QUFRQTtFQUNFLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLHdCQUFBO0VBQ0EsV0FBQTtFQUNBLHlCQUFBO0FBTEY7O0FBUUE7RUFDRSxrQkFBQTtFQUNBLGVBQUE7RUFDQSx3QkFBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7QUFMRjs7QUFRQTtFQUNFLGVBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7QUFMRjs7QUFRQTtFQUNFLGdCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSx5Q0FBQTtFQUNBLG1CQUFBO0FBTEY7O0FBUUE7RUFDRSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxTQUFBO0FBTEY7O0FBUUE7RUFDRSxtQ0FBQTtFQUNBLDhCQUFBO0FBTEY7O0FBUUE7RUFDRSxZQUFBO0FBTEY7O0FBTUU7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLHdCQUFBO0VBQ0EsZUFBQTtFQUNBLHlCQUFBO0FBSko7O0FBT0U7RUFDRSxrQkFBQTtFQUNBLGNBQUE7RUFDQSx3QkFBQTtFQUNBLGVBQUE7RUFDQSx5QkFBQTtBQUxKOztBQVFFO0VBQ0Usa0JBQUE7RUFDQSxjQUFBO0VBQ0Esd0JBQUE7RUFDQSxlQUFBO0VBQ0EseUJBQUE7QUFOSjs7QUFTRTs7OztFQUlFLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLHdCQUFBO0VBQ0EsdUJBQUE7QUFQSjs7QUFVRTtFQUNFLGVBQUE7QUFSSjs7QUFXRTtFQUNFLGVBQUE7QUFUSjs7QUFZRTtFQUNFLGVBQUE7QUFWSjs7QUFhRTtFQUNFLGVBQUE7QUFYSjs7QUFlQTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7QUFaRjs7QUFlQTtFQUNFLHdCQUFBO0VBQ0EsU0FBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLGtDQUFBO0FBWkY7O0FBY0U7RUFDRSxrQkFBQTtFQUNBLGNBQUE7RUFDQSx3QkFBQTtFQUNBLGVBQUE7RUFDQSx1QkFBQTtBQVpKOztBQWVFO0VBQ0UsWUFBQTtFQUNBLDJCQUFBO0VBQ0EsZUFBQTtFQUNBLHFCQUFBO0VBQ0EsY0FBQTtBQWJKOztBQWdCRTtFQUNFLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLDJCQUFBO0VBQ0EsZUFBQTtFQUNBLHVCQUFBO0VBQ0EsVUFBQTtBQWRKOztBQWtCQTtFQUNFLG1EQUFBO0VBQ0EsOEJBQUE7QUFmRiIsImZpbGUiOiJmdWxsLXdvcmtvdXQtZmxvdy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubW9kYWwtdGl0bGUge1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBjb2xvcjogI2VmZWZlZjtcclxuICBmb250LWZhbWlseTogUm9ib3RvLU1lZGl1bTtcclxuICBmb250LXNpemU6IDI1cHg7XHJcbn1cclxuXHJcbi5jdXJyZW50IHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgbGluZS1oZWlnaHQ6IDE7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGNvbG9yOiAjZWZlZmVmO1xyXG4gIHotaW5kZXg6IDI7XHJcbiAgZm9udC1mYW1pbHk6IFJvYm90by1NZWRpdW07XHJcbn1cclxuXHJcbi5jaXJjbGUtd3JhcHBlciB7XHJcbiAgcGFkZGluZzogMCA0cmVtO1xyXG4gIG1hcmdpbi1ib3R0b206IDJyZW07XHJcbn1cclxuXHJcbi5hZGQtcmVzdCxcclxuLnNraXAtcmVzdCB7XHJcbiAgY29sb3I6ICNlZmVmZWY7XHJcbiAgZm9udC1mYW1pbHk6IFJvYm90by1NZWRpdW07XHJcbiAgZm9udC1zaXplOiAyNXB4O1xyXG59XHJcblxyXG4uYWRkLXJlc3Qge1xyXG4gIHRleHQtYWxpZ246IGVuZDtcclxufVxyXG5cclxuLnNraXAtcmVzdCB7XHJcbiAgdGV4dC1hbGlnbjogc3RhcnQ7XHJcbn1cclxuXHJcbi5uZXh0LWV4ZXJjaXNlIHtcclxuICBoZWlnaHQ6IDdyZW07XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgYm9yZGVyLXJhZGl1czogMXJlbSAxcmVtIDByZW0gMHJlbTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICBib3R0b206IDA7XHJcblxyXG4gICYgLm5leHQtZ2lmLWltYWdlIHtcclxuICAgIGhlaWdodDogN3JlbTtcclxuICB9XHJcblxyXG4gICYgLm5leHQtaW5mbyB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIH1cclxuXHJcbiAgJiAubmV4dC1leGVyY2lzZS1uYW1lIHtcclxuICAgIGZvbnQtZmFtaWx5OiBcIlJvYm90by1Cb2xkXCI7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBjb2xvcjogIzQ0NDQ0NDtcclxuICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgICBtYXJnaW4tbGVmdDogNHJlbTtcclxuICB9XHJcblxyXG4gICYgLm5leHQtZXhlcmNpc2UtcmVwcyB7XHJcbiAgICBmb250LWZhbWlseTogXCJSb2JvdG8tQm9sZFwiO1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNSk7XHJcbiAgICBtYXJnaW4tbGVmdDogNHJlbTtcclxuICAgIG1hcmdpbi10b3A6IC0wLjVyZW07XHJcbiAgfVxyXG59XHJcblxyXG5pb24tbW9kYWwge1xyXG4gICYgaW9uLWNvbnRlbnQge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjMDA1Yjc0O1xyXG4gIH1cclxufVxyXG5cclxuaW9uLWNhcmQge1xyXG4gIC0tYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcclxufVxyXG5cclxuLmlvbi1uby1tYXJnaW4ge1xyXG4gIG1hcmdpbjogMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5zcGxpdC1iYXIge1xyXG4gIG1hcmdpbi1sZWZ0OiA1MCU7XHJcbiAgd2lkdGg6IDBweDtcclxuICBoZWlnaHQ6IDNyZW07XHJcbiAgYm9yZGVyLWxlZnQ6IDFweCBzb2xpZCAjZWZlZmVmO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcbi50aW1lci11aSB7XHJcbiAgbWFyZ2luLXRvcDogY2FsYygoMTAwJSAtIDdyZW0pIC8gMik7XHJcbn1cclxuXHJcbi5naWYtaW1hZ2Uge1xyXG4gIGhlaWdodDogNTB2aDtcclxuICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICBib3JkZXItYm90dG9tOiAycHggc29saWQgIzAwNWI3NDtcclxufVxyXG5cclxuLmV4ZXJjaXNlLXRpdGxlIHtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgZm9udC1zaXplOiAyNHB4O1xyXG4gIGZvbnQtZmFtaWx5OiBSb2JvdG8tQm9sZDtcclxuICBjb2xvcjogIzQ0NDtcclxuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG59XHJcblxyXG4uZXhlcmNpc2UtcmVwcyB7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtc2l6ZTogMzZweDtcclxuICBmb250LWZhbWlseTogUm9ib3RvLUJvbGQ7XHJcbiAgY29sb3I6IHJnYmEoJGNvbG9yOiAjMDAwMDAwLCAkYWxwaGE6IDAuNCk7XHJcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxufVxyXG5cclxuLmRvbmUtYnV0dG9uIHtcclxuICBwYWRkaW5nOiAwIDNyZW07XHJcbiAgaGVpZ2h0OiAzcmVtO1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxuICAtLWJvcmRlci1yYWRpdXM6IDFyZW07XHJcbiAgbWFyZ2luLWJvdHRvbTogMXJlbTtcclxufVxyXG5cclxuLnNwbGl0LWJhci0yIHtcclxuICBtYXJnaW4tbGVmdDogNTAlO1xyXG4gIHdpZHRoOiAwcHg7XHJcbiAgaGVpZ2h0OiAzcmVtO1xyXG4gIGJvcmRlci1sZWZ0OiAxcHggc29saWQgcmdiYSgkY29sb3I6ICMwMDAwMDAsICRhbHBoYTogMC4yKTtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4uYm90dG9tLWJ1dHRvbnMge1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDVyZW07XHJcbiAgYm90dG9tOiAwO1xyXG59XHJcblxyXG4udGV4dC1hbmQtYnV0dG9ucyB7XHJcbiAgbWFyZ2luLXRvcDogY2FsYygoNTB2aCAtIDVyZW0pIC8gMik7XHJcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoMCUsIC01MCUpO1xyXG59XHJcblxyXG4ud29ya291dC1kb25lLW1vZGFsIHtcclxuICBjb2xvcjogd2hpdGU7XHJcbiAgJiAud29ya291dC1kb25lLWhlYWRlciB7XHJcbiAgICBtYXJnaW4tdG9wOiA3cmVtO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6ICNlZmVmZWY7XHJcbiAgICBmb250LWZhbWlseTogUm9ib3RvLUJvbGQ7XHJcbiAgICBmb250LXNpemU6IDQwcHg7XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gIH1cclxuXHJcbiAgJiAud29ya291dC1kb25lLWhlYWRlciB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBjb2xvcjogI2VmZWZlZjtcclxuICAgIGZvbnQtZmFtaWx5OiBSb2JvdG8tQm9sZDtcclxuICAgIGZvbnQtc2l6ZTogMjZweDtcclxuICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgfVxyXG5cclxuICAmIC53b3Jrb3V0LWRvbmUtc3ViaGVhZGVyIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiAjZWZlZmVmO1xyXG4gICAgZm9udC1mYW1pbHk6IFJvYm90by1Cb2xkO1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICB9XHJcblxyXG4gICYgLmNvbXBsZXRlZC1leGVyY2lzZXMsXHJcbiAgLmNvbXBsZXRlZC1leGVyY2lzZXMtdmFsdWUsXHJcbiAgLnRvdGFsLXRpbWUsXHJcbiAgLnRvdGFsLXRpbWUtdmFsdWUge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6ICMwMDViNzQ7XHJcbiAgICBmb250LWZhbWlseTogUm9ib3RvLUJvbGQ7XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogaW5pdGlhbDtcclxuICB9XHJcblxyXG4gICYgLmNvbXBsZXRlZC1leGVyY2lzZXMtdmFsdWUge1xyXG4gICAgZm9udC1zaXplOiAzNXB4O1xyXG4gIH1cclxuXHJcbiAgJiAudG90YWwtdGltZS12YWx1ZSB7XHJcbiAgICBmb250LXNpemU6IDUwcHg7XHJcbiAgfVxyXG5cclxuICAmIC5jb21wbGV0ZWQtZXhlcmNpc2VzIHtcclxuICAgIGZvbnQtc2l6ZTogMjVweDtcclxuICB9XHJcblxyXG4gICYgLnRvdGFsLXRpbWUge1xyXG4gICAgZm9udC1zaXplOiAyNXB4O1xyXG4gIH1cclxufVxyXG5cclxuLmJhY2staWNvbiB7XHJcbiAgZm9udC1zaXplOiA0MHB4O1xyXG4gIG1hcmdpbi1sZWZ0OiAxcmVtO1xyXG4gIG1hcmdpbi10b3A6IDFyZW07XHJcbiAgcG9zaXRpb246IGZpeGVkO1xyXG4gIGNvbG9yOiAjNDQ0O1xyXG59XHJcblxyXG4uZm9vdGVyLWNhcmQge1xyXG4gIC0tYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcclxuICBtYXJnaW46IDA7XHJcbiAgcG9zaXRpb246IGZpeGVkO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGJvdHRvbTogMDtcclxuICBib3JkZXItcmFkaXVzOiAxcmVtIDFyZW0gMHJlbSAwcmVtO1xyXG5cclxuICAmIC5mb290ZXItdGl0bGUge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6ICM0NTQ1NDU7XHJcbiAgICBmb250LWZhbWlseTogUm9ib3RvLUJvbGQ7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogaW5pdGlhbDtcclxuICB9XHJcblxyXG4gICYgLmZvb3Rlci1idXR0b24ge1xyXG4gICAgaGVpZ2h0OiAzcmVtO1xyXG4gICAgZm9udC1mYW1pbHk6IFJvYm90by1SZWd1bGFyO1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgLS1ib3JkZXItcmFkaXVzOiAxcmVtO1xyXG4gICAgbWFyZ2luOiAwIDJyZW07XHJcbiAgfVxyXG5cclxuICAmIC5uby10aGFua3MtYnV0dG9uIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiAjMDA1Yjc0O1xyXG4gICAgZm9udC1mYW1pbHk6IFJvYm90by1SZWd1bGFyO1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IGluaXRpYWw7XHJcbiAgICB6LWluZGV4OiA1O1xyXG4gIH1cclxufVxyXG5cclxuLm1pZGRsZS1jYXJkIHtcclxuICBtYXJnaW4tdG9wOiBjYWxjKCgxMDB2aCAtIDU0cHggLSA3cmVtIC0gMTgwcHgpIC8gMik7XHJcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoMCUsIC01MCUpO1xyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 8295:
/*!**************************************************************************!*\
  !*** ./src/app/full-workout-flow/full-workout-flow.page.html?ngResource ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <!-- <ion-button (click)=\"openTimerModal(30000)\">Open modal</ion-button> -->\n\n  <ion-icon\n    name=\"arrow-back-outline\"\n    class=\"back-icon\"\n    (click)=\"exitWorkout()\"\n  ></ion-icon>\n  <!-- gif wrapper -->\n  <img\n    class=\"gif-image\"\n    [src]=\"'assets/gifs/' + bodyPart + '/' + todayWorkout[exerciseIndex].gif\"\n  />\n\n  <div class=\"text-and-buttons\">\n    <p class=\"exercise-title\">{{todayWorkout[exerciseIndex].name}}</p>\n    <p class=\"exercise-reps\">x{{todayWorkout[exerciseIndex].totalReps}}</p>\n    <ion-button class=\"done-button\" expand=\"block\" (click)=\"loadNextExercise()\"\n      >Done</ion-button\n    >\n  </div>\n\n  <ion-row class=\"bottom-buttons\">\n    <ion-col size=\"5\">\n      <p\n        style=\"\n          text-align: center;\n          font-family: Roboto-Bold;\n          font-size: 18px;\n          color: #444444;\n        \"\n        (click)=\"previousExercise()\"\n      >\n        << Previous\n      </p>\n    </ion-col>\n    <ion-col size=\"2\">\n      <div class=\"split-bar-2\"></div>\n    </ion-col>\n    <ion-col size=\"5\">\n      <p\n        style=\"\n          text-align: center;\n          font-family: Roboto-Bold;\n          font-size: 18px;\n          color: #444444;\n        \"\n        (click)=\"skipExercise()\"\n      >\n        Skip >>\n      </p>\n    </ion-col>\n  </ion-row>\n\n  <!-- rest timer modal -->\n  <ion-modal [isOpen]=\"isTimerModalOpen\" [animated]=\"false\">\n    <ng-template>\n      <ion-content>\n        <div class=\"timer-ui\">\n          <ion-row class=\"modal-title\">\n            <ion-col size=\"12\">\n              <p>REST</p>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"12\" class=\"circle-wrapper\">\n              <div class=\"current\" [ngStyle]=\"getOverlayStyle(55)\">\n                {{ timer }}\n              </div>\n              <round-progress\n                [current]=\"current\"\n                [max]=\"total\"\n                [color]=\"color\"\n                [background]=\"background\"\n                [radius]=\"radius\"\n                [stroke]=\"strokeMacro\"\n                [clockwise]=\"clockwise\"\n                [responsive]=\"responsive\"\n                [duration]=\"duration\"\n                [animation]=\"animation\"\n                [animationDelay]=\"animationDelay\"\n              ></round-progress>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"5\" class=\"ion-no-margin\">\n              <p class=\"add-rest\" (click)=\"addRestSeconds()\">+20s</p>\n            </ion-col>\n            <ion-col size=\"2\" class=\"ion-no-margin\">\n              <p class=\"split-bar\"></p>\n            </ion-col>\n            <ion-col size=\"5\" class=\"ion-no-margin\" style=\"display: flex\">\n              <p class=\"skip-rest\" (click)=\"closeTimerModal()\">Skip</p>\n            </ion-col>\n          </ion-row>\n        </div>\n        <!-- <ion-button (click)=\"closeTimerModal()\">Close Modal</ion-button> -->\n        <div class=\"next-exercise\">\n          <!-- <p style=\"position: absolute\">\n            NEXT:\n            <span\n              >Exercise {{exerciseIndex + 1 + '/' + todayWorkout.length}}</span\n            >\n          </p> -->\n          <div style=\"display: flex\">\n            <img\n              class=\"next-gif-image\"\n              [src]=\"'assets/gifs/' + bodyPart + '/' + todayWorkout[exerciseIndex].gif\"\n            />\n            <div class=\"next-info\">\n              <p class=\"next-exercise-name\">\n                {{todayWorkout[exerciseIndex].name}}\n              </p>\n              <p class=\"next-exercise-reps\">\n                x{{todayWorkout[exerciseIndex].totalReps}}\n              </p>\n            </div>\n          </div>\n        </div>\n      </ion-content>\n    </ng-template>\n  </ion-modal>\n\n  <!-- workout done modal -->\n  <ion-modal [isOpen]=\"isWorkoutDone\" class=\"workout-done-modal\">\n    <ng-template>\n      <ion-content>\n        <p class=\"workout-done-header\">Congratulations</p>\n        <p class=\"workout-done-subheader\">Workout Done</p>\n        <ion-card class=\"middle-card\">\n          <p class=\"completed-exercises\">Comlpeted exercises:</p>\n          <p class=\"completed-exercises-value\">\n            {{completedExercises.length + ' / ' + todayWorkout.length}}\n          </p>\n          <p class=\"total-time\">Total time:</p>\n          <p class=\"total-time-value\">{{totalWorkoutTime}}</p>\n        </ion-card>\n\n        <ion-card class=\"footer-card\">\n          <p class=\"footer-title\">Want to update your info?</p>\n          <ion-button\n            class=\"footer-button\"\n            color=\"primary\"\n            expand=\"block\"\n            (click)=\"openUpdateInfoModal()\"\n            >Update now</ion-button\n          >\n          <p class=\"no-thanks-button\" (click)=\"navigateToHomePage()\">\n            No thanks\n          </p>\n        </ion-card>\n      </ion-content>\n    </ng-template>\n  </ion-modal>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_full-workout-flow_full-workout-flow_module_ts-src_app_services_user-data_service_ts.js.map