"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_starting-views_login_login_module_ts"],{

/***/ 1473:
/*!**************************************************************!*\
  !*** ./src/app/starting-views/login/login-routing.module.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageRoutingModule": () => (/* binding */ LoginPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.page */ 5689);




const routes = [
    {
        path: 'login',
        component: _login_page__WEBPACK_IMPORTED_MODULE_0__.LoginPage,
    },
    {
        path: '',
        redirectTo: '/login',
        pathMatch: 'full',
    },
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ 2311:
/*!******************************************************!*\
  !*** ./src/app/starting-views/login/login.module.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageModule": () => (/* binding */ LoginPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login-routing.module */ 1473);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page */ 5689);







let LoginPageModule = class LoginPageModule {
};
LoginPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _login_routing_module__WEBPACK_IMPORTED_MODULE_0__.LoginPageRoutingModule,
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_1__.LoginPage],
    })
], LoginPageModule);



/***/ }),

/***/ 5689:
/*!****************************************************!*\
  !*** ./src/app/starting-views/login/login.page.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPage": () => (/* binding */ LoginPage)
/* harmony export */ });
/* harmony import */ var D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _login_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page.html?ngResource */ 5479);
/* harmony import */ var _login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./login.page.scss?ngResource */ 3022);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);









let LoginPage = class LoginPage {
  constructor(fb, authService, router, loadingController) {
    this.fb = fb;
    this.authService = authService;
    this.router = router;
    this.loadingController = loadingController;
    this.loginFailed = false;
  }

  get email() {
    return this.loginForm.get('email');
  }

  get password() {
    return this.loginForm.get('password');
  }

  ngOnInit() {
    this.loginForm = this.fb.group({
      email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.email]],
      password: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(6)]]
    });
  }

  login() {
    var _this = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const loading = yield _this.loadingController.create({
        showBackdrop: false,
        cssClass: 'custom-loading'
      });
      yield loading.present();
      const user = yield _this.authService.login(_this.loginForm.value);
      yield loading.dismiss();

      if (user) {
        _this.loginFailed = false;

        _this.router.navigateByUrl('/tabs', {
          replaceUrl: true
        });
      } else {
        _this.loginFailed = true;
      }
    })();
  }

};

LoginPage.ctorParameters = () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder
}, {
  type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController
}];

LoginPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-login',
  template: _login_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], LoginPage);


/***/ }),

/***/ 3022:
/*!*****************************************************************!*\
  !*** ./src/app/starting-views/login/login.page.scss?ngResource ***!
  \*****************************************************************/
/***/ ((module) => {

module.exports = ".login-header {\n  font-family: Teko-Light;\n  font-style: normal;\n  font-weight: 400;\n  font-size: 50px;\n  color: #efefef;\n}\n\n.login-button {\n  height: 3rem;\n  font-family: Roboto-Medium;\n  font-size: 16px;\n  --border-radius: 1rem;\n  margin-top: 15rem;\n}\n\n.go-to-sign-up {\n  font-family: Roboto-Light;\n  color: #828282;\n  font-size: 14px;\n  bottom: 0;\n}\n\n.sign-up-btn {\n  font-family: Roboto-Bold;\n  color: #efefef;\n  font-size: 14px;\n  margin-left: 0.3rem;\n}\n\nion-content {\n  --ion-background-color: #005b74;\n}\n\nion-grid {\n  margin-top: 5rem;\n  padding: 2rem;\n}\n\nion-item {\n  border-bottom: 1px solid #828282 !important;\n}\n\nion-item.ion-invalid.ion-touched {\n  border-bottom: 1px solid red !important;\n}\n\nion-item.item-has-focus {\n  border-bottom: 1px solid #efefef !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHVCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FBQ0Y7O0FBRUE7RUFDRSxZQUFBO0VBQ0EsMEJBQUE7RUFDQSxlQUFBO0VBQ0EscUJBQUE7RUFDQSxpQkFBQTtBQUNGOztBQUVBO0VBQ0UseUJBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLFNBQUE7QUFDRjs7QUFFQTtFQUNFLHdCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtBQUNGOztBQUVBO0VBQ0UsK0JBQUE7QUFDRjs7QUFFQTtFQUNFLGdCQUFBO0VBQ0EsYUFBQTtBQUNGOztBQUVBO0VBQ0UsMkNBQUE7QUFDRjs7QUFBRTtFQUNFLHVDQUFBO0FBRUo7O0FBQUU7RUFDRSwyQ0FBQTtBQUVKIiwiZmlsZSI6ImxvZ2luLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5sb2dpbi1oZWFkZXIge1xyXG4gIGZvbnQtZmFtaWx5OiBUZWtvLUxpZ2h0O1xyXG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICBmb250LXdlaWdodDogNDAwO1xyXG4gIGZvbnQtc2l6ZTogNTBweDtcclxuICBjb2xvcjogI2VmZWZlZjtcclxufVxyXG5cclxuLmxvZ2luLWJ1dHRvbiB7XHJcbiAgaGVpZ2h0OiAzcmVtO1xyXG4gIGZvbnQtZmFtaWx5OiBSb2JvdG8tTWVkaXVtO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICAtLWJvcmRlci1yYWRpdXM6IDFyZW07XHJcbiAgbWFyZ2luLXRvcDogMTVyZW07XHJcbn1cclxuXHJcbi5nby10by1zaWduLXVwIHtcclxuICBmb250LWZhbWlseTogUm9ib3RvLUxpZ2h0O1xyXG4gIGNvbG9yOiAjODI4MjgyO1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxuICBib3R0b206IDA7XHJcbn1cclxuXHJcbi5zaWduLXVwLWJ0biB7XHJcbiAgZm9udC1mYW1pbHk6IFJvYm90by1Cb2xkO1xyXG4gIGNvbG9yOiAjZWZlZmVmO1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxuICBtYXJnaW4tbGVmdDogMC4zcmVtO1xyXG59XHJcblxyXG5pb24tY29udGVudCB7XHJcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogIzAwNWI3NDtcclxufVxyXG5cclxuaW9uLWdyaWQge1xyXG4gIG1hcmdpbi10b3A6IDVyZW07XHJcbiAgcGFkZGluZzogMnJlbTtcclxufVxyXG5cclxuaW9uLWl0ZW0ge1xyXG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjODI4MjgyICFpbXBvcnRhbnQ7XHJcbiAgJi5pb24taW52YWxpZC5pb24tdG91Y2hlZCB7XHJcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgcmVkICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG4gICYuaXRlbS1oYXMtZm9jdXMge1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlZmVmZWYgIWltcG9ydGFudDtcclxuICB9XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 5479:
/*!*****************************************************************!*\
  !*** ./src/app/starting-views/login/login.page.html?ngResource ***!
  \*****************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <ion-grid>\n    <form [formGroup]=\"loginForm\" (ngSubmit)=\"login()\">\n      <ion-row class=\"ion-align-items-center\">\n        <ion-col size=\"12\">\n          <h3 class=\"login-header\">Log in</h3>\n        </ion-col>\n      </ion-row>\n\n      <ion-row style=\"margin-top: 2rem\">\n        <ion-col size=\"12\" class=\"ion-align-items-center\">\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Email</ion-label>\n            <ion-input formControlName=\"email\" class=\"light-text\"></ion-input>\n          </ion-item>\n          <span\n            class=\"input-error\"\n            *ngIf=\"email.dirty && email.touched && email.errors\"\n            >*Invalid email</span\n          >\n        </ion-col>\n      </ion-row>\n\n      <ion-row style=\"margin-top: 1rem\">\n        <ion-col size=\"12\" class=\"ion-align-items-center\">\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Password</ion-label>\n            <ion-input\n              formControlName=\"password\"\n              class=\"light-text\"\n              type=\"password\"\n            ></ion-input>\n          </ion-item>\n          <span\n            class=\"input-error\"\n            *ngIf=\"(password.dirty || password.touched) && password.errors\"\n            >*Password must contain at least 6 characters</span\n          >\n          <span class=\"input-error\" *ngIf=\"loginFailed\"\n            >Wrong email or password</span\n          >\n        </ion-col>\n      </ion-row>\n\n      <ion-row style=\"margin-top: 1.5rem\">\n        <ion-col size=\"12\" class=\"ion-text-center\">\n          <ion-button\n            type=\"submit\"\n            class=\"login-button\"\n            color=\"light\"\n            expand=\"block\"\n            [disabled]=\"!loginForm.valid\"\n            >ENTER ACCOUNT</ion-button\n          >\n        </ion-col>\n      </ion-row>\n\n      <ion-row class=\"ion-align-items-center\">\n        <ion-col class=\"ion-text-center\">\n          <span class=\"go-to-sign-up\">First time on our app?</span>\n          <span class=\"sign-up-btn\" routerLink=\"/register\">Sign Up</span>\n        </ion-col>\n      </ion-row>\n    </form>\n  </ion-grid>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_starting-views_login_login_module_ts.js.map