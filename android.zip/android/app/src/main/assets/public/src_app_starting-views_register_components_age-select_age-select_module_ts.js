"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_starting-views_register_components_age-select_age-select_module_ts"],{

/***/ 7250:
/*!********************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/age-select/age-select-routing.module.ts ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AgeSelectPageRoutingModule": () => (/* binding */ AgeSelectPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _age_select_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./age-select.page */ 9472);




const routes = [
    {
        path: '',
        component: _age_select_page__WEBPACK_IMPORTED_MODULE_0__.AgeSelectPage
    }
];
let AgeSelectPageRoutingModule = class AgeSelectPageRoutingModule {
};
AgeSelectPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AgeSelectPageRoutingModule);



/***/ }),

/***/ 9704:
/*!************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/age-select/age-select.module.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AgeSelectPageModule": () => (/* binding */ AgeSelectPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _age_select_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./age-select-routing.module */ 7250);
/* harmony import */ var _age_select_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./age-select.page */ 9472);
/* harmony import */ var _angular_slider_ngx_slider__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular-slider/ngx-slider */ 2498);
/* harmony import */ var src_app_pipes_convert_unit_pipe__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/pipes/convert-unit.pipe */ 2931);
/* harmony import */ var src_app_shared_background_curves_background_curves_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/background-curves/background-curves.component */ 7199);










let AgeSelectPageModule = class AgeSelectPageModule {
};
AgeSelectPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _age_select_routing_module__WEBPACK_IMPORTED_MODULE_0__.AgeSelectPageRoutingModule,
            src_app_shared_background_curves_background_curves_component__WEBPACK_IMPORTED_MODULE_3__.BackgroundCurvesComponentModule,
            _angular_slider_ngx_slider__WEBPACK_IMPORTED_MODULE_9__.NgxSliderModule,
            src_app_pipes_convert_unit_pipe__WEBPACK_IMPORTED_MODULE_2__.ConvertUnitPipeModule,
        ],
        declarations: [_age_select_page__WEBPACK_IMPORTED_MODULE_1__.AgeSelectPage],
    })
], AgeSelectPageModule);



/***/ }),

/***/ 9472:
/*!**********************************************************************************!*\
  !*** ./src/app/starting-views/register/components/age-select/age-select.page.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AgeSelectPage": () => (/* binding */ AgeSelectPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _age_select_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./age-select.page.html?ngResource */ 4790);
/* harmony import */ var _age_select_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./age-select.page.scss?ngResource */ 6353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_services_user_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/user-data.service */ 5944);






let AgeSelectPage = class AgeSelectPage {
    constructor(router, activatedRoute, userDataService) {
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.userDataService = userDataService;
        this.selectedUnit = 1;
        this.selectedAge = 12;
        this.options = {
            floor: 2,
            ceil: 100,
            vertical: false,
        };
    }
    ngOnInit() { }
    setSelectedAge() {
        this.userDataService.updateUserData({ age: this.selectedAge });
        this.router.navigate(['../goal-select'], {
            relativeTo: this.activatedRoute,
        });
    }
};
AgeSelectPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.ActivatedRoute },
    { type: src_app_services_user_data_service__WEBPACK_IMPORTED_MODULE_2__.UserDataService }
];
AgeSelectPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-age-select',
        template: _age_select_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_age_select_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AgeSelectPage);



/***/ }),

/***/ 6353:
/*!***********************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/age-select/age-select.page.scss?ngResource ***!
  \***********************************************************************************************/
/***/ ((module) => {

module.exports = ".age-select-header {\n  font-family: Teko-Light;\n  font-style: normal;\n  font-weight: 400;\n  font-size: 50px;\n  color: #efefef;\n  line-height: 30px;\n  margin-left: 1rem;\n}\n\n.age-select-subheader {\n  font-family: Roboto-Light;\n  font-style: normal;\n  font-weight: 400;\n  font-size: 16px;\n  line-height: 42px;\n  color: #efefef;\n  line-height: 10px;\n  margin-left: 1rem;\n}\n\n.age-select-panel {\n  margin-top: calc(100px + (90vh - 118px - 100px) / 2);\n  transform: translate(0, -50%);\n}\n\n.value-panel {\n  position: absolute;\n  bottom: 10vh;\n  left: 50%;\n  transform: translate(-50%, 0);\n  width: 100%;\n}\n\n.age-label,\n.age-value {\n  text-align: center;\n  align-items: center;\n  justify-content: center;\n  color: #005b74;\n}\n\n.age-label {\n  font-family: Roboto-Regular;\n  font-size: 22px;\n}\n\n.age-value {\n  font-family: Roboto-Bold;\n  font-size: 28px;\n}\n\n.age-select-button {\n  height: 3rem;\n  font-family: Roboto-Regular;\n  font-size: 16px;\n  --border-radius: 1rem;\n  margin: 0 2rem;\n}\n\n.arrow-slider {\n  -webkit-appearance: slider-vertical;\n  height: 38vh;\n  margin-top: 0.5rem;\n}\n\nion-grid {\n  padding: 2rem;\n}\n\nion-content {\n  overflow: hidden;\n  --ion-background-color: #efefef;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFnZS1zZWxlY3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsdUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtBQUNGOztBQUVBO0VBQ0Usb0RBQUE7RUFDQSw2QkFBQTtBQUNGOztBQUVBO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsU0FBQTtFQUNBLDZCQUFBO0VBQ0EsV0FBQTtBQUNGOztBQUVBOztFQUVFLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGNBQUE7QUFDRjs7QUFFQTtFQUNFLDJCQUFBO0VBQ0EsZUFBQTtBQUNGOztBQUVBO0VBQ0Usd0JBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBRUE7RUFDRSxZQUFBO0VBQ0EsMkJBQUE7RUFDQSxlQUFBO0VBQ0EscUJBQUE7RUFDQSxjQUFBO0FBQ0Y7O0FBRUE7RUFDRSxtQ0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsYUFBQTtBQUNGOztBQUVBO0VBQ0UsZ0JBQUE7RUFDQSwrQkFBQTtBQUNGIiwiZmlsZSI6ImFnZS1zZWxlY3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmFnZS1zZWxlY3QtaGVhZGVyIHtcclxuICBmb250LWZhbWlseTogVGVrby1MaWdodDtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICBmb250LXNpemU6IDUwcHg7XHJcbiAgY29sb3I6ICNlZmVmZWY7XHJcbiAgbGluZS1oZWlnaHQ6IDMwcHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDFyZW07XHJcbn1cclxuXHJcbi5hZ2Utc2VsZWN0LXN1YmhlYWRlciB7XHJcbiAgZm9udC1mYW1pbHk6IFJvYm90by1MaWdodDtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgbGluZS1oZWlnaHQ6IDQycHg7XHJcbiAgY29sb3I6ICNlZmVmZWY7XHJcbiAgbGluZS1oZWlnaHQ6IDEwcHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDFyZW07XHJcbn1cclxuXHJcbi5hZ2Utc2VsZWN0LXBhbmVsIHtcclxuICBtYXJnaW4tdG9wOiBjYWxjKDEwMHB4ICsgKDEwMHZoIC0gMTB2aCAtIDExOHB4IC0gMTAwcHgpIC8gMik7XHJcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoMCwgLTUwJSk7XHJcbn1cclxuXHJcbi52YWx1ZS1wYW5lbCB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIGJvdHRvbTogMTB2aDtcclxuICBsZWZ0OiA1MCU7XHJcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgMCk7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbi5hZ2UtbGFiZWwsXHJcbi5hZ2UtdmFsdWUge1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGNvbG9yOiAjMDA1Yjc0O1xyXG59XHJcblxyXG4uYWdlLWxhYmVsIHtcclxuICBmb250LWZhbWlseTogUm9ib3RvLVJlZ3VsYXI7XHJcbiAgZm9udC1zaXplOiAyMnB4O1xyXG59XHJcblxyXG4uYWdlLXZhbHVlIHtcclxuICBmb250LWZhbWlseTogUm9ib3RvLUJvbGQ7XHJcbiAgZm9udC1zaXplOiAyOHB4O1xyXG59XHJcblxyXG4uYWdlLXNlbGVjdC1idXR0b24ge1xyXG4gIGhlaWdodDogM3JlbTtcclxuICBmb250LWZhbWlseTogUm9ib3RvLVJlZ3VsYXI7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIC0tYm9yZGVyLXJhZGl1czogMXJlbTtcclxuICBtYXJnaW46IDAgMnJlbTtcclxufVxyXG5cclxuLmFycm93LXNsaWRlciB7XHJcbiAgLXdlYmtpdC1hcHBlYXJhbmNlOiBzbGlkZXItdmVydGljYWw7XHJcbiAgaGVpZ2h0OiAzOHZoO1xyXG4gIG1hcmdpbi10b3A6IDAuNXJlbTtcclxufVxyXG5cclxuaW9uLWdyaWQge1xyXG4gIHBhZGRpbmc6IDJyZW07XHJcbn1cclxuXHJcbmlvbi1jb250ZW50IHtcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNlZmVmZWY7XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 4790:
/*!***********************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/age-select/age-select.page.html?ngResource ***!
  \***********************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <!-- Background Curves -->\n  <app-background-curves></app-background-curves>\n\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"12\" class=\"ion-text-end age-select-header\">\n        <span>AGE</span>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size=\"12\" class=\"ion-text-end age-select-subheader\">\n        <span>How old are you?</span>\n      </ion-col>\n    </ion-row>\n\n    <div class=\"age-select-panel\">\n      <!-- svg row -->\n      <ion-row>\n        <ion-col size=\"12\" class=\"ion-text-center\">\n          <img\n            class=\"primary-image\"\n            [src]=\"selectedAge < 5 ? 'assets/images/infant.svg' : selectedAge < 11 ? 'assets/images/baby.svg' : selectedAge < 18 ? 'assets/images/kid.svg' : selectedAge < 30 ? 'assets/images/student.svg' : selectedAge < 60 ? 'assets/images/adult.svg' : 'assets/images/old.svg'\"\n            alt=\"silouette\"\n            style=\"height: 30vh\"\n          />\n        </ion-col>\n      </ion-row>\n\n      <!-- grid row -->\n      <ion-row>\n        <ion-col size=\"12\" class=\"ion-text-center\">\n          <img\n            class=\"primary-image\"\n            src=\"assets/images/age-scale.svg\"\n            alt=\"ruler\"\n          />\n        </ion-col>\n      </ion-row>\n\n      <!-- arrow row -->\n      <ion-row>\n        <ion-col size=\"12\" class=\"ion-text-center\">\n          <div style=\"height: 28vh; width: 100%\">\n            <ngx-slider\n              [(value)]=\"selectedAge\"\n              [options]=\"options\"\n            ></ngx-slider>\n          </div>\n        </ion-col>\n      </ion-row>\n    </div>\n\n    <div class=\"value-panel\">\n      <ion-row style=\"display: flex\">\n        <ion-col size=\"12\" class=\"ion-text-center\">\n          <span class=\"age-label\">I am</span>\n          <span class=\"age-value\"\n            >{{' ' + (selectedAge | convertUnit:selectedUnit) + ' '}}</span\n          >\n          <span class=\"age-label\">years old</span>\n        </ion-col>\n      </ion-row>\n\n      <ion-row style=\"margin-top: 1rem\">\n        <ion-col size=\"12\" class=\"ion-text-center\">\n          <ion-button\n            class=\"age-select-button\"\n            color=\"primary\"\n            expand=\"block\"\n            (click)=\"setSelectedAge()\"\n            >NEXT</ion-button\n          >\n        </ion-col>\n      </ion-row>\n    </div>\n  </ion-grid>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_starting-views_register_components_age-select_age-select_module_ts.js.map