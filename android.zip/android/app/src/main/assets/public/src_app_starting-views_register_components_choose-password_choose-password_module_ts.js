"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_starting-views_register_components_choose-password_choose-password_module_ts"],{

/***/ 5944:
/*!***********************************************!*\
  !*** ./src/app/services/user-data.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserDataService": () => (/* binding */ UserDataService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 4505);



let UserDataService = class UserDataService {
    constructor() {
        this.userData = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject({
            firstName: null,
            lastName: null,
            email: null,
            genderIsFemale: null,
            heightInCm: null,
            heightInInches: null,
            weight: null,
            age: null,
            goal: null,
            activeLevel: null,
            fatPercentage: null,
            neckCircumference: null,
            waistCircumference: null,
            hipCircumference: null,
            BMR: null,
            totalKcal: null,
            totalCarbs: null,
            totalProtein: null,
            totalFats: null,
            leanBodyMass: null,
        });
        this.currentUserData = this.userData.asObservable();
    }
    updateUserData(data) {
        this.userData.next({ ...this.userData.value, ...data });
    }
    log10(val) {
        return Math.log(val) / Math.log(10);
    }
    calculateKcalAndMacro(data) {
        console.log(data);
        let fatPercentage = null;
        let leanBodyMass = null;
        let BMR = null;
        let totalKcal = null;
        let totalProtein = null;
        let totalFats = null;
        let totalCarbs = null;
        // If we have the fat percentage
        if (data.fatPercentage) {
            fatPercentage = data.fatPercentage;
            leanBodyMass = (data.weight * (100 - data.fatPercentage)) / 100;
            BMR = 370 + 21.6 * leanBodyMass;
        }
        // if we calculated our fat percentage through measurements
        else if ((data.genderIsFemale && data.hipCircumference) ||
            (!data.genderIsFemale && data.waistCircumference)) {
            // we calculate the fat percentage using neck/waist/hip measurements
            fatPercentage = data.genderIsFemale
                ? 163.205 *
                    this.log10(data.waistCircumference +
                        data.hipCircumference -
                        data.neckCircumference) -
                    97.684 * this.log10(data.heightInInches) -
                    78.387
                : 86.01 * this.log10(data.waistCircumference - data.neckCircumference) -
                    70.041 * this.log10(data.heightInInches) +
                    36.76;
            // we aprox the result to 1 decimal
            fatPercentage = Math.round(fatPercentage * 10) / 10;
            // we calculate the lean mass
            leanBodyMass = (data.weight * (100 - fatPercentage)) / 100;
            // calculate the BMR using FIRST formula
            BMR = 370 + 21.6 * leanBodyMass;
        }
        // if we don't have the fat percentage set up
        else {
            // we calculate the BMR using SECOND formula
            BMR = 10 * data.weight + 6.25 * data.heightInCm - 5 * data.age + 5;
            if (data.genderIsFemale) {
                BMR -= 166; // we substract 166 kcal if user is a woman
            }
        }
        // multiply BMR by activity level
        totalKcal = Math.round(BMR * data.activeLevel);
        // substract or add calories regarding the goal
        switch (data.goal) {
            case -1:
                totalKcal -= 300;
                break;
            case 1:
                totalKcal += 300;
                break;
        }
        //  fats = 30% of total calories
        totalFats = Math.round((0.3 * totalKcal) / 9);
        if (data.age < 18) {
            totalProtein = Math.round(data.weight);
        }
        else if (18 <= data.age && data.age < 35) {
            totalProtein = Math.round(data.weight * 1.4);
        }
        else if (35 <= data.age && data.age < 45) {
            totalProtein = Math.round(data.weight * 1.5);
        }
        else {
            totalProtein = Math.round(data.weight * 1.6);
        }
        totalCarbs = Math.round((totalKcal - totalFats * 9 - totalProtein * 4) / 4);
        const result = {
            ...data,
            fatPercentage,
            leanBodyMass,
            BMR,
            totalKcal,
            totalProtein,
            totalCarbs,
            totalFats,
        };
        return result;
    }
};
UserDataService.ctorParameters = () => [];
UserDataService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root',
    })
], UserDataService);



/***/ }),

/***/ 7199:
/*!*************************************************************************!*\
  !*** ./src/app/shared/background-curves/background-curves.component.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BackgroundCurvesComponent": () => (/* binding */ BackgroundCurvesComponent),
/* harmony export */   "BackgroundCurvesComponentModule": () => (/* binding */ BackgroundCurvesComponentModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _background_curves_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./background-curves.component.html?ngResource */ 3774);
/* harmony import */ var _background_curves_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./background-curves.component.scss?ngResource */ 3005);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);




let BackgroundCurvesComponent = class BackgroundCurvesComponent {
    constructor() { }
    ngOnInit() { }
};
BackgroundCurvesComponent.ctorParameters = () => [];
BackgroundCurvesComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-background-curves',
        template: _background_curves_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_background_curves_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], BackgroundCurvesComponent);

let BackgroundCurvesComponentModule = class BackgroundCurvesComponentModule {
};
BackgroundCurvesComponentModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [BackgroundCurvesComponent],
        imports: [],
        exports: [BackgroundCurvesComponent],
    })
], BackgroundCurvesComponentModule);



/***/ }),

/***/ 851:
/*!******************************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/choose-password/choose-password-routing.module.ts ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChoosePasswordPageRoutingModule": () => (/* binding */ ChoosePasswordPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _choose_password_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./choose-password.page */ 6395);




const routes = [
    {
        path: '',
        component: _choose_password_page__WEBPACK_IMPORTED_MODULE_0__.ChoosePasswordPage,
    },
];
let ChoosePasswordPageRoutingModule = class ChoosePasswordPageRoutingModule {
};
ChoosePasswordPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ChoosePasswordPageRoutingModule);



/***/ }),

/***/ 1871:
/*!**********************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/choose-password/choose-password.module.ts ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChoosePasswordPageModule": () => (/* binding */ ChoosePasswordPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_shared_background_curves_background_curves_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/background-curves/background-curves.component */ 7199);
/* harmony import */ var _choose_password_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./choose-password.page */ 6395);
/* harmony import */ var _choose_password_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./choose-password-routing.module */ 851);








let ChoosePasswordPageModule = class ChoosePasswordPageModule {
};
ChoosePasswordPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _choose_password_routing_module__WEBPACK_IMPORTED_MODULE_2__.ChoosePasswordPageRoutingModule,
            src_app_shared_background_curves_background_curves_component__WEBPACK_IMPORTED_MODULE_0__.BackgroundCurvesComponentModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
        ],
        declarations: [_choose_password_page__WEBPACK_IMPORTED_MODULE_1__.ChoosePasswordPage],
    })
], ChoosePasswordPageModule);



/***/ }),

/***/ 6395:
/*!********************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/choose-password/choose-password.page.ts ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChoosePasswordPage": () => (/* binding */ ChoosePasswordPage)
/* harmony export */ });
/* harmony import */ var D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _choose_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./choose-password.page.html?ngResource */ 7777);
/* harmony import */ var _choose_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./choose-password.page.scss?ngResource */ 3745);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);
/* harmony import */ var src_app_services_user_data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/user-data.service */ 5944);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 3910);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);











let ChoosePasswordPage = class ChoosePasswordPage {
  constructor(loadingController, router, activatedRoute, fb, authService, userDataService) {
    this.loadingController = loadingController;
    this.router = router;
    this.activatedRoute = activatedRoute;
    this.fb = fb;
    this.authService = authService;
    this.userDataService = userDataService;
    this.passwordsMatch = true;
    this.userData = null;
  }

  get password() {
    return this.passwordSelectForm.get('password');
  }

  get confirmPassword() {
    return this.passwordSelectForm.get('confirmPassword');
  }

  ngOnInit() {
    this.userDataService.currentUserData.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.take)(1)).subscribe(data => {
      this.userData = data;
    });
    this.passwordSelectForm = this.fb.group({
      password: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(6)]],
      confirmPassword: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required]]
    });
  }

  registerUser() {
    this.userData = { ...this.userData,
      ...this.passwordSelectForm.value
    };

    if (this.password.value !== this.confirmPassword.value) {
      this.passwordsMatch = false;
      return;
    } else {
      this.passwordsMatch = true;
      this.register();
    }
  }

  register() {
    var _this = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const loading = yield _this.loadingController.create({
        showBackdrop: false,
        cssClass: 'custom-loading'
      });
      yield loading.present();
      const user = yield _this.authService.register({
        email: _this.userData.email,
        password: _this.userData.password
      });
      yield loading.dismiss();

      if (user) {
        _this.router.navigate(['../choose-password'], {
          relativeTo: _this.activatedRoute
        });

        console.log('Account created successfully!');

        _this.router.navigate(['../gender-select'], {
          relativeTo: _this.activatedRoute
        });
      } else {
        console.log('Register failed!');
      }
    })();
  }

};

ChoosePasswordPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.LoadingController
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute
}, {
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder
}, {
  type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService
}, {
  type: src_app_services_user_data_service__WEBPACK_IMPORTED_MODULE_4__.UserDataService
}];

ChoosePasswordPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
  selector: 'app-choose-password',
  template: _choose_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_choose_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ChoosePasswordPage);


/***/ }),

/***/ 3005:
/*!**************************************************************************************!*\
  !*** ./src/app/shared/background-curves/background-curves.component.scss?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

module.exports = ".svg-waves-top,\n.svg-waves-bottom {\n  position: absolute;\n}\n\n.svg-waves-bottom {\n  bottom: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJhY2tncm91bmQtY3VydmVzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOztFQUVFLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxXQUFBO0FBQ0YiLCJmaWxlIjoiYmFja2dyb3VuZC1jdXJ2ZXMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc3ZnLXdhdmVzLXRvcCxcclxuLnN2Zy13YXZlcy1ib3R0b20ge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxufVxyXG5cclxuLnN2Zy13YXZlcy1ib3R0b20ge1xyXG4gIGJvdHRvbTogMHB4O1xyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 3745:
/*!*********************************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/choose-password/choose-password.page.scss?ngResource ***!
  \*********************************************************************************************************/
/***/ ((module) => {

module.exports = ".password-header {\n  font-family: Teko-Light;\n  font-style: normal;\n  font-weight: 400;\n  font-size: 50px;\n  color: #efefef;\n  line-height: 20px;\n}\n\n.password-subheader {\n  font-family: Roboto-Light;\n  font-style: normal;\n  font-weight: 400;\n  font-size: 16px;\n  line-height: 42px;\n  color: #efefef;\n  line-height: 10px;\n}\n\n.password-button {\n  height: 3rem;\n  font-family: Roboto-Medium;\n  font-size: 16px;\n  --border-radius: 1rem;\n  margin-top: 18rem;\n}\n\n.go-to-login {\n  font-family: Roboto-Light;\n  color: #828282;\n  font-size: 14px;\n}\n\n.login-btn {\n  font-family: Roboto-Bold;\n  color: #efefef;\n  font-size: 14px;\n  margin-left: 0.3rem;\n}\n\nion-icon {\n  font-size: 64px;\n  color: #505050;\n}\n\nion-content {\n  --ion-background-color: #005b74;\n}\n\nion-grid {\n  margin-top: 5rem;\n  padding: 2rem;\n}\n\nion-item {\n  border-bottom: 1px solid #828282 !important;\n}\n\nion-item.ion-invalid.ion-touched {\n  border-bottom: 1px solid red !important;\n}\n\nion-item.item-has-focus {\n  border-bottom: 1px solid #efefef !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNob29zZS1wYXNzd29yZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUFDRjs7QUFFQTtFQUNFLFlBQUE7RUFDQSwwQkFBQTtFQUNBLGVBQUE7RUFDQSxxQkFBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSx5QkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBRUE7RUFDRSx3QkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7QUFDRjs7QUFFQTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FBQ0Y7O0FBRUE7RUFDRSwrQkFBQTtBQUNGOztBQUVBO0VBQ0UsZ0JBQUE7RUFDQSxhQUFBO0FBQ0Y7O0FBRUE7RUFDRSwyQ0FBQTtBQUNGOztBQUFFO0VBQ0UsdUNBQUE7QUFFSjs7QUFBRTtFQUNFLDJDQUFBO0FBRUoiLCJmaWxlIjoiY2hvb3NlLXBhc3N3b3JkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5wYXNzd29yZC1oZWFkZXIge1xyXG4gIGZvbnQtZmFtaWx5OiBUZWtvLUxpZ2h0O1xyXG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICBmb250LXdlaWdodDogNDAwO1xyXG4gIGZvbnQtc2l6ZTogNTBweDtcclxuICBjb2xvcjogI2VmZWZlZjtcclxuICBsaW5lLWhlaWdodDogMjBweDtcclxufVxyXG5cclxuLnBhc3N3b3JkLXN1YmhlYWRlciB7XHJcbiAgZm9udC1mYW1pbHk6IFJvYm90by1MaWdodDtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgbGluZS1oZWlnaHQ6IDQycHg7XHJcbiAgY29sb3I6ICNlZmVmZWY7XHJcbiAgbGluZS1oZWlnaHQ6IDEwcHg7XHJcbn1cclxuXHJcbi5wYXNzd29yZC1idXR0b24ge1xyXG4gIGhlaWdodDogM3JlbTtcclxuICBmb250LWZhbWlseTogUm9ib3RvLU1lZGl1bTtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgLS1ib3JkZXItcmFkaXVzOiAxcmVtO1xyXG4gIG1hcmdpbi10b3A6IDE4cmVtO1xyXG59XHJcblxyXG4uZ28tdG8tbG9naW4ge1xyXG4gIGZvbnQtZmFtaWx5OiBSb2JvdG8tTGlnaHQ7XHJcbiAgY29sb3I6ICM4MjgyODI7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG59XHJcblxyXG4ubG9naW4tYnRuIHtcclxuICBmb250LWZhbWlseTogUm9ib3RvLUJvbGQ7XHJcbiAgY29sb3I6ICNlZmVmZWY7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG4gIG1hcmdpbi1sZWZ0OiAwLjNyZW07XHJcbn1cclxuXHJcbmlvbi1pY29uIHtcclxuICBmb250LXNpemU6IDY0cHg7XHJcbiAgY29sb3I6ICM1MDUwNTA7XHJcbn1cclxuXHJcbmlvbi1jb250ZW50IHtcclxuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAjMDA1Yjc0O1xyXG59XHJcblxyXG5pb24tZ3JpZCB7XHJcbiAgbWFyZ2luLXRvcDogNXJlbTtcclxuICBwYWRkaW5nOiAycmVtO1xyXG59XHJcblxyXG5pb24taXRlbSB7XHJcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICM4MjgyODIgIWltcG9ydGFudDtcclxuICAmLmlvbi1pbnZhbGlkLmlvbi10b3VjaGVkIHtcclxuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCByZWQgIWltcG9ydGFudDtcclxuICB9XHJcbiAgJi5pdGVtLWhhcy1mb2N1cyB7XHJcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2VmZWZlZiAhaW1wb3J0YW50O1xyXG4gIH1cclxufVxyXG4iXX0= */";

/***/ }),

/***/ 3774:
/*!**************************************************************************************!*\
  !*** ./src/app/shared/background-curves/background-curves.component.html?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

module.exports = "<!-- Top Curves -->\n<svg class=\"svg-waves-top\" viewBox=\"0 0 880 550\">\n  <path\n    fill=\"#005b74\"\n    fill-opacity=\"1\"\n    d=\"M75.84.18h812.9V540.53S786.83,315.38,479.92,272.72,75.84.18,75.84.18Z\"\n  ></path>\n</svg>\n<svg class=\"svg-waves-top\" viewBox=\"0 0 880 550\">\n  <path\n    fill=\"#005b74\"\n    fill-opacity=\"0.78\"\n    d=\"M0,.18,888.88,0l1,354-1,187s-94.78-171.54-450-220S0,.18,0,.18Z\"\n  ></path>\n</svg>\n\n<!-- Bottom Curves -->\n<svg class=\"svg-waves-bottom\" viewBox=\"0 0 350 250\">\n  <path\n    fill=\"#005b74\"\n    fill-opacity=\"0.2\"\n    d=\"M342.17 251H-2.62975V119.782V26.0554C-2.62975 26.0554 40.5959 119.782 170.775 137.541C300.954 155.3 342.17 251 342.17 251Z\"\n  ></path>\n</svg>\n<svg class=\"svg-waves-bottom\" viewBox=\"0 0 350 250\">\n  <path\n    fill=\"#005b74\"\n    fill-opacity=\"0.2\"\n    d=\"M367.356 251H-20V104.583V6.19888e-06C-20 6.19888e-06 28.5607 104.583 174.808 124.399C321.054 144.215 367.356 251 367.356 251Z\"\n  ></path>\n</svg>\n";

/***/ }),

/***/ 7777:
/*!*********************************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/choose-password/choose-password.page.html?ngResource ***!
  \*********************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <ion-grid>\n    <form [formGroup]=\"passwordSelectForm\" (ngSubmit)=\"registerUser()\">\n      <ion-row>\n        <ion-col size=\"12\">\n          <span class=\"password-header\">We all love privacy</span>\n        </ion-col>\n      </ion-row>\n\n      <ion-row>\n        <ion-col size=\"12\" style=\"padding: none\">\n          <span class=\"password-subheader\"> Choose a strong password </span>\n        </ion-col>\n      </ion-row>\n\n      <ion-row style=\"margin-top: 3rem\">\n        <ion-col size=\"12\" class=\"ion-align-items-center\">\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Password</ion-label>\n            <ion-input\n              formControlName=\"password\"\n              class=\"light-text\"\n              type=\"password\"\n            ></ion-input>\n          </ion-item>\n\n          <!-- input error message -->\n          <ng-container\n            *ngIf=\"password.dirty && password.touched && password.errors\"\n          >\n            <span class=\"input-error\" *ngIf=\"password.errors?.['required']\"\n              >*This field is required</span\n            >\n            <span class=\"input-error\" *ngIf=\"password.errors?.['minlength']\"\n              >*The password must contain at least 6 characters</span\n            >\n          </ng-container>\n        </ion-col>\n      </ion-row>\n\n      <ion-row style=\"margin-top: 1rem\">\n        <ion-col size=\"12\" class=\"ion-align-items-center\">\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Confirm password</ion-label>\n            <ion-input\n              formControlName=\"confirmPassword\"\n              class=\"light-text\"\n              type=\"password\"\n            ></ion-input>\n          </ion-item>\n          <!-- input error message -->\n          <ng-container\n            *ngIf=\"confirmPassword.dirty && confirmPassword.touched\"\n          >\n            <span\n              class=\"input-error\"\n              *ngIf=\"confirmPassword.errors?.['required']\"\n              >*This field is required</span\n            >\n            <span class=\"input-error\" *ngIf=\"!passwordsMatch\"\n              >*Passwords do not match</span\n            >\n          </ng-container>\n        </ion-col>\n      </ion-row>\n\n      <ion-row>\n        <ion-col size=\"12\" class=\"ion-text-center\">\n          <ion-button\n            type=\"submit\"\n            class=\"password-button\"\n            color=\"light\"\n            expand=\"block\"\n            >NEXT</ion-button\n          >\n        </ion-col>\n      </ion-row>\n\n      <ion-row>\n        <ion-col class=\"ion-text-center\">\n          <span class=\"go-to-login\">Already have an account?</span>\n          <span class=\"login-btn\" routerLink=\"/login\">Login</span>\n        </ion-col>\n      </ion-row>\n    </form>\n  </ion-grid>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_starting-views_register_components_choose-password_choose-password_module_ts.js.map