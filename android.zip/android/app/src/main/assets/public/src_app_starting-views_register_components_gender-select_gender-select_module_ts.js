"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_starting-views_register_components_gender-select_gender-select_module_ts"],{

/***/ 5944:
/*!***********************************************!*\
  !*** ./src/app/services/user-data.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserDataService": () => (/* binding */ UserDataService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 4505);



let UserDataService = class UserDataService {
    constructor() {
        this.userData = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject({
            firstName: null,
            lastName: null,
            email: null,
            genderIsFemale: null,
            heightInCm: null,
            heightInInches: null,
            weight: null,
            age: null,
            goal: null,
            activeLevel: null,
            fatPercentage: null,
            neckCircumference: null,
            waistCircumference: null,
            hipCircumference: null,
            BMR: null,
            totalKcal: null,
            totalCarbs: null,
            totalProtein: null,
            totalFats: null,
            leanBodyMass: null,
        });
        this.currentUserData = this.userData.asObservable();
    }
    updateUserData(data) {
        this.userData.next({ ...this.userData.value, ...data });
    }
    log10(val) {
        return Math.log(val) / Math.log(10);
    }
    calculateKcalAndMacro(data) {
        console.log(data);
        let fatPercentage = null;
        let leanBodyMass = null;
        let BMR = null;
        let totalKcal = null;
        let totalProtein = null;
        let totalFats = null;
        let totalCarbs = null;
        // If we have the fat percentage
        if (data.fatPercentage) {
            fatPercentage = data.fatPercentage;
            leanBodyMass = (data.weight * (100 - data.fatPercentage)) / 100;
            BMR = 370 + 21.6 * leanBodyMass;
        }
        // if we calculated our fat percentage through measurements
        else if ((data.genderIsFemale && data.hipCircumference) ||
            (!data.genderIsFemale && data.waistCircumference)) {
            // we calculate the fat percentage using neck/waist/hip measurements
            fatPercentage = data.genderIsFemale
                ? 163.205 *
                    this.log10(data.waistCircumference +
                        data.hipCircumference -
                        data.neckCircumference) -
                    97.684 * this.log10(data.heightInInches) -
                    78.387
                : 86.01 * this.log10(data.waistCircumference - data.neckCircumference) -
                    70.041 * this.log10(data.heightInInches) +
                    36.76;
            // we aprox the result to 1 decimal
            fatPercentage = Math.round(fatPercentage * 10) / 10;
            // we calculate the lean mass
            leanBodyMass = (data.weight * (100 - fatPercentage)) / 100;
            // calculate the BMR using FIRST formula
            BMR = 370 + 21.6 * leanBodyMass;
        }
        // if we don't have the fat percentage set up
        else {
            // we calculate the BMR using SECOND formula
            BMR = 10 * data.weight + 6.25 * data.heightInCm - 5 * data.age + 5;
            if (data.genderIsFemale) {
                BMR -= 166; // we substract 166 kcal if user is a woman
            }
        }
        // multiply BMR by activity level
        totalKcal = Math.round(BMR * data.activeLevel);
        // substract or add calories regarding the goal
        switch (data.goal) {
            case -1:
                totalKcal -= 300;
                break;
            case 1:
                totalKcal += 300;
                break;
        }
        //  fats = 30% of total calories
        totalFats = Math.round((0.3 * totalKcal) / 9);
        if (data.age < 18) {
            totalProtein = Math.round(data.weight);
        }
        else if (18 <= data.age && data.age < 35) {
            totalProtein = Math.round(data.weight * 1.4);
        }
        else if (35 <= data.age && data.age < 45) {
            totalProtein = Math.round(data.weight * 1.5);
        }
        else {
            totalProtein = Math.round(data.weight * 1.6);
        }
        totalCarbs = Math.round((totalKcal - totalFats * 9 - totalProtein * 4) / 4);
        const result = {
            ...data,
            fatPercentage,
            leanBodyMass,
            BMR,
            totalKcal,
            totalProtein,
            totalCarbs,
            totalFats,
        };
        return result;
    }
};
UserDataService.ctorParameters = () => [];
UserDataService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root',
    })
], UserDataService);



/***/ }),

/***/ 7199:
/*!*************************************************************************!*\
  !*** ./src/app/shared/background-curves/background-curves.component.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BackgroundCurvesComponent": () => (/* binding */ BackgroundCurvesComponent),
/* harmony export */   "BackgroundCurvesComponentModule": () => (/* binding */ BackgroundCurvesComponentModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _background_curves_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./background-curves.component.html?ngResource */ 3774);
/* harmony import */ var _background_curves_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./background-curves.component.scss?ngResource */ 3005);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);




let BackgroundCurvesComponent = class BackgroundCurvesComponent {
    constructor() { }
    ngOnInit() { }
};
BackgroundCurvesComponent.ctorParameters = () => [];
BackgroundCurvesComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-background-curves',
        template: _background_curves_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_background_curves_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], BackgroundCurvesComponent);

let BackgroundCurvesComponentModule = class BackgroundCurvesComponentModule {
};
BackgroundCurvesComponentModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [BackgroundCurvesComponent],
        imports: [],
        exports: [BackgroundCurvesComponent],
    })
], BackgroundCurvesComponentModule);



/***/ }),

/***/ 4979:
/*!**************************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/gender-select/gender-select-routing.module.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GenderSelectPageRoutingModule": () => (/* binding */ GenderSelectPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _gender_select_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./gender-select.page */ 8089);




const routes = [
    {
        path: '',
        component: _gender_select_page__WEBPACK_IMPORTED_MODULE_0__.GenderSelectPage
    }
];
let GenderSelectPageRoutingModule = class GenderSelectPageRoutingModule {
};
GenderSelectPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], GenderSelectPageRoutingModule);



/***/ }),

/***/ 6196:
/*!******************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/gender-select/gender-select.module.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GenderSelectPageModule": () => (/* binding */ GenderSelectPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _gender_select_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./gender-select-routing.module */ 4979);
/* harmony import */ var _gender_select_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./gender-select.page */ 8089);
/* harmony import */ var src_app_shared_background_curves_background_curves_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/background-curves/background-curves.component */ 7199);








let GenderSelectPageModule = class GenderSelectPageModule {
};
GenderSelectPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            src_app_shared_background_curves_background_curves_component__WEBPACK_IMPORTED_MODULE_2__.BackgroundCurvesComponentModule,
            _gender_select_routing_module__WEBPACK_IMPORTED_MODULE_0__.GenderSelectPageRoutingModule,
        ],
        declarations: [_gender_select_page__WEBPACK_IMPORTED_MODULE_1__.GenderSelectPage],
    })
], GenderSelectPageModule);



/***/ }),

/***/ 8089:
/*!****************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/gender-select/gender-select.page.ts ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GenderSelectPage": () => (/* binding */ GenderSelectPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _gender_select_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./gender-select.page.html?ngResource */ 1403);
/* harmony import */ var _gender_select_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./gender-select.page.scss?ngResource */ 5660);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_services_user_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/user-data.service */ 5944);






let GenderSelectPage = class GenderSelectPage {
    constructor(router, activatedRoute, userDataService) {
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.userDataService = userDataService;
        this.selectedGender = false;
    }
    ngOnInit() { }
    setSelectedGender() {
        this.userDataService.updateUserData({
            genderIsFemale: this.selectedGender,
        });
        this.router.navigate(['../height-select'], {
            relativeTo: this.activatedRoute,
        });
    }
};
GenderSelectPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.ActivatedRoute },
    { type: src_app_services_user_data_service__WEBPACK_IMPORTED_MODULE_2__.UserDataService }
];
GenderSelectPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-gender-select',
        template: _gender_select_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_gender_select_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], GenderSelectPage);



/***/ }),

/***/ 3005:
/*!**************************************************************************************!*\
  !*** ./src/app/shared/background-curves/background-curves.component.scss?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

module.exports = ".svg-waves-top,\n.svg-waves-bottom {\n  position: absolute;\n}\n\n.svg-waves-bottom {\n  bottom: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJhY2tncm91bmQtY3VydmVzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOztFQUVFLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxXQUFBO0FBQ0YiLCJmaWxlIjoiYmFja2dyb3VuZC1jdXJ2ZXMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc3ZnLXdhdmVzLXRvcCxcclxuLnN2Zy13YXZlcy1ib3R0b20ge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxufVxyXG5cclxuLnN2Zy13YXZlcy1ib3R0b20ge1xyXG4gIGJvdHRvbTogMHB4O1xyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 5660:
/*!*****************************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/gender-select/gender-select.page.scss?ngResource ***!
  \*****************************************************************************************************/
/***/ ((module) => {

module.exports = "ion-icon {\n  font-size: 200px;\n  color: #005b74;\n}\n\n.gender-select-wrapper {\n  margin-top: 50vh;\n  transform: translate(0, -50%);\n  z-index: 2;\n}\n\n.gender-select-header {\n  font-family: \"Teko\";\n  font-style: normal;\n  font-weight: 400;\n  font-size: 50px;\n  line-height: 72px;\n  color: #005b74;\n}\n\n.gender-select-subheader {\n  font-family: \"Roboto\";\n  font-style: normal;\n  font-weight: 300;\n  font-size: 20px;\n  line-height: 23px;\n}\n\n.gender-select-button {\n  height: 3rem;\n  font-family: Roboto-Regular;\n  font-size: 16px;\n  --border-radius: 1rem;\n  margin-top: 5rem;\n}\n\n.svg-waves-top,\n.svg-waves-bottom {\n  position: absolute;\n}\n\n.svg-waves-bottom {\n  bottom: 0px;\n}\n\nion-content {\n  --ion-background-color: #efefef;\n}\n\nion-radio {\n  display: none;\n}\n\nion-grid {\n  margin-top: 5rem;\n  padding: 2rem;\n  position: absolute;\n}\n\nion-toggle {\n  width: 100%;\n  height: 100px;\n  padding: 0 3rem;\n  --handle-height: 100px;\n  --handle-width: 100px;\n  --handle-border-radius: 50px;\n  --border-radius: 50px;\n  --background: #005b74;\n  --background-checked: #fff;\n  --handle-background: #fff url(/assets/icon/male-blue.png) no-repeat center /\n    50px;\n  --handle-background-checked: #005b74 url(/assets/icon/female-white.png)\n    no-repeat center / 40px;\n}\n\nion-toggle[aria-checked=false]::before {\n  position: absolute;\n  content: \"MALE\";\n  font-size: 20px;\n  line-height: 31px;\n  top: 50%;\n  transform: translate(0, -50%);\n  left: 11rem;\n  z-index: 2;\n  color: #fff;\n}\n\nion-toggle[aria-checked=false]::after {\n  position: absolute;\n  content: \"\";\n}\n\nion-toggle[aria-checked=true] {\n  position: relative;\n}\n\nion-toggle[aria-checked=true]::before {\n  position: absolute;\n  content: \"\";\n}\n\nion-toggle[aria-checked=true]::after {\n  position: absolute;\n  content: \"FEMALE\";\n  font-size: 20px;\n  font-weight: 500;\n  line-height: 31px;\n  top: 50%;\n  transform: translate(0, -50%);\n  left: 5rem;\n  color: #005b74;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImdlbmRlci1zZWxlY3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBQTtFQUNBLDZCQUFBO0VBQ0EsVUFBQTtBQUNGOztBQUVBO0VBQ0UsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQUNGOztBQUVBO0VBQ0UscUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxZQUFBO0VBQ0EsMkJBQUE7RUFDQSxlQUFBO0VBQ0EscUJBQUE7RUFDQSxnQkFBQTtBQUNGOztBQUVBOztFQUVFLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxXQUFBO0FBQ0Y7O0FBRUE7RUFDRSwrQkFBQTtBQUNGOztBQUVBO0VBQ0UsYUFBQTtBQUNGOztBQUVBO0VBQ0UsZ0JBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7QUFDRjs7QUFFQTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtFQUNBLHNCQUFBO0VBQ0EscUJBQUE7RUFDQSw0QkFBQTtFQUNBLHFCQUFBO0VBQ0EscUJBQUE7RUFDQSwwQkFBQTtFQUVBO1FBQUE7RUFFQTsyQkFBQTtBQUNGOztBQUlFO0VBQ0Usa0JBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsUUFBQTtFQUNBLDZCQUFBO0VBQ0EsV0FBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0FBREo7O0FBR0U7RUFDRSxrQkFBQTtFQUNBLFdBQUE7QUFESjs7QUFJQTtFQUNFLGtCQUFBO0FBREY7O0FBRUU7RUFDRSxrQkFBQTtFQUNBLFdBQUE7QUFBSjs7QUFFRTtFQUNFLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLFFBQUE7RUFDQSw2QkFBQTtFQUNBLFVBQUE7RUFDQSxjQUFBO0FBQUoiLCJmaWxlIjoiZ2VuZGVyLXNlbGVjdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taWNvbiB7XHJcbiAgZm9udC1zaXplOiAyMDBweDtcclxuICBjb2xvcjogIzAwNWI3NDtcclxufVxyXG5cclxuLmdlbmRlci1zZWxlY3Qtd3JhcHBlciB7XHJcbiAgbWFyZ2luLXRvcDogNTB2aDtcclxuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgwLCAtNTAlKTtcclxuICB6LWluZGV4OiAyO1xyXG59XHJcblxyXG4uZ2VuZGVyLXNlbGVjdC1oZWFkZXIge1xyXG4gIGZvbnQtZmFtaWx5OiBcIlRla29cIjtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICBmb250LXNpemU6IDUwcHg7XHJcbiAgbGluZS1oZWlnaHQ6IDcycHg7XHJcbiAgY29sb3I6ICMwMDViNzQ7XHJcbn1cclxuXHJcbi5nZW5kZXItc2VsZWN0LXN1YmhlYWRlciB7XHJcbiAgZm9udC1mYW1pbHk6IFwiUm9ib3RvXCI7XHJcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gIGZvbnQtd2VpZ2h0OiAzMDA7XHJcbiAgZm9udC1zaXplOiAyMHB4O1xyXG4gIGxpbmUtaGVpZ2h0OiAyM3B4O1xyXG59XHJcblxyXG4uZ2VuZGVyLXNlbGVjdC1idXR0b24ge1xyXG4gIGhlaWdodDogM3JlbTtcclxuICBmb250LWZhbWlseTogUm9ib3RvLVJlZ3VsYXI7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIC0tYm9yZGVyLXJhZGl1czogMXJlbTtcclxuICBtYXJnaW4tdG9wOiA1cmVtO1xyXG59XHJcblxyXG4uc3ZnLXdhdmVzLXRvcCxcclxuLnN2Zy13YXZlcy1ib3R0b20ge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxufVxyXG5cclxuLnN2Zy13YXZlcy1ib3R0b20ge1xyXG4gIGJvdHRvbTogMHB4O1xyXG59XHJcblxyXG5pb24tY29udGVudCB7XHJcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2VmZWZlZjtcclxufVxyXG5cclxuaW9uLXJhZGlvIHtcclxuICBkaXNwbGF5OiBub25lO1xyXG59XHJcblxyXG5pb24tZ3JpZCB7XHJcbiAgbWFyZ2luLXRvcDogNXJlbTtcclxuICBwYWRkaW5nOiAycmVtO1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxufVxyXG5cclxuaW9uLXRvZ2dsZSB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxMDBweDtcclxuICBwYWRkaW5nOiAwIDNyZW07XHJcbiAgLS1oYW5kbGUtaGVpZ2h0OiAxMDBweDtcclxuICAtLWhhbmRsZS13aWR0aDogMTAwcHg7XHJcbiAgLS1oYW5kbGUtYm9yZGVyLXJhZGl1czogNTBweDtcclxuICAtLWJvcmRlci1yYWRpdXM6IDUwcHg7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjMDA1Yjc0O1xyXG4gIC0tYmFja2dyb3VuZC1jaGVja2VkOiAjZmZmO1xyXG5cclxuICAtLWhhbmRsZS1iYWNrZ3JvdW5kOiAjZmZmIHVybCgvYXNzZXRzL2ljb24vbWFsZS1ibHVlLnBuZykgbm8tcmVwZWF0IGNlbnRlciAvXHJcbiAgICA1MHB4O1xyXG4gIC0taGFuZGxlLWJhY2tncm91bmQtY2hlY2tlZDogIzAwNWI3NCB1cmwoL2Fzc2V0cy9pY29uL2ZlbWFsZS13aGl0ZS5wbmcpXHJcbiAgICBuby1yZXBlYXQgY2VudGVyIC8gNDBweDtcclxufVxyXG5cclxuaW9uLXRvZ2dsZVthcmlhLWNoZWNrZWQ9XCJmYWxzZVwiXSB7XHJcbiAgJjo6YmVmb3JlIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGNvbnRlbnQ6IFwiTUFMRVwiO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDMxcHg7XHJcbiAgICB0b3A6IDUwJTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKDAsIC01MCUpO1xyXG4gICAgbGVmdDogMTFyZW07XHJcbiAgICB6LWluZGV4OiAyO1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgfVxyXG4gICY6OmFmdGVyIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgfVxyXG59XHJcbmlvbi10b2dnbGVbYXJpYS1jaGVja2VkPVwidHJ1ZVwiXSB7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICY6OmJlZm9yZSB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBjb250ZW50OiBcIlwiO1xyXG4gIH1cclxuICAmOjphZnRlciB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBjb250ZW50OiBcIkZFTUFMRVwiO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIGxpbmUtaGVpZ2h0OiAzMXB4O1xyXG4gICAgdG9wOiA1MCU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgwLCAtNTAlKTtcclxuICAgIGxlZnQ6IDVyZW07XHJcbiAgICBjb2xvcjogIzAwNWI3NDtcclxuICB9XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 3774:
/*!**************************************************************************************!*\
  !*** ./src/app/shared/background-curves/background-curves.component.html?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

module.exports = "<!-- Top Curves -->\n<svg class=\"svg-waves-top\" viewBox=\"0 0 880 550\">\n  <path\n    fill=\"#005b74\"\n    fill-opacity=\"1\"\n    d=\"M75.84.18h812.9V540.53S786.83,315.38,479.92,272.72,75.84.18,75.84.18Z\"\n  ></path>\n</svg>\n<svg class=\"svg-waves-top\" viewBox=\"0 0 880 550\">\n  <path\n    fill=\"#005b74\"\n    fill-opacity=\"0.78\"\n    d=\"M0,.18,888.88,0l1,354-1,187s-94.78-171.54-450-220S0,.18,0,.18Z\"\n  ></path>\n</svg>\n\n<!-- Bottom Curves -->\n<svg class=\"svg-waves-bottom\" viewBox=\"0 0 350 250\">\n  <path\n    fill=\"#005b74\"\n    fill-opacity=\"0.2\"\n    d=\"M342.17 251H-2.62975V119.782V26.0554C-2.62975 26.0554 40.5959 119.782 170.775 137.541C300.954 155.3 342.17 251 342.17 251Z\"\n  ></path>\n</svg>\n<svg class=\"svg-waves-bottom\" viewBox=\"0 0 350 250\">\n  <path\n    fill=\"#005b74\"\n    fill-opacity=\"0.2\"\n    d=\"M367.356 251H-20V104.583V6.19888e-06C-20 6.19888e-06 28.5607 104.583 174.808 124.399C321.054 144.215 367.356 251 367.356 251Z\"\n  ></path>\n</svg>\n";

/***/ }),

/***/ 1403:
/*!*****************************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/gender-select/gender-select.page.html?ngResource ***!
  \*****************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <!-- Background Curves -->\n  <app-background-curves></app-background-curves>\n\n  <ion-grid class=\"gender-select-wrapper\">\n    <ion-row>\n      <ion-col size=\"12\" class=\"gender-select-subheader\">\n        <span>Hi, Stefan!</span>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=\"12\" class=\"gender-select-header\">\n        <span>SELECT YOUR GENDER</span>\n      </ion-col>\n    </ion-row>\n\n    <ion-row style=\"margin-top: 3rem\">\n      <ion-toggle [(ngModel)]=\"selectedGender\"> </ion-toggle>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size=\"12\" class=\"ion-text-center\">\n        <ion-button\n          class=\"gender-select-button\"\n          color=\"primary\"\n          expand=\"block\"\n          routerLink=\"/height-select\"\n          (click)=\"setSelectedGender()\"\n          >NEXT</ion-button\n        >\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_starting-views_register_components_gender-select_gender-select_module_ts.js.map