"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_starting-views_register_components_height-select_height-select_module_ts"],{

/***/ 2847:
/*!**************************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/height-select/height-select-routing.module.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeightSelectPageRoutingModule": () => (/* binding */ HeightSelectPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _height_select_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./height-select.page */ 9351);




const routes = [
    {
        path: '',
        component: _height_select_page__WEBPACK_IMPORTED_MODULE_0__.HeightSelectPage
    }
];
let HeightSelectPageRoutingModule = class HeightSelectPageRoutingModule {
};
HeightSelectPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], HeightSelectPageRoutingModule);



/***/ }),

/***/ 4197:
/*!******************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/height-select/height-select.module.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeightSelectPageModule": () => (/* binding */ HeightSelectPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _height_select_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./height-select-routing.module */ 2847);
/* harmony import */ var _height_select_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./height-select.page */ 9351);
/* harmony import */ var src_app_shared_background_curves_background_curves_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/background-curves/background-curves.component */ 7199);
/* harmony import */ var _angular_slider_ngx_slider__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular-slider/ngx-slider */ 2498);
/* harmony import */ var src_app_pipes_convert_unit_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/pipes/convert-unit.pipe */ 2931);










let HeightSelectPageModule = class HeightSelectPageModule {
};
HeightSelectPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _height_select_routing_module__WEBPACK_IMPORTED_MODULE_0__.HeightSelectPageRoutingModule,
            src_app_shared_background_curves_background_curves_component__WEBPACK_IMPORTED_MODULE_2__.BackgroundCurvesComponentModule,
            _angular_slider_ngx_slider__WEBPACK_IMPORTED_MODULE_9__.NgxSliderModule,
            src_app_pipes_convert_unit_pipe__WEBPACK_IMPORTED_MODULE_3__.ConvertUnitPipeModule,
        ],
        declarations: [_height_select_page__WEBPACK_IMPORTED_MODULE_1__.HeightSelectPage],
    })
], HeightSelectPageModule);



/***/ }),

/***/ 9351:
/*!****************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/height-select/height-select.page.ts ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeightSelectPage": () => (/* binding */ HeightSelectPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _height_select_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./height-select.page.html?ngResource */ 3669);
/* harmony import */ var _height_select_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./height-select.page.scss?ngResource */ 7389);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_services_user_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/user-data.service */ 5944);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 3910);







let HeightSelectPage = class HeightSelectPage {
    constructor(router, activatedRoute, userDataService) {
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.userDataService = userDataService;
        this.selectedUnit = 1;
        this.selectedHeight = 170;
        this.genderIsFemale = false;
        this.options = {
            floor: 120,
            ceil: 220,
            vertical: true,
        };
    }
    ngOnInit() {
        this.userDataService.currentUserData
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.take)(1))
            .subscribe((data) => (this.genderIsFemale = data.genderIsFemale));
    }
    setSelectedHeight() {
        const heightInCm = this.selectedHeight;
        this.userDataService.updateUserData({
            heightInCm: heightInCm,
            heightInInches: heightInCm / 2.54,
        });
        this.router.navigate(['../weight-select'], {
            relativeTo: this.activatedRoute,
        });
    }
};
HeightSelectPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute },
    { type: src_app_services_user_data_service__WEBPACK_IMPORTED_MODULE_2__.UserDataService }
];
HeightSelectPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-height-select',
        template: _height_select_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_height_select_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HeightSelectPage);



/***/ }),

/***/ 7389:
/*!*****************************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/height-select/height-select.page.scss?ngResource ***!
  \*****************************************************************************************************/
/***/ ((module) => {

module.exports = ".height-select-header {\n  font-family: Teko-Light;\n  font-style: normal;\n  font-weight: 400;\n  font-size: 50px;\n  color: #efefef;\n  line-height: 30px;\n  margin-left: 1rem;\n}\n\n.height-select-subheader {\n  font-family: Roboto-Light;\n  font-style: normal;\n  font-weight: 400;\n  font-size: 16px;\n  line-height: 42px;\n  color: #efefef;\n  line-height: 10px;\n  margin-left: 1rem;\n}\n\n.height-select-panel {\n  margin-top: calc(30px + (90vh - 140px - 80px) / 2);\n  transform: translate(0, -50%);\n}\n\n.value-panel {\n  position: absolute;\n  bottom: 10vh;\n  left: 50%;\n  transform: translate(-50%, 0);\n  width: 100%;\n}\n\n.height-label,\n.height-value {\n  text-align: center;\n  align-items: center;\n  justify-content: center;\n  color: #005b74;\n}\n\n.height-label {\n  font-family: Roboto-Regular;\n  font-size: 22px;\n}\n\n.height-value {\n  font-family: Roboto-Bold;\n  font-size: 28px;\n}\n\n.height-select-button {\n  height: 3rem;\n  font-family: Roboto-Regular;\n  font-size: 16px;\n  --border-radius: 1rem;\n  margin: 0 2rem;\n}\n\n.arrow-slider {\n  -webkit-appearance: slider-vertical;\n  height: 38vh;\n  margin-top: 0.5rem;\n}\n\nion-grid {\n  padding: 2rem;\n}\n\nion-content {\n  overflow: hidden;\n  --ion-background-color: #efefef;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlaWdodC1zZWxlY3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsdUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtBQUNGOztBQUVBO0VBQ0Usa0RBQUE7RUFDQSw2QkFBQTtBQUNGOztBQUVBO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsU0FBQTtFQUNBLDZCQUFBO0VBQ0EsV0FBQTtBQUNGOztBQUVBOztFQUVFLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGNBQUE7QUFDRjs7QUFFQTtFQUNFLDJCQUFBO0VBQ0EsZUFBQTtBQUNGOztBQUVBO0VBQ0Usd0JBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBRUE7RUFDRSxZQUFBO0VBQ0EsMkJBQUE7RUFDQSxlQUFBO0VBQ0EscUJBQUE7RUFDQSxjQUFBO0FBQ0Y7O0FBRUE7RUFDRSxtQ0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsYUFBQTtBQUNGOztBQUVBO0VBQ0UsZ0JBQUE7RUFDQSwrQkFBQTtBQUNGIiwiZmlsZSI6ImhlaWdodC1zZWxlY3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlaWdodC1zZWxlY3QtaGVhZGVyIHtcclxuICBmb250LWZhbWlseTogVGVrby1MaWdodDtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICBmb250LXNpemU6IDUwcHg7XHJcbiAgY29sb3I6ICNlZmVmZWY7XHJcbiAgbGluZS1oZWlnaHQ6IDMwcHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDFyZW07XHJcbn1cclxuXHJcbi5oZWlnaHQtc2VsZWN0LXN1YmhlYWRlciB7XHJcbiAgZm9udC1mYW1pbHk6IFJvYm90by1MaWdodDtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgbGluZS1oZWlnaHQ6IDQycHg7XHJcbiAgY29sb3I6ICNlZmVmZWY7XHJcbiAgbGluZS1oZWlnaHQ6IDEwcHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDFyZW07XHJcbn1cclxuXHJcbi5oZWlnaHQtc2VsZWN0LXBhbmVsIHtcclxuICBtYXJnaW4tdG9wOiBjYWxjKDMwcHggKyAoMTAwdmggLSAxMHZoIC0gMTQwcHggLSA4MHB4KSAvIDIpO1xyXG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKDAsIC01MCUpO1xyXG59XHJcblxyXG4udmFsdWUtcGFuZWwge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICBib3R0b206IDEwdmg7XHJcbiAgbGVmdDogNTAlO1xyXG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIDApO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG4uaGVpZ2h0LWxhYmVsLFxyXG4uaGVpZ2h0LXZhbHVlIHtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBjb2xvcjogIzAwNWI3NDtcclxufVxyXG5cclxuLmhlaWdodC1sYWJlbCB7XHJcbiAgZm9udC1mYW1pbHk6IFJvYm90by1SZWd1bGFyO1xyXG4gIGZvbnQtc2l6ZTogMjJweDtcclxufVxyXG5cclxuLmhlaWdodC12YWx1ZSB7XHJcbiAgZm9udC1mYW1pbHk6IFJvYm90by1Cb2xkO1xyXG4gIGZvbnQtc2l6ZTogMjhweDtcclxufVxyXG5cclxuLmhlaWdodC1zZWxlY3QtYnV0dG9uIHtcclxuICBoZWlnaHQ6IDNyZW07XHJcbiAgZm9udC1mYW1pbHk6IFJvYm90by1SZWd1bGFyO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICAtLWJvcmRlci1yYWRpdXM6IDFyZW07XHJcbiAgbWFyZ2luOiAwIDJyZW07XHJcbn1cclxuXHJcbi5hcnJvdy1zbGlkZXIge1xyXG4gIC13ZWJraXQtYXBwZWFyYW5jZTogc2xpZGVyLXZlcnRpY2FsO1xyXG4gIGhlaWdodDogMzh2aDtcclxuICBtYXJnaW4tdG9wOiAwLjVyZW07XHJcbn1cclxuXHJcbmlvbi1ncmlkIHtcclxuICBwYWRkaW5nOiAycmVtO1xyXG59XHJcblxyXG5pb24tY29udGVudCB7XHJcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAjZWZlZmVmO1xyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 3669:
/*!*****************************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/height-select/height-select.page.html?ngResource ***!
  \*****************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <!-- Background Curves -->\n  <app-background-curves></app-background-curves>\n\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"12\" class=\"ion-text-end height-select-header\">\n        <span>HEIGHT</span>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size=\"12\" class=\"ion-text-end height-select-subheader\">\n        <span>Please select your height</span>\n      </ion-col>\n    </ion-row>\n\n    <ion-row class=\"height-select-panel\">\n      <ion-col size=\"6\" class=\"ion-text-center\">\n        <img\n          class=\"primary-image\"\n          [src]=\"genderIsFemale ? 'assets/images/femaleBlack.svg' : 'assets/images/maleBlack.svg'\"\n          alt=\"silouette\"\n          style=\"height: 40vh\"\n        />\n      </ion-col>\n      <ion-col size=\"2\" class=\"ion-text-center\">\n        <img\n          class=\"primary-image\"\n          src=\"assets/images/rulerBlack.svg\"\n          alt=\"ruler\"\n          style=\"height: 40vh\"\n        />\n      </ion-col>\n      <ion-col size=\"4\" class=\"ion-text-center\">\n        <div style=\"height: 38vh\" class=\"height-slider\">\n          <ngx-slider\n            [(value)]=\"selectedHeight\"\n            [options]=\"options\"\n          ></ngx-slider>\n        </div>\n      </ion-col>\n    </ion-row>\n\n    <div class=\"value-panel\">\n      <ion-row style=\"display: flex\">\n        <ion-col size=\"12\" class=\"ion-text-center\">\n          <span class=\"height-label\">Your height: </span>\n          <span class=\"height-value\"\n            >{{ selectedHeight | convertUnit:selectedUnit}}</span\n          >\n        </ion-col>\n      </ion-row>\n\n      <ion-row>\n        <ion-col size=\"12\" class=\"ion-text-center\">\n          <ion-radio-group\n            [(ngModel)]=\"selectedUnit\"\n            style=\"display: flex; justify-content: space-evenly\"\n          >\n            <ion-item lines=\"none\">\n              <ion-radio [value]=\"1\"></ion-radio>\n              <ion-label style=\"margin-left: 0.3rem\">cm</ion-label>\n            </ion-item>\n            <ion-item lines=\"none\">\n              <ion-radio [value]=\"2\"></ion-radio>\n              <ion-label style=\"margin-left: 0.3rem\">feet</ion-label>\n            </ion-item>\n          </ion-radio-group>\n        </ion-col>\n      </ion-row>\n\n      <ion-row style=\"margin-top: 1rem\">\n        <ion-col size=\"12\" class=\"ion-text-center\">\n          <ion-button\n            class=\"height-select-button\"\n            color=\"primary\"\n            expand=\"block\"\n            (click)=\"setSelectedHeight()\"\n            >NEXT</ion-button\n          >\n        </ion-col>\n      </ion-row>\n    </div>\n  </ion-grid>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_starting-views_register_components_height-select_height-select_module_ts.js.map