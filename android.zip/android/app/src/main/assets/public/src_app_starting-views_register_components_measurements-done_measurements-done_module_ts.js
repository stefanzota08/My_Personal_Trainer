"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_starting-views_register_components_measurements-done_measurements-done_module_ts"],{

/***/ 5944:
/*!***********************************************!*\
  !*** ./src/app/services/user-data.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserDataService": () => (/* binding */ UserDataService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 4505);



let UserDataService = class UserDataService {
    constructor() {
        this.userData = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject({
            firstName: null,
            lastName: null,
            email: null,
            genderIsFemale: null,
            heightInCm: null,
            heightInInches: null,
            weight: null,
            age: null,
            goal: null,
            activeLevel: null,
            fatPercentage: null,
            neckCircumference: null,
            waistCircumference: null,
            hipCircumference: null,
            BMR: null,
            totalKcal: null,
            totalCarbs: null,
            totalProtein: null,
            totalFats: null,
            leanBodyMass: null,
        });
        this.currentUserData = this.userData.asObservable();
    }
    updateUserData(data) {
        this.userData.next({ ...this.userData.value, ...data });
    }
    log10(val) {
        return Math.log(val) / Math.log(10);
    }
    calculateKcalAndMacro(data) {
        console.log(data);
        let fatPercentage = null;
        let leanBodyMass = null;
        let BMR = null;
        let totalKcal = null;
        let totalProtein = null;
        let totalFats = null;
        let totalCarbs = null;
        // If we have the fat percentage
        if (data.fatPercentage) {
            fatPercentage = data.fatPercentage;
            leanBodyMass = (data.weight * (100 - data.fatPercentage)) / 100;
            BMR = 370 + 21.6 * leanBodyMass;
        }
        // if we calculated our fat percentage through measurements
        else if ((data.genderIsFemale && data.hipCircumference) ||
            (!data.genderIsFemale && data.waistCircumference)) {
            // we calculate the fat percentage using neck/waist/hip measurements
            fatPercentage = data.genderIsFemale
                ? 163.205 *
                    this.log10(data.waistCircumference +
                        data.hipCircumference -
                        data.neckCircumference) -
                    97.684 * this.log10(data.heightInInches) -
                    78.387
                : 86.01 * this.log10(data.waistCircumference - data.neckCircumference) -
                    70.041 * this.log10(data.heightInInches) +
                    36.76;
            // we aprox the result to 1 decimal
            fatPercentage = Math.round(fatPercentage * 10) / 10;
            // we calculate the lean mass
            leanBodyMass = (data.weight * (100 - fatPercentage)) / 100;
            // calculate the BMR using FIRST formula
            BMR = 370 + 21.6 * leanBodyMass;
        }
        // if we don't have the fat percentage set up
        else {
            // we calculate the BMR using SECOND formula
            BMR = 10 * data.weight + 6.25 * data.heightInCm - 5 * data.age + 5;
            if (data.genderIsFemale) {
                BMR -= 166; // we substract 166 kcal if user is a woman
            }
        }
        // multiply BMR by activity level
        totalKcal = Math.round(BMR * data.activeLevel);
        // substract or add calories regarding the goal
        switch (data.goal) {
            case -1:
                totalKcal -= 300;
                break;
            case 1:
                totalKcal += 300;
                break;
        }
        //  fats = 30% of total calories
        totalFats = Math.round((0.3 * totalKcal) / 9);
        if (data.age < 18) {
            totalProtein = Math.round(data.weight);
        }
        else if (18 <= data.age && data.age < 35) {
            totalProtein = Math.round(data.weight * 1.4);
        }
        else if (35 <= data.age && data.age < 45) {
            totalProtein = Math.round(data.weight * 1.5);
        }
        else {
            totalProtein = Math.round(data.weight * 1.6);
        }
        totalCarbs = Math.round((totalKcal - totalFats * 9 - totalProtein * 4) / 4);
        const result = {
            ...data,
            fatPercentage,
            leanBodyMass,
            BMR,
            totalKcal,
            totalProtein,
            totalCarbs,
            totalFats,
        };
        return result;
    }
};
UserDataService.ctorParameters = () => [];
UserDataService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root',
    })
], UserDataService);



/***/ }),

/***/ 1360:
/*!**********************************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/measurements-done/measurements-done-routing.module.ts ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MeasurementsDonePageRoutingModule": () => (/* binding */ MeasurementsDonePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _measurements_done_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./measurements-done.page */ 8832);




const routes = [
    {
        path: '',
        component: _measurements_done_page__WEBPACK_IMPORTED_MODULE_0__.MeasurementsDonePage
    }
];
let MeasurementsDonePageRoutingModule = class MeasurementsDonePageRoutingModule {
};
MeasurementsDonePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MeasurementsDonePageRoutingModule);



/***/ }),

/***/ 3528:
/*!**************************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/measurements-done/measurements-done.module.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MeasurementsDonePageModule": () => (/* binding */ MeasurementsDonePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _measurements_done_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./measurements-done-routing.module */ 1360);
/* harmony import */ var _measurements_done_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./measurements-done.page */ 8832);







let MeasurementsDonePageModule = class MeasurementsDonePageModule {
};
MeasurementsDonePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _measurements_done_routing_module__WEBPACK_IMPORTED_MODULE_0__.MeasurementsDonePageRoutingModule
        ],
        declarations: [_measurements_done_page__WEBPACK_IMPORTED_MODULE_1__.MeasurementsDonePage]
    })
], MeasurementsDonePageModule);



/***/ }),

/***/ 8832:
/*!************************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/measurements-done/measurements-done.page.ts ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MeasurementsDonePage": () => (/* binding */ MeasurementsDonePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _measurements_done_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./measurements-done.page.html?ngResource */ 2130);
/* harmony import */ var _measurements_done_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./measurements-done.page.scss?ngResource */ 5992);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 3910);
/* harmony import */ var src_app_services_daily_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/daily-data.service */ 5268);
/* harmony import */ var src_app_services_user_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/user-data.service */ 5944);
/* harmony import */ var src_app_services_user_info_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/user-info.service */ 5360);








let MeasurementsDonePage = class MeasurementsDonePage {
    constructor(userDataService, dailyDataService, userInfoService) {
        this.userDataService = userDataService;
        this.dailyDataService = dailyDataService;
        this.userInfoService = userInfoService;
    }
    ngOnInit() {
        this.userDataService.currentUserData.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.take)(1)).subscribe((data) => {
            const result = this.userDataService.calculateKcalAndMacro(data);
            const fatPercentage = result.fatPercentage;
            const leanBodyMass = result.leanBodyMass;
            const BMR = Math.round(result.BMR);
            const totalKcal = result.totalKcal;
            const totalProtein = result.totalProtein;
            const totalFats = result.totalFats;
            const totalCarbs = result.totalCarbs;
            this.userInfoService.uploadUserInfo({
                ...data,
                fatPercentage,
                leanBodyMass,
            });
            this.userInfoService.uploadUserDietData({
                BMR,
                totalKcal,
                totalProtein,
                totalCarbs,
                totalFats,
                weight: Math.round(data.weight),
            });
            this.dailyDataService.uploadCurrentDateWithData({
                BMR,
                totalKcal,
                totalProtein,
                totalCarbs,
                totalFats,
                weight: Math.round(data.weight),
            });
        });
    }
    log10(val) {
        return Math.log(val) / Math.log(10);
    }
};
MeasurementsDonePage.ctorParameters = () => [
    { type: src_app_services_user_data_service__WEBPACK_IMPORTED_MODULE_3__.UserDataService },
    { type: src_app_services_daily_data_service__WEBPACK_IMPORTED_MODULE_2__.DailyDataService },
    { type: src_app_services_user_info_service__WEBPACK_IMPORTED_MODULE_4__.UserInfoService }
];
MeasurementsDonePage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-measurements-done',
        template: _measurements_done_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_measurements_done_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], MeasurementsDonePage);



/***/ }),

/***/ 5992:
/*!*************************************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/measurements-done/measurements-done.page.scss?ngResource ***!
  \*************************************************************************************************************/
/***/ ((module) => {

module.exports = ".done-wrapper {\n  margin-top: 50vh;\n  transform: translate(0, -50%);\n}\n\n.done-header {\n  font-family: Teko-Light;\n  font-weight: 100;\n  font-size: 64px;\n  color: #005b74;\n}\n\n.done-subheader {\n  font-family: Roboto-Light;\n  font-weight: 100;\n  font-size: 15px;\n}\n\n.done-button {\n  position: absolute;\n  display: flex;\n  text-align: end;\n  height: 10rem;\n  font-family: Teko-Light;\n  font-size: 35px;\n  width: 100%;\n  bottom: 0;\n  padding: 0 !important;\n  margin: 0 !important;\n  --border-radius: 0px !important;\n  letter-spacing: 0 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1lYXN1cmVtZW50cy1kb25lLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0VBQ0EsNkJBQUE7QUFDRjs7QUFFQTtFQUNFLHVCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtBQUNGOztBQUVBO0VBQ0UseUJBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFDRjs7QUFFQTtFQUNFLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxxQkFBQTtFQUNBLG9CQUFBO0VBQ0EsK0JBQUE7RUFDQSw0QkFBQTtBQUNGIiwiZmlsZSI6Im1lYXN1cmVtZW50cy1kb25lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5kb25lLXdyYXBwZXIge1xyXG4gIG1hcmdpbi10b3A6IDUwdmg7XHJcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoMCwgLTUwJSk7XHJcbn1cclxuXHJcbi5kb25lLWhlYWRlciB7XHJcbiAgZm9udC1mYW1pbHk6IFRla28tTGlnaHQ7XHJcbiAgZm9udC13ZWlnaHQ6IDEwMDtcclxuICBmb250LXNpemU6IDY0cHg7XHJcbiAgY29sb3I6ICMwMDViNzQ7XHJcbn1cclxuXHJcbi5kb25lLXN1YmhlYWRlciB7XHJcbiAgZm9udC1mYW1pbHk6IFJvYm90by1MaWdodDtcclxuICBmb250LXdlaWdodDogMTAwO1xyXG4gIGZvbnQtc2l6ZTogMTVweDtcclxufVxyXG5cclxuLmRvbmUtYnV0dG9uIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICB0ZXh0LWFsaWduOiBlbmQ7XHJcbiAgaGVpZ2h0OiAxMHJlbTtcclxuICBmb250LWZhbWlseTogVGVrby1MaWdodDtcclxuICBmb250LXNpemU6IDM1cHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgYm90dG9tOiAwO1xyXG4gIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcclxuICBtYXJnaW46IDAgIWltcG9ydGFudDtcclxuICAtLWJvcmRlci1yYWRpdXM6IDBweCAhaW1wb3J0YW50O1xyXG4gIGxldHRlci1zcGFjaW5nOiAwICFpbXBvcnRhbnQ7XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 2130:
/*!*************************************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/measurements-done/measurements-done.page.html?ngResource ***!
  \*************************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content style=\"padding: 0; margin: 0\">\n  <ion-grid class=\"done-wrapper\">\n    <ion-row>\n      <ion-col size=\"12\" class=\"ion-text-center\">\n        <img src=\"assets/images/done.svg\" alt=\"done\" style=\"height: 12rem\" />\n      </ion-col>\n    </ion-row>\n\n    <ion-row style=\"margin-top: 1rem\">\n      <ion-col size=\"12\" class=\"ion-text-center\">\n        <span class=\"done-header\">DONE!</span>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size=\"12\" class=\"ion-text-center\" style=\"margin-top: 0.3rem\">\n        <span class=\"done-subheader\"\n          >You have successfully set up your account</span\n        >\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <ion-button\n    class=\"done-button\"\n    color=\"primary\"\n    expand=\"block\"\n    routerLink=\"/tabs\"\n  >\n    <span>ENTER ACCOUNT</span>\n    <ion-icon name=\"arrow-forward-outline\" style=\"font-size: 35px\"></ion-icon\n  ></ion-button>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_starting-views_register_components_measurements-done_measurements-done_module_ts.js.map