"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_starting-views_register_components_waist-circumference_waist-circumference_module_ts"],{

/***/ 5944:
/*!***********************************************!*\
  !*** ./src/app/services/user-data.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserDataService": () => (/* binding */ UserDataService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 4505);



let UserDataService = class UserDataService {
    constructor() {
        this.userData = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject({
            firstName: null,
            lastName: null,
            email: null,
            genderIsFemale: null,
            heightInCm: null,
            heightInInches: null,
            weight: null,
            age: null,
            goal: null,
            activeLevel: null,
            fatPercentage: null,
            neckCircumference: null,
            waistCircumference: null,
            hipCircumference: null,
            BMR: null,
            totalKcal: null,
            totalCarbs: null,
            totalProtein: null,
            totalFats: null,
            leanBodyMass: null,
        });
        this.currentUserData = this.userData.asObservable();
    }
    updateUserData(data) {
        this.userData.next({ ...this.userData.value, ...data });
    }
    log10(val) {
        return Math.log(val) / Math.log(10);
    }
    calculateKcalAndMacro(data) {
        console.log(data);
        let fatPercentage = null;
        let leanBodyMass = null;
        let BMR = null;
        let totalKcal = null;
        let totalProtein = null;
        let totalFats = null;
        let totalCarbs = null;
        // If we have the fat percentage
        if (data.fatPercentage) {
            fatPercentage = data.fatPercentage;
            leanBodyMass = (data.weight * (100 - data.fatPercentage)) / 100;
            BMR = 370 + 21.6 * leanBodyMass;
        }
        // if we calculated our fat percentage through measurements
        else if ((data.genderIsFemale && data.hipCircumference) ||
            (!data.genderIsFemale && data.waistCircumference)) {
            // we calculate the fat percentage using neck/waist/hip measurements
            fatPercentage = data.genderIsFemale
                ? 163.205 *
                    this.log10(data.waistCircumference +
                        data.hipCircumference -
                        data.neckCircumference) -
                    97.684 * this.log10(data.heightInInches) -
                    78.387
                : 86.01 * this.log10(data.waistCircumference - data.neckCircumference) -
                    70.041 * this.log10(data.heightInInches) +
                    36.76;
            // we aprox the result to 1 decimal
            fatPercentage = Math.round(fatPercentage * 10) / 10;
            // we calculate the lean mass
            leanBodyMass = (data.weight * (100 - fatPercentage)) / 100;
            // calculate the BMR using FIRST formula
            BMR = 370 + 21.6 * leanBodyMass;
        }
        // if we don't have the fat percentage set up
        else {
            // we calculate the BMR using SECOND formula
            BMR = 10 * data.weight + 6.25 * data.heightInCm - 5 * data.age + 5;
            if (data.genderIsFemale) {
                BMR -= 166; // we substract 166 kcal if user is a woman
            }
        }
        // multiply BMR by activity level
        totalKcal = Math.round(BMR * data.activeLevel);
        // substract or add calories regarding the goal
        switch (data.goal) {
            case -1:
                totalKcal -= 300;
                break;
            case 1:
                totalKcal += 300;
                break;
        }
        //  fats = 30% of total calories
        totalFats = Math.round((0.3 * totalKcal) / 9);
        if (data.age < 18) {
            totalProtein = Math.round(data.weight);
        }
        else if (18 <= data.age && data.age < 35) {
            totalProtein = Math.round(data.weight * 1.4);
        }
        else if (35 <= data.age && data.age < 45) {
            totalProtein = Math.round(data.weight * 1.5);
        }
        else {
            totalProtein = Math.round(data.weight * 1.6);
        }
        totalCarbs = Math.round((totalKcal - totalFats * 9 - totalProtein * 4) / 4);
        const result = {
            ...data,
            fatPercentage,
            leanBodyMass,
            BMR,
            totalKcal,
            totalProtein,
            totalCarbs,
            totalFats,
        };
        return result;
    }
};
UserDataService.ctorParameters = () => [];
UserDataService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root',
    })
], UserDataService);



/***/ }),

/***/ 7199:
/*!*************************************************************************!*\
  !*** ./src/app/shared/background-curves/background-curves.component.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BackgroundCurvesComponent": () => (/* binding */ BackgroundCurvesComponent),
/* harmony export */   "BackgroundCurvesComponentModule": () => (/* binding */ BackgroundCurvesComponentModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _background_curves_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./background-curves.component.html?ngResource */ 3774);
/* harmony import */ var _background_curves_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./background-curves.component.scss?ngResource */ 3005);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);




let BackgroundCurvesComponent = class BackgroundCurvesComponent {
    constructor() { }
    ngOnInit() { }
};
BackgroundCurvesComponent.ctorParameters = () => [];
BackgroundCurvesComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-background-curves',
        template: _background_curves_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_background_curves_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], BackgroundCurvesComponent);

let BackgroundCurvesComponentModule = class BackgroundCurvesComponentModule {
};
BackgroundCurvesComponentModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [BackgroundCurvesComponent],
        imports: [],
        exports: [BackgroundCurvesComponent],
    })
], BackgroundCurvesComponentModule);



/***/ }),

/***/ 5874:
/*!**************************************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/waist-circumference/waist-circumference-routing.module.ts ***!
  \**************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WaistCircumferencePageRoutingModule": () => (/* binding */ WaistCircumferencePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _waist_circumference_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./waist-circumference.page */ 6232);




const routes = [
    {
        path: '',
        component: _waist_circumference_page__WEBPACK_IMPORTED_MODULE_0__.WaistCircumferencePage
    }
];
let WaistCircumferencePageRoutingModule = class WaistCircumferencePageRoutingModule {
};
WaistCircumferencePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], WaistCircumferencePageRoutingModule);



/***/ }),

/***/ 7911:
/*!******************************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/waist-circumference/waist-circumference.module.ts ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WaistCircumferencePageModule": () => (/* binding */ WaistCircumferencePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _waist_circumference_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./waist-circumference-routing.module */ 5874);
/* harmony import */ var _waist_circumference_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./waist-circumference.page */ 6232);
/* harmony import */ var src_app_shared_background_curves_background_curves_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/background-curves/background-curves.component */ 7199);








let WaistCircumferencePageModule = class WaistCircumferencePageModule {
};
WaistCircumferencePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _waist_circumference_routing_module__WEBPACK_IMPORTED_MODULE_0__.WaistCircumferencePageRoutingModule,
            src_app_shared_background_curves_background_curves_component__WEBPACK_IMPORTED_MODULE_2__.BackgroundCurvesComponentModule,
        ],
        declarations: [_waist_circumference_page__WEBPACK_IMPORTED_MODULE_1__.WaistCircumferencePage],
    })
], WaistCircumferencePageModule);



/***/ }),

/***/ 6232:
/*!****************************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/waist-circumference/waist-circumference.page.ts ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WaistCircumferencePage": () => (/* binding */ WaistCircumferencePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _waist_circumference_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./waist-circumference.page.html?ngResource */ 7510);
/* harmony import */ var _waist_circumference_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./waist-circumference.page.scss?ngResource */ 9870);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 3910);
/* harmony import */ var src_app_services_user_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/user-data.service */ 5944);







let WaistCircumferencePage = class WaistCircumferencePage {
    constructor(userDataService, router, activatedRoute) {
        this.userDataService = userDataService;
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.genderIsFemale = false;
        this.selectedUnit = 1;
        this.waistCircumference = null;
    }
    ngOnInit() {
        this.userDataService.currentUserData.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.take)(1)).subscribe((data) => {
            this.genderIsFemale = data.genderIsFemale;
        });
    }
    setWaistMeasurement() {
        const valueInInches = this.selectedUnit === 2
            ? this.waistCircumference
            : this.waistCircumference * 0.393700787;
        this.userDataService.updateUserData({
            waistCircumference: valueInInches,
        });
        if (this.genderIsFemale) {
            this.router.navigate(['../hip-measurements'], {
                relativeTo: this.activatedRoute,
            });
        }
        else {
            this.router.navigate(['../measurements-done'], {
                relativeTo: this.activatedRoute,
            });
        }
    }
    skipMeasurements() {
        this.router.navigate(['../measurements-done'], {
            relativeTo: this.activatedRoute,
        });
    }
};
WaistCircumferencePage.ctorParameters = () => [
    { type: src_app_services_user_data_service__WEBPACK_IMPORTED_MODULE_2__.UserDataService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute }
];
WaistCircumferencePage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-waist-circumference',
        template: _waist_circumference_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_waist_circumference_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], WaistCircumferencePage);



/***/ }),

/***/ 3005:
/*!**************************************************************************************!*\
  !*** ./src/app/shared/background-curves/background-curves.component.scss?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

module.exports = ".svg-waves-top,\n.svg-waves-bottom {\n  position: absolute;\n}\n\n.svg-waves-bottom {\n  bottom: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJhY2tncm91bmQtY3VydmVzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOztFQUVFLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxXQUFBO0FBQ0YiLCJmaWxlIjoiYmFja2dyb3VuZC1jdXJ2ZXMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc3ZnLXdhdmVzLXRvcCxcclxuLnN2Zy13YXZlcy1ib3R0b20ge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxufVxyXG5cclxuLnN2Zy13YXZlcy1ib3R0b20ge1xyXG4gIGJvdHRvbTogMHB4O1xyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 9870:
/*!*****************************************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/waist-circumference/waist-circumference.page.scss?ngResource ***!
  \*****************************************************************************************************************/
/***/ ((module) => {

module.exports = ".waist-header {\n  font-family: Teko-Light;\n  font-style: normal;\n  font-weight: 400;\n  font-size: 50px;\n  color: #efefef;\n  line-height: 40px;\n  text-transform: uppercase;\n  padding-top: 1rem;\n}\n\n.waist-button {\n  height: 3rem;\n  font-family: Roboto-Regular;\n  font-size: 16px;\n  --border-radius: 1rem;\n  margin: 0 1rem;\n}\n\n.small-text {\n  font-family: Roboto-Light;\n  font-size: 16px;\n  color: #005b74;\n}\n\nion-grid {\n  padding: 1rem 1rem;\n}\n\nion-content {\n  --ion-background-color: #efefef;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndhaXN0LWNpcmN1bWZlcmVuY2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsdUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLHlCQUFBO0VBQ0EsaUJBQUE7QUFDRjs7QUFFQTtFQUNFLFlBQUE7RUFDQSwyQkFBQTtFQUNBLGVBQUE7RUFDQSxxQkFBQTtFQUNBLGNBQUE7QUFDRjs7QUFFQTtFQUNFLHlCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFDRjs7QUFFQTtFQUNFLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSwrQkFBQTtBQUNGIiwiZmlsZSI6IndhaXN0LWNpcmN1bWZlcmVuY2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLndhaXN0LWhlYWRlciB7XHJcbiAgZm9udC1mYW1pbHk6IFRla28tTGlnaHQ7XHJcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgZm9udC1zaXplOiA1MHB4O1xyXG4gIGNvbG9yOiAjZWZlZmVmO1xyXG4gIGxpbmUtaGVpZ2h0OiA0MHB4O1xyXG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgcGFkZGluZy10b3A6IDFyZW07XHJcbn1cclxuXHJcbi53YWlzdC1idXR0b24ge1xyXG4gIGhlaWdodDogM3JlbTtcclxuICBmb250LWZhbWlseTogUm9ib3RvLVJlZ3VsYXI7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIC0tYm9yZGVyLXJhZGl1czogMXJlbTtcclxuICBtYXJnaW46IDAgMXJlbTtcclxufVxyXG5cclxuLnNtYWxsLXRleHQge1xyXG4gIGZvbnQtZmFtaWx5OiBSb2JvdG8tTGlnaHQ7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIGNvbG9yOiAjMDA1Yjc0O1xyXG59XHJcblxyXG5pb24tZ3JpZCB7XHJcbiAgcGFkZGluZzogMXJlbSAxcmVtO1xyXG59XHJcblxyXG5pb24tY29udGVudCB7XHJcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2VmZWZlZjtcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 3774:
/*!**************************************************************************************!*\
  !*** ./src/app/shared/background-curves/background-curves.component.html?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

module.exports = "<!-- Top Curves -->\n<svg class=\"svg-waves-top\" viewBox=\"0 0 880 550\">\n  <path\n    fill=\"#005b74\"\n    fill-opacity=\"1\"\n    d=\"M75.84.18h812.9V540.53S786.83,315.38,479.92,272.72,75.84.18,75.84.18Z\"\n  ></path>\n</svg>\n<svg class=\"svg-waves-top\" viewBox=\"0 0 880 550\">\n  <path\n    fill=\"#005b74\"\n    fill-opacity=\"0.78\"\n    d=\"M0,.18,888.88,0l1,354-1,187s-94.78-171.54-450-220S0,.18,0,.18Z\"\n  ></path>\n</svg>\n\n<!-- Bottom Curves -->\n<svg class=\"svg-waves-bottom\" viewBox=\"0 0 350 250\">\n  <path\n    fill=\"#005b74\"\n    fill-opacity=\"0.2\"\n    d=\"M342.17 251H-2.62975V119.782V26.0554C-2.62975 26.0554 40.5959 119.782 170.775 137.541C300.954 155.3 342.17 251 342.17 251Z\"\n  ></path>\n</svg>\n<svg class=\"svg-waves-bottom\" viewBox=\"0 0 350 250\">\n  <path\n    fill=\"#005b74\"\n    fill-opacity=\"0.2\"\n    d=\"M367.356 251H-20V104.583V6.19888e-06C-20 6.19888e-06 28.5607 104.583 174.808 124.399C321.054 144.215 367.356 251 367.356 251Z\"\n  ></path>\n</svg>\n";

/***/ }),

/***/ 7510:
/*!*****************************************************************************************************************!*\
  !*** ./src/app/starting-views/register/components/waist-circumference/waist-circumference.page.html?ngResource ***!
  \*****************************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <!-- Background Curves -->\n  <app-background-curves></app-background-curves>\n\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"12\" class=\"ion-text-end\">\n        <span class=\"waist-header\"\n          >waist <br />\n          circumference</span\n        >\n      </ion-col>\n    </ion-row>\n\n    <ion-row style=\"margin-top: 10vh\">\n      <ion-col size=\"12\" class=\"ion-text-center\">\n        <img\n          class=\"primary-image\"\n          [src]=\"genderIsFemale ? 'assets/images/female-waist.svg' : 'assets/images/waist.svg'\"\n          alt=\"measure-waist\"\n          style=\"height: 30vh\"\n        />\n      </ion-col>\n    </ion-row>\n\n    <ion-row style=\"margin-top: 2rem\">\n      <ion-col size=\"12\">\n        <ion-item>\n          <ion-label position=\"floating\"\n            >{{\"e.g. \" + (selectedUnit === 1 ? \"32.5 cm\" : \"12.7\n            inch\")}}</ion-label\n          >\n          <ion-input [(ngModel)]=\"waistCircumference\" type=\"number\"></ion-input>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size=\"12\" class=\"ion-text-center\">\n        <ion-radio-group\n          [(ngModel)]=\"selectedUnit\"\n          style=\"display: flex; justify-content: space-evenly\"\n        >\n          <ion-item lines=\"none\">\n            <ion-radio [value]=\"1\"></ion-radio>\n            <ion-label style=\"margin-left: 0.3rem\">cm</ion-label>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-radio [value]=\"2\"></ion-radio>\n            <ion-label style=\"margin-left: 0.3rem\">inches</ion-label>\n          </ion-item>\n        </ion-radio-group>\n      </ion-col>\n    </ion-row>\n\n    <ion-row style=\"margin-top: 1rem\">\n      <ion-col size=\"12\" class=\"ion-text-center\">\n        <ion-button\n          class=\"waist-button\"\n          color=\"primary\"\n          expand=\"block\"\n          (click)=\"setWaistMeasurement()\"\n          [disabled]=\"!waistCircumference\"\n          >NEXT</ion-button\n        >\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size=\"12\" class=\"ion-text-center small-text\">\n        <span routerLink=\"../measurements-done\">Skip this step</span>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_starting-views_register_components_waist-circumference_waist-circumference_module_ts.js.map