"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_starting-views_register_register_module_ts"],{

/***/ 201:
/*!********************************************************************!*\
  !*** ./src/app/starting-views/register/register-routing.module.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPageRoutingModule": () => (/* binding */ RegisterPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register.page */ 4574);




const routes = [
    {
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_0__.RegisterPage,
        children: [
            {
                path: 'sign-up',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_starting-views_register_components_sign-up-page_sign-up_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./components/sign-up-page/sign-up.module */ 8450)).then((m) => m.SignUpPageModule),
            },
            {
                path: 'choose-password',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_starting-views_register_components_choose-password_choose-password_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./components/choose-password/choose-password.module */ 1871)).then((m) => m.ChoosePasswordPageModule),
            },
            {
                path: 'gender-select',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_starting-views_register_components_gender-select_gender-select_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./components/gender-select/gender-select.module */ 6196)).then((m) => m.GenderSelectPageModule),
            },
            {
                path: 'height-select',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_pipes_convert-unit_pipe_ts-src_app_services_user-data_service_ts-src_app_shar-2d577b"), __webpack_require__.e("src_app_starting-views_register_components_height-select_height-select_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./components/height-select/height-select.module */ 4197)).then((m) => m.HeightSelectPageModule),
            },
            {
                path: 'weight-select',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_starting-views_register_components_weight-select_weight-select_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./components/weight-select/weight-select.module */ 5484)).then((m) => m.WeightSelectPageModule),
            },
            {
                path: 'age-select',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_pipes_convert-unit_pipe_ts-src_app_services_user-data_service_ts-src_app_shar-2d577b"), __webpack_require__.e("src_app_starting-views_register_components_age-select_age-select_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./components/age-select/age-select.module */ 9704)).then((m) => m.AgeSelectPageModule),
            },
            {
                path: 'active-level-select',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_starting-views_register_components_active-level-select_active-level-select_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./components/active-level-select/active-level-select.module */ 7644)).then((m) => m.ActiveLevelSelectPageModule),
            },
            {
                path: 'goal-select',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_starting-views_register_components_goal-select_goal-select_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./components/goal-select/goal-select.module */ 6947)).then((m) => m.GoalSelectPageModule),
            },
            {
                path: 'fat-percentage',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_starting-views_register_components_fat-percentage_fat-percentage_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./components/fat-percentage/fat-percentage.module */ 8108)).then((m) => m.FatPercentagePageModule),
            },
            {
                path: 'measurements-done',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_daily-data_service_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_starting-views_register_components_measurements-done_measurements-done_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./components/measurements-done/measurements-done.module */ 3528)).then((m) => m.MeasurementsDonePageModule),
            },
            {
                path: 'neck-measurements',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_starting-views_register_components_neck-measurements_neck-measurements_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./components/neck-measurements/neck-measurements.module */ 1426)).then((m) => m.NeckMeasurementsPageModule),
            },
            {
                path: 'waist-circumference',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_starting-views_register_components_waist-circumference_waist-circumference_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./components/waist-circumference/waist-circumference.module */ 7911)).then((m) => m.WaistCircumferencePageModule),
            },
            {
                path: 'hip-measurements',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_starting-views_register_components_hip-measurements_hip-measurements_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./components/hip-measurements/hip-measurements.module */ 5909)).then((m) => m.HipMeasurementsPageModule),
            },
            {
                path: '',
                redirectTo: 'sign-up',
                pathMatch: 'full',
            },
        ],
    },
    {
        path: '',
        redirectTo: 'sign-up',
        pathMatch: 'full',
    },
    {
        path: 'hip-measurements',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_starting-views_register_components_hip-measurements_hip-measurements_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./components/hip-measurements/hip-measurements.module */ 5909)).then((m) => m.HipMeasurementsPageModule),
    },
    {
        path: 'age-select',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_pipes_convert-unit_pipe_ts-src_app_services_user-data_service_ts-src_app_shar-2d577b"), __webpack_require__.e("src_app_starting-views_register_components_age-select_age-select_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./components/age-select/age-select.module */ 9704)).then((m) => m.AgeSelectPageModule),
    },
    {
        path: 'goal-select',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_starting-views_register_components_goal-select_goal-select_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./components/goal-select/goal-select.module */ 6947)).then((m) => m.GoalSelectPageModule),
    },
    {
        path: 'active-level-select',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_starting-views_register_components_active-level-select_active-level-select_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./components/active-level-select/active-level-select.module */ 7644)).then((m) => m.ActiveLevelSelectPageModule),
    },
];
let RegisterPageRoutingModule = class RegisterPageRoutingModule {
};
RegisterPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], RegisterPageRoutingModule);



/***/ }),

/***/ 8933:
/*!************************************************************!*\
  !*** ./src/app/starting-views/register/register.module.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPageModule": () => (/* binding */ RegisterPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _register_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register-routing.module */ 201);
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.page */ 4574);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 124);








let RegisterPageModule = class RegisterPageModule {
};
RegisterPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _register_routing_module__WEBPACK_IMPORTED_MODULE_0__.RegisterPageRoutingModule,
            _angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterModule,
        ],
        declarations: [_register_page__WEBPACK_IMPORTED_MODULE_1__.RegisterPage],
    })
], RegisterPageModule);



/***/ }),

/***/ 4574:
/*!**********************************************************!*\
  !*** ./src/app/starting-views/register/register.page.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPage": () => (/* binding */ RegisterPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _register_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register.page.html?ngResource */ 9162);
/* harmony import */ var _register_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.page.scss?ngResource */ 5460);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 2508);





let RegisterPage = class RegisterPage {
    constructor(fb) {
        this.fb = fb;
    }
    ngOnInit() {
        this.registerForm = this.fb.group({
            firstName: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]],
            lastName: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]],
            email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.email]],
        });
    }
};
RegisterPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder }
];
RegisterPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-register',
        template: _register_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_register_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], RegisterPage);



/***/ }),

/***/ 5460:
/*!***********************************************************************!*\
  !*** ./src/app/starting-views/register/register.page.scss?ngResource ***!
  \***********************************************************************/
/***/ ((module) => {

module.exports = ".register-header {\n  font-family: Teko-Light;\n  font-style: normal;\n  font-weight: 400;\n  font-size: 50px;\n  color: #efefef;\n  line-height: 20px;\n}\n\n.register-subheader {\n  font-family: Roboto-Light;\n  font-style: normal;\n  font-weight: 400;\n  font-size: 16px;\n  line-height: 42px;\n  color: #efefef;\n  line-height: 10px;\n}\n\n.register-button {\n  height: 3rem;\n  font-family: Roboto-Medium;\n  font-size: 16px;\n  --border-radius: 1rem;\n  margin-top: 13rem;\n}\n\n.go-to-login {\n  font-family: Roboto-Light;\n  color: #828282;\n  font-size: 14px;\n}\n\n.login-btn {\n  font-family: Roboto-Bold;\n  color: #efefef;\n  font-size: 14px;\n  margin-left: 0.3rem;\n}\n\nion-content {\n  --ion-background-color: #005b74;\n}\n\nion-grid {\n  margin-top: 5rem;\n  padding: 2rem;\n}\n\nion-item {\n  border-bottom: 1px solid #828282 !important;\n}\n\nion-item.item-has-focus {\n  border-bottom: 1px solid #efefef !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlZ2lzdGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHVCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUFDRjs7QUFFQTtFQUNFLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQUNGOztBQUVBO0VBQ0UsWUFBQTtFQUNBLDBCQUFBO0VBQ0EsZUFBQTtFQUNBLHFCQUFBO0VBQ0EsaUJBQUE7QUFDRjs7QUFFQTtFQUNFLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7QUFDRjs7QUFFQTtFQUNFLHdCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtBQUNGOztBQUVBO0VBQ0UsK0JBQUE7QUFDRjs7QUFFQTtFQUNFLGdCQUFBO0VBQ0EsYUFBQTtBQUNGOztBQUVBO0VBQ0UsMkNBQUE7QUFDRjs7QUFBRTtFQUNFLDJDQUFBO0FBRUoiLCJmaWxlIjoicmVnaXN0ZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnJlZ2lzdGVyLWhlYWRlciB7XHJcbiAgZm9udC1mYW1pbHk6IFRla28tTGlnaHQ7XHJcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgZm9udC1zaXplOiA1MHB4O1xyXG4gIGNvbG9yOiAjZWZlZmVmO1xyXG4gIGxpbmUtaGVpZ2h0OiAyMHB4O1xyXG59XHJcblxyXG4ucmVnaXN0ZXItc3ViaGVhZGVyIHtcclxuICBmb250LWZhbWlseTogUm9ib3RvLUxpZ2h0O1xyXG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICBmb250LXdlaWdodDogNDAwO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBsaW5lLWhlaWdodDogNDJweDtcclxuICBjb2xvcjogI2VmZWZlZjtcclxuICBsaW5lLWhlaWdodDogMTBweDtcclxufVxyXG5cclxuLnJlZ2lzdGVyLWJ1dHRvbiB7XHJcbiAgaGVpZ2h0OiAzcmVtO1xyXG4gIGZvbnQtZmFtaWx5OiBSb2JvdG8tTWVkaXVtO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICAtLWJvcmRlci1yYWRpdXM6IDFyZW07XHJcbiAgbWFyZ2luLXRvcDogMTNyZW07XHJcbn1cclxuXHJcbi5nby10by1sb2dpbiB7XHJcbiAgZm9udC1mYW1pbHk6IFJvYm90by1MaWdodDtcclxuICBjb2xvcjogIzgyODI4MjtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbn1cclxuXHJcbi5sb2dpbi1idG4ge1xyXG4gIGZvbnQtZmFtaWx5OiBSb2JvdG8tQm9sZDtcclxuICBjb2xvcjogI2VmZWZlZjtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDAuM3JlbTtcclxufVxyXG5cclxuaW9uLWNvbnRlbnQge1xyXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICMwMDViNzQ7XHJcbn1cclxuXHJcbmlvbi1ncmlkIHtcclxuICBtYXJnaW4tdG9wOiA1cmVtO1xyXG4gIHBhZGRpbmc6IDJyZW07XHJcbn1cclxuXHJcbmlvbi1pdGVtIHtcclxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgIzgyODI4MiAhaW1wb3J0YW50O1xyXG4gICYuaXRlbS1oYXMtZm9jdXMge1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlZmVmZWYgIWltcG9ydGFudDtcclxuICB9XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 9162:
/*!***********************************************************************!*\
  !*** ./src/app/starting-views/register/register.page.html?ngResource ***!
  \***********************************************************************/
/***/ ((module) => {

module.exports = "<ion-router-outlet></ion-router-outlet>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_starting-views_register_register_module_ts.js.map