"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab1_tab1_module_ts"],{

/***/ 2580:
/*!*********************************************!*\
  !*** ./src/app/tab1/tab1-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab1PageRoutingModule": () => (/* binding */ Tab1PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab1.page */ 6923);




const routes = [
    {
        path: '',
        component: _tab1_page__WEBPACK_IMPORTED_MODULE_0__.Tab1Page,
    }
];
let Tab1PageRoutingModule = class Tab1PageRoutingModule {
};
Tab1PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], Tab1PageRoutingModule);



/***/ }),

/***/ 2168:
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab1PageModule": () => (/* binding */ Tab1PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab1.page */ 6923);
/* harmony import */ var _tab1_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab1-routing.module */ 2580);
/* harmony import */ var angular_svg_round_progressbar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! angular-svg-round-progressbar */ 8841);








let Tab1PageModule = class Tab1PageModule {
};
Tab1PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _tab1_routing_module__WEBPACK_IMPORTED_MODULE_1__.Tab1PageRoutingModule,
            angular_svg_round_progressbar__WEBPACK_IMPORTED_MODULE_7__.RoundProgressModule,
        ],
        declarations: [_tab1_page__WEBPACK_IMPORTED_MODULE_0__.Tab1Page],
    })
], Tab1PageModule);



/***/ }),

/***/ 6923:
/*!***********************************!*\
  !*** ./src/app/tab1/tab1.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab1Page": () => (/* binding */ Tab1Page)
/* harmony export */ });
/* harmony import */ var D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _tab1_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab1.page.html?ngResource */ 3852);
/* harmony import */ var _tab1_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tab1.page.scss?ngResource */ 8165);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/auth.service */ 7556);
/* harmony import */ var _services_daily_data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/daily-data.service */ 5268);
/* harmony import */ var _services_food_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/food.service */ 9785);
/* harmony import */ var _services_workout_data_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/workout-data.service */ 7026);











let Tab1Page = class Tab1Page {
  constructor(authService, router, dailyDataService, alertController, foodService, workoutDataService) {
    this.authService = authService;
    this.router = router;
    this.dailyDataService = dailyDataService;
    this.alertController = alertController;
    this.foodService = foodService;
    this.workoutDataService = workoutDataService;
    this.meals = null;
    this.workouts = null;
    this.currentKcal = 0;
    this.totalKcal = 1;
    this.currentProtein = 0;
    this.totalProtein = 1;
    this.currentFats = 0;
    this.totalFats = 1;
    this.currentCarbs = 0;
    this.totalCarbs = 1;
    this.stroke = 9;
    this.strokeMacro = 12;
    this.radius = 125;
    this.responsive = true;
    this.clockwise = true;
    this.color = '#005B74';
    this.background = '#CEE0E5';
    this.duration = 1500;
    this.animation = 'easeOutCubic';
    this.animationDelay = 0;
    this.realCurrent = 0;
    this.currentDate = null;
    this.timeoutHandler = null;
    this.count = 0;
  }

  ionViewWillEnter() {
    this.getAllData();
  }

  getOverlayStyle(textSize) {
    const transform = 'translateY(-50%) ' + 'translateX(-50%)';
    return {
      top: '50%',
      bottom: 'auto',
      left: '50%',
      transform,
      fontSize: textSize + 'px'
    };
  }

  getDietData() {
    var _this = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const data = yield _this.dailyDataService.getDietData();
      _this.totalKcal = data.totalKcal;
      _this.totalProtein = data.totalProtein;
      _this.totalFats = data.totalFats;
      _this.totalCarbs = data.totalCarbs;
    })();
  }

  getTodaysData() {
    var _this2 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        yield _this2.dailyDataService.getTodaysData().then(data => {
          _this2.currentKcal = data.totalKcal;
          _this2.currentProtein = data.totalProtein;
          _this2.currentFats = data.totalFats;
          _this2.currentCarbs = data.totalCarbs;
        });
      } catch {
        _this2.dailyDataService.instantCreateNewDayDocument();

        _this2.getTodaysData();
      }
    })();
  }

  getTodaysMeals() {
    var _this3 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.meals = yield _this3.dailyDataService.getTodaysMeals();
    })();
  }

  getTodaysWorkouts() {
    var _this4 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this4.workouts = yield _this4.dailyDataService.getTodaysWorkouts();
    })();
  }

  getAllData() {
    this.getDietData();
    this.getTodaysData();
    this.getTodaysMeals();
    this.getTodaysWorkouts();
  }

  removeMealFromList(meal) {
    var _this5 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      delete meal.inputData;
      console.log(meal);
      yield _this5.foodService.removeMeal(meal);

      _this5.getAllData();
    })();
  }

  removeWorkoutFromList(workout) {
    var _this6 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      delete workout.inputData;
      console.log(workout);
      yield _this6.workoutDataService.removeWorkout(workout);

      _this6.getAllData();
    })();
  }

  confirmDeleteMeal(meal) {
    var _this7 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this7.alertController.create({
        header: 'Are you sure?',
        message: 'Remove ' + meal.name + ' from list',
        buttons: [{
          text: 'Cancel',
          role: 'cancel',
          handler: () => {}
        }, {
          text: 'OK',
          role: 'confirm',
          handler: () => {
            _this7.removeMealFromList(meal);
          }
        }]
      });
      yield alert.present();
    })();
  }

  confirmDeleteWorkout(workout) {
    var _this8 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this8.alertController.create({
        header: 'Are you sure?',
        message: 'Remove ' + workout.bodyPart + ' workout from list',
        buttons: [{
          text: 'Cancel',
          role: 'cancel',
          handler: () => {}
        }, {
          text: 'OK',
          role: 'confirm',
          handler: () => {
            _this8.removeWorkoutFromList(workout);
          }
        }]
      });
      yield alert.present();
    })();
  }

};

Tab1Page.ctorParameters = () => [{
  type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router
}, {
  type: _services_daily_data_service__WEBPACK_IMPORTED_MODULE_4__.DailyDataService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.AlertController
}, {
  type: _services_food_service__WEBPACK_IMPORTED_MODULE_5__.FoodService
}, {
  type: _services_workout_data_service__WEBPACK_IMPORTED_MODULE_6__.WorkoutDataService
}];

Tab1Page = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
  selector: 'app-tab1',
  template: _tab1_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_tab1_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], Tab1Page);


/***/ }),

/***/ 8165:
/*!************************************************!*\
  !*** ./src/app/tab1/tab1.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = ".current {\n  position: absolute;\n  font-weight: 400;\n  line-height: 1;\n  text-align: center;\n  color: #005b74;\n  z-index: 2;\n}\n\n.kcal-circle-wrapper {\n  padding: 0 4rem;\n  margin-top: 4rem;\n  margin-bottom: 2rem;\n}\n\n.kcal-circle {\n  background-color: #efefef;\n  border-radius: 100%;\n}\n\n.workout-panel {\n  background-color: #efefef;\n  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);\n  border-radius: 10px;\n  min-height: 6rem;\n  padding: 1rem 1.5rem;\n}\n\n.workout-panel .workout-panel-header {\n  font-size: 20px;\n  font-family: RobotoCondensed-Regular;\n  color: #005b74;\n}\n\n.workout-panel .no-workouts {\n  margin-left: 1rem;\n  font-size: 20px;\n  font-family: RobotoCondensed-Light;\n  color: #676767;\n}\n\n.workout-panel ion-button {\n  margin-top: 1rem;\n  height: 2.5rem;\n  font-family: RobotoCondensed-Regular;\n  font-size: 16px;\n  --border-radius: 1rem;\n  text-transform: capitalize;\n}\n\n.meals-panel {\n  background-color: #efefef;\n  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);\n  border-radius: 10px;\n  min-height: 6rem;\n  padding: 1rem 1.5rem;\n}\n\n.meals-panel .meals-panel-header {\n  font-size: 20px;\n  font-family: RobotoCondensed-Regular;\n  color: #005b74;\n}\n\n.meals-panel .no-meals {\n  margin-left: 1rem;\n  font-size: 20px;\n  font-family: RobotoCondensed-Light;\n  color: #676767;\n}\n\n.meals-panel ion-button {\n  margin-top: 1rem;\n  height: 2.5rem;\n  font-family: RobotoCondensed-Regular;\n  font-size: 16px;\n  --border-radius: 1rem;\n  text-transform: capitalize;\n}\n\nion-content {\n  --ion-background-color: #cee0e5;\n  --padding-bottom: 1.5rem !important;\n}\n\nion-list {\n  max-height: 10rem;\n  overflow-y: scroll;\n  background-color: #efefef;\n}\n\nion-card {\n  box-shadow: none !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhYjEucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxVQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtBQUNGOztBQUVBO0VBQ0UseUJBQUE7RUFDQSxtQkFBQTtBQUNGOztBQUVBO0VBQ0UseUJBQUE7RUFDQSwyQ0FBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxvQkFBQTtBQUNGOztBQUNFO0VBQ0UsZUFBQTtFQUNBLG9DQUFBO0VBQ0EsY0FBQTtBQUNKOztBQUVFO0VBQ0UsaUJBQUE7RUFDQSxlQUFBO0VBQ0Esa0NBQUE7RUFDQSxjQUFBO0FBQUo7O0FBR0U7RUFDRSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxvQ0FBQTtFQUNBLGVBQUE7RUFDQSxxQkFBQTtFQUNBLDBCQUFBO0FBREo7O0FBS0E7RUFDRSx5QkFBQTtFQUNBLDJDQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLG9CQUFBO0FBRkY7O0FBSUU7RUFDRSxlQUFBO0VBQ0Esb0NBQUE7RUFDQSxjQUFBO0FBRko7O0FBS0U7RUFDRSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxrQ0FBQTtFQUNBLGNBQUE7QUFISjs7QUFNRTtFQUNFLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLG9DQUFBO0VBQ0EsZUFBQTtFQUNBLHFCQUFBO0VBQ0EsMEJBQUE7QUFKSjs7QUFRQTtFQUNFLCtCQUFBO0VBQ0EsbUNBQUE7QUFMRjs7QUFRQTtFQUNFLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtBQUxGOztBQVFBO0VBQ0UsMkJBQUE7QUFMRiIsImZpbGUiOiJ0YWIxLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jdXJyZW50IHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICBsaW5lLWhlaWdodDogMTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgY29sb3I6ICMwMDViNzQ7XHJcbiAgei1pbmRleDogMjtcclxufVxyXG5cclxuLmtjYWwtY2lyY2xlLXdyYXBwZXIge1xyXG4gIHBhZGRpbmc6IDAgNHJlbTtcclxuICBtYXJnaW4tdG9wOiA0cmVtO1xyXG4gIG1hcmdpbi1ib3R0b206IDJyZW07XHJcbn1cclxuXHJcbi5rY2FsLWNpcmNsZSB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2VmZWZlZjtcclxuICBib3JkZXItcmFkaXVzOiAxMDAlO1xyXG59XHJcblxyXG4ud29ya291dC1wYW5lbCB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2VmZWZlZjtcclxuICBib3gtc2hhZG93OiAwcHggNHB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMjUpO1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgbWluLWhlaWdodDogNnJlbTtcclxuICBwYWRkaW5nOiAxcmVtIDEuNXJlbTtcclxuXHJcbiAgJiAud29ya291dC1wYW5lbC1oZWFkZXIge1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgZm9udC1mYW1pbHk6IFJvYm90b0NvbmRlbnNlZC1SZWd1bGFyO1xyXG4gICAgY29sb3I6ICMwMDViNzQ7XHJcbiAgfVxyXG5cclxuICAmIC5uby13b3Jrb3V0cyB7XHJcbiAgICBtYXJnaW4tbGVmdDogMXJlbTtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGZvbnQtZmFtaWx5OiBSb2JvdG9Db25kZW5zZWQtTGlnaHQ7XHJcbiAgICBjb2xvcjogIzY3Njc2NztcclxuICB9XHJcblxyXG4gICYgaW9uLWJ1dHRvbiB7XHJcbiAgICBtYXJnaW4tdG9wOiAxcmVtO1xyXG4gICAgaGVpZ2h0OiAyLjVyZW07XHJcbiAgICBmb250LWZhbWlseTogUm9ib3RvQ29uZGVuc2VkLVJlZ3VsYXI7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAtLWJvcmRlci1yYWRpdXM6IDFyZW07XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogY2FwaXRhbGl6ZTtcclxuICB9XHJcbn1cclxuXHJcbi5tZWFscy1wYW5lbCB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2VmZWZlZjtcclxuICBib3gtc2hhZG93OiAwcHggNHB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMjUpO1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgbWluLWhlaWdodDogNnJlbTtcclxuICBwYWRkaW5nOiAxcmVtIDEuNXJlbTtcclxuXHJcbiAgJiAubWVhbHMtcGFuZWwtaGVhZGVyIHtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGZvbnQtZmFtaWx5OiBSb2JvdG9Db25kZW5zZWQtUmVndWxhcjtcclxuICAgIGNvbG9yOiAjMDA1Yjc0O1xyXG4gIH1cclxuXHJcbiAgJiAubm8tbWVhbHMge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDFyZW07XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICBmb250LWZhbWlseTogUm9ib3RvQ29uZGVuc2VkLUxpZ2h0O1xyXG4gICAgY29sb3I6ICM2NzY3Njc7XHJcbiAgfVxyXG5cclxuICAmIGlvbi1idXR0b24ge1xyXG4gICAgbWFyZ2luLXRvcDogMXJlbTtcclxuICAgIGhlaWdodDogMi41cmVtO1xyXG4gICAgZm9udC1mYW1pbHk6IFJvYm90b0NvbmRlbnNlZC1SZWd1bGFyO1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgLS1ib3JkZXItcmFkaXVzOiAxcmVtO1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XHJcbiAgfVxyXG59XHJcblxyXG5pb24tY29udGVudCB7XHJcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2NlZTBlNTtcclxuICAtLXBhZGRpbmctYm90dG9tOiAxLjVyZW0gIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWxpc3Qge1xyXG4gIG1heC1oZWlnaHQ6IDEwcmVtO1xyXG4gIG92ZXJmbG93LXk6IHNjcm9sbDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWZlZmVmO1xyXG59XHJcblxyXG5pb24tY2FyZCB7XHJcbiAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 3852:
/*!************************************************!*\
  !*** ./src/app/tab1/tab1.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-content [fullscreen]=\"true\">\n  <!-- Calories Circle -->\n  <ion-row>\n    <ion-col size=\"12\" class=\"kcal-circle-wrapper\">\n      <div class=\"current\" [ngStyle]=\"getOverlayStyle(45)\">\n        {{ currentKcal }}\n        <span style=\"font-size: 20px; margin-left: -0.5rem\">kcal</span>\n      </div>\n      <round-progress\n        class=\"kcal-circle\"\n        [current]=\"currentKcal\"\n        [max]=\"totalKcal\"\n        [color]=\"color\"\n        [background]=\"background\"\n        [radius]=\"radius\"\n        [stroke]=\"stroke\"\n        [clockwise]=\"clockwise\"\n        [responsive]=\"responsive\"\n        [duration]=\"duration\"\n        [animation]=\"animation\"\n        [animationDelay]=\"animationDelay\"\n      ></round-progress>\n    </ion-col>\n  </ion-row>\n\n  <!-- ///////////////////////////////////////// -->\n\n  <!-- Macronutrients Row -->\n  <ion-row style=\"padding: 0 0.5rem\">\n    <!-- Protein Circle -->\n    <ion-col size=\"4\">\n      <div class=\"current\" [ngStyle]=\"getOverlayStyle(22)\">\n        {{ currentProtein }}\n        <span style=\"font-size: 14px; margin-left: -0.3rem\">g protein</span>\n      </div>\n      <round-progress\n        class=\"kcal-circle\"\n        [current]=\"currentProtein\"\n        [max]=\"totalProtein\"\n        [color]=\"color\"\n        [background]=\"background\"\n        [radius]=\"radius\"\n        [stroke]=\"strokeMacro\"\n        [clockwise]=\"clockwise\"\n        [responsive]=\"responsive\"\n        [duration]=\"duration\"\n        [animation]=\"animation\"\n        [animationDelay]=\"animationDelay\"\n      ></round-progress>\n    </ion-col>\n\n    <!-- Fats Circle -->\n    <ion-col size=\"4\">\n      <div class=\"current\" [ngStyle]=\"getOverlayStyle(22)\">\n        {{ currentFats }}\n        <span style=\"font-size: 14px; margin-left: -0.3rem\"\n          >g <br />\n          fats</span\n        >\n      </div>\n      <round-progress\n        class=\"kcal-circle\"\n        [current]=\"currentFats\"\n        [max]=\"totalFats\"\n        [color]=\"color\"\n        [background]=\"background\"\n        [radius]=\"radius\"\n        [stroke]=\"strokeMacro\"\n        [clockwise]=\"clockwise\"\n        [responsive]=\"responsive\"\n        [duration]=\"duration\"\n        [animation]=\"animation\"\n        [animationDelay]=\"animationDelay\"\n      ></round-progress>\n    </ion-col>\n\n    <!-- Carbs Circle -->\n    <ion-col size=\"4\">\n      <div class=\"current\" [ngStyle]=\"getOverlayStyle(22)\">\n        {{ currentCarbs }}\n        <span style=\"font-size: 14px; margin-left: -0.3rem\"\n          >g <br />\n          carbs</span\n        >\n      </div>\n      <round-progress\n        class=\"kcal-circle\"\n        [current]=\"currentCarbs\"\n        [max]=\"totalCarbs\"\n        [color]=\"color\"\n        [background]=\"background\"\n        [radius]=\"radius\"\n        [stroke]=\"strokeMacro\"\n        [clockwise]=\"clockwise\"\n        [responsive]=\"responsive\"\n        [duration]=\"duration\"\n        [animation]=\"animation\"\n        [animationDelay]=\"animationDelay\"\n      ></round-progress>\n    </ion-col>\n  </ion-row>\n\n  <ion-row style=\"margin-top: 2rem; padding: 0 0.5rem\">\n    <ion-col size=\"12\">\n      <div class=\"workout-panel\">\n        <span class=\"workout-panel-header\">Workouts:</span>\n        <span *ngIf=\"!workouts || workouts.length === 0\" class=\"no-workouts\">\n          No workouts today</span\n        >\n        <ion-card *ngIf=\"workouts && workouts.length > 0\">\n          <ion-list>\n            <ion-item *ngFor=\"let workout of workouts\">\n              <label style=\"text-transform: capitalize\"\n                >{{workout.bodyPart}}</label\n              >\n              <label style=\"position: absolute; right: 2rem\"\n                >{{workout.time + ' min'}}</label\n              >\n              <ion-icon\n                style=\"position: absolute; right: 0\"\n                name=\"trash-outline\"\n                (click)=\"confirmDeleteWorkout(workout)\"\n              ></ion-icon>\n            </ion-item>\n          </ion-list>\n        </ion-card>\n        <ion-button\n          class=\"workout-panel-button\"\n          color=\"primary\"\n          expand=\"block\"\n          routerLink=\"../workout\"\n          >Workout now!</ion-button\n        >\n      </div>\n    </ion-col>\n  </ion-row>\n\n  <ion-row style=\"margin-top: 1rem; padding: 0 0.5rem\">\n    <ion-col size=\"12\">\n      <div class=\"meals-panel\">\n        <span class=\"meals-panel-header\">What you ate today:</span>\n        <span *ngIf=\"!meals || meals.length === 0\" class=\"no-meals\">\n          No meals yet</span\n        >\n        <ion-card *ngIf=\"meals && meals.length > 0\">\n          <ion-list>\n            <ion-item *ngFor=\"let meal of meals\">\n              <label>{{meal.name}}</label>\n              <label style=\"position: absolute; right: 2rem\"\n                >{{meal.kcal + ' kcal'}}</label\n              >\n              <ion-icon\n                style=\"position: absolute; right: 0\"\n                name=\"trash-outline\"\n                (click)=\"confirmDeleteMeal(meal)\"\n              ></ion-icon>\n            </ion-item>\n          </ion-list>\n        </ion-card>\n        <ion-button\n          class=\"meals-panel-button\"\n          color=\"primary\"\n          expand=\"block\"\n          routerLink=\"../nutrition\"\n          >Click to add meal</ion-button\n        >\n      </div>\n    </ion-col>\n  </ion-row>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab1_tab1_module_ts.js.map