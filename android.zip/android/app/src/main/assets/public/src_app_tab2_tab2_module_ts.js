"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab2_tab2_module_ts"],{

/***/ 7026:
/*!**************************************************!*\
  !*** ./src/app/services/workout-data.service.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WorkoutDataService": () => (/* binding */ WorkoutDataService)
/* harmony export */ });
/* harmony import */ var D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/fire/auth */ 1577);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire/firestore */ 6466);
/* harmony import */ var _daily_data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./daily-data.service */ 5268);






let WorkoutDataService = class WorkoutDataService {
  constructor(firestore, dailyDataService, auth) {
    this.firestore = firestore;
    this.dailyDataService = dailyDataService;
    this.auth = auth;
  } // async addItemsToDatabase() {
  //   const workoutDataRef = doc(this.firestore, `workout-data/exercises`);
  //   const exercises = workouts.exercises;
  //   let uploadedData = {};
  //   uploadedData['abs'] = exercises.abs;
  //   uploadedData['chest'] = exercises.chest;
  //   uploadedData['legs'] = exercises.legs;
  //   uploadedData['arms'] = exercises.arms;
  //   updateDoc(workoutDataRef, uploadedData);
  //   const dailyWorkoutsRef = doc(this.firestore, `workout-data/daily-workouts`);
  //   const dailyWorkouts = workouts.dailyWorkouts;
  //   let _uploadedData = {};
  //   _uploadedData['abs'] = dailyWorkouts.abs;
  //   _uploadedData['chest'] = dailyWorkouts.chest;
  //   _uploadedData['legs'] = dailyWorkouts.legs;
  //   _uploadedData['arms'] = dailyWorkouts.arms;
  //   // uploadedData['chest'] = exercises.chest;
  //   updateDoc(dailyWorkoutsRef, _uploadedData);
  // }


  getExercisesList() {
    var _this = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const workoutDataRef = (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.doc)(_this.firestore, `workout-data/exercises`);
      const result = yield (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.getDoc)(workoutDataRef);
      return result.data();
    })();
  }

  getDailyWorkouts() {
    var _this2 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const dailyWorkoutsRef = (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.doc)(_this2.firestore, `workout-data/daily-workouts`);
      const result = yield (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.getDoc)(dailyWorkoutsRef);
      return result.data();
    })();
  }

  addWorkout(item) {
    var _this3 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const currentDate = _this3.dailyDataService.getCurrentDate();

      const user = _this3.auth.currentUser;
      const docRef = (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.doc)(_this3.firestore, `daily-data/${user.uid}`);
      let currentKcal;
      let currentProtein;
      let currentCarbs;
      let currentFats;
      let weight;
      let meals = [];
      let workouts = [];

      try {
        yield _this3.dailyDataService.getTodaysData().then(data => {
          currentKcal = data.totalKcal;
          currentProtein = data.totalProtein;
          currentFats = data.totalFats;
          currentCarbs = data.totalCarbs;
          weight = data.weight;
          meals = data.meals;
          workouts = data.workouts;
        });
      } catch {
        _this3.dailyDataService.instantCreateNewDayDocument();

        _this3.dailyDataService.getTodaysData();
      }

      workouts.push({ ...item
      });
      let todayData = {};
      todayData[currentDate] = {
        totalKcal: currentKcal,
        totalCarbs: currentCarbs,
        totalProtein: currentProtein,
        totalFats: currentFats,
        weight: weight,
        meals: meals,
        workouts: workouts
      };
      (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.updateDoc)(docRef, todayData);
    })();
  }

  removeWorkout(item) {
    var _this4 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const currentDate = _this4.dailyDataService.getCurrentDate();

      const user = _this4.auth.currentUser;
      const docRef = (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.doc)(_this4.firestore, `daily-data/${user.uid}`);
      let currentKcal;
      let currentProtein;
      let currentCarbs;
      let currentFats;
      let weight;
      let meals = [];
      let workouts = [];

      try {
        yield _this4.dailyDataService.getTodaysData().then(data => {
          currentKcal = data.totalKcal;
          currentProtein = data.totalProtein;
          currentFats = data.totalFats;
          currentCarbs = data.totalCarbs;
          weight = data.weight;
          meals = data.meals;
          workouts = data.workouts;
        });
      } catch {
        _this4.dailyDataService.instantCreateNewDayDocument();

        _this4.dailyDataService.getTodaysData();
      }

      console.log('before', workouts);
      let indexForRemoval;
      workouts.forEach((workout, index) => {
        if (workout.bodyPart === item.bodyPart && workout.time === item.time && workout.exercisesNr === item.exercisesNr) {
          indexForRemoval = index;
        }
      });
      workouts.splice(indexForRemoval, 1);
      console.log('after', workouts);
      let todayData = {};
      todayData[currentDate] = {
        totalKcal: currentKcal,
        totalCarbs: currentCarbs,
        totalProtein: currentProtein,
        totalFats: currentFats,
        weight: weight,
        meals: meals,
        workouts: workouts
      };
      (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.updateDoc)(docRef, todayData);
    })();
  }

  setDayAsCompleted(dayNumber, bodyPart) {
    var _this5 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const dailyWorkoutsRef = (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.doc)(_this5.firestore, `workout-data/daily-workouts`);
      const result = yield (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.getDoc)(dailyWorkoutsRef);
      let dailyWorkoutInfo = result.data();
      dailyWorkoutInfo[bodyPart][dayNumber].completed = true;
      console.log(dailyWorkoutInfo);
      (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.updateDoc)(dailyWorkoutsRef, dailyWorkoutInfo);
    })();
  }

};

WorkoutDataService.ctorParameters = () => [{
  type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__.Firestore
}, {
  type: _daily_data_service__WEBPACK_IMPORTED_MODULE_1__.DailyDataService
}, {
  type: _angular_fire_auth__WEBPACK_IMPORTED_MODULE_3__.Auth
}];

WorkoutDataService = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
  providedIn: 'root'
})], WorkoutDataService);


/***/ }),

/***/ 3092:
/*!*********************************************!*\
  !*** ./src/app/tab2/tab2-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab2PageRoutingModule": () => (/* binding */ Tab2PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _tab2_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab2.page */ 442);




const routes = [
    {
        path: '',
        component: _tab2_page__WEBPACK_IMPORTED_MODULE_0__.Tab2Page,
    }
];
let Tab2PageRoutingModule = class Tab2PageRoutingModule {
};
Tab2PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], Tab2PageRoutingModule);



/***/ }),

/***/ 4608:
/*!*************************************!*\
  !*** ./src/app/tab2/tab2.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab2PageModule": () => (/* binding */ Tab2PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _tab2_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab2.page */ 442);
/* harmony import */ var _tab2_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab2-routing.module */ 3092);







let Tab2PageModule = class Tab2PageModule {
};
Tab2PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule, _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule, _tab2_routing_module__WEBPACK_IMPORTED_MODULE_1__.Tab2PageRoutingModule],
        declarations: [_tab2_page__WEBPACK_IMPORTED_MODULE_0__.Tab2Page],
    })
], Tab2PageModule);



/***/ }),

/***/ 442:
/*!***********************************!*\
  !*** ./src/app/tab2/tab2.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab2Page": () => (/* binding */ Tab2Page)
/* harmony export */ });
/* harmony import */ var D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _tab2_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab2.page.html?ngResource */ 1748);
/* harmony import */ var _tab2_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tab2.page.scss?ngResource */ 1597);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _services_workout_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/workout-data.service */ 7026);
/* harmony import */ var _services_workout_state_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/workout-state.service */ 674);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);









let Tab2Page = class Tab2Page {
  constructor(loadingController, workoutDataService, router, workoutState) {
    this.loadingController = loadingController;
    this.workoutDataService = workoutDataService;
    this.router = router;
    this.workoutState = workoutState;
    this.isModalOpen = false;
    this.isDailyRoutineSummaryOpen = false;
    this.exercisesList = null;
    this.dailyWorkouts = null;
    this.displayedTitle = null;
    this.selectedTab = null;
    this.selectedDay = null;
    this.todayWorkout = null;
    this.workoutEstimatedTime = null;
    this.numberOfDays = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30]; // this.workoutDataService.addItemsToDatabase();
  }

  ngOnInit() {
    this.loadAllData();
  }

  loadAllData() {
    var _this = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const loading = yield _this.loadingController.create({
        showBackdrop: false,
        cssClass: 'custom-loading'
      });
      yield loading.present();
      yield _this.getExercisesList();
      yield _this.getDailyWorkouts();
      yield loading.dismiss();
    })();
  }

  openModal(bodyPart) {
    this.isModalOpen = true;
    this.selectedTab = bodyPart;
    this.displayedTitle = bodyPart + ' Workout';
  }

  closeSelectDayModal() {
    this.isModalOpen = false;
  }

  openDailyRoutineModal(dayNumber) {
    this.isDailyRoutineSummaryOpen = true;
    this.selectedDay = dayNumber;
    this.todayWorkout = this.dailyWorkouts[this.selectedTab][this.selectedDay - 1].exercises;
    this.todayWorkout = this.todayWorkout.map(index => this.exercisesList[this.selectedTab][index]);
    this.todayWorkout = this.todayWorkout.map(exercise => {
      return { ...exercise,
        totalReps: Math.floor(exercise.initialReps * ((9 + this.selectedDay) / 10))
      };
    });
    let workoutTotalReps = 0;
    this.todayWorkout.forEach(exercise => {
      workoutTotalReps += exercise.totalReps;
    });
    this.todayWorkout = this.todayWorkout.concat(this.todayWorkout); // nr of total reps * 4sec + (nr of exercises * 30 sec pause)

    this.workoutEstimatedTime = workoutTotalReps * 4 + this.todayWorkout.length * 30;
    this.workoutEstimatedTime = Math.ceil(this.workoutEstimatedTime / 60);
    console.log(this.todayWorkout);
  }

  closeDailyRoutineModal() {
    this.isDailyRoutineSummaryOpen = false;
  }

  getExercisesList() {
    var _this2 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.exercisesList = yield _this2.workoutDataService.getExercisesList();
      console.log(_this2.exercisesList);
    })();
  }

  getDailyWorkouts() {
    var _this3 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.dailyWorkouts = yield _this3.workoutDataService.getDailyWorkouts();
      console.log(_this3.dailyWorkouts);
    })();
  }

  startFullWorkoutFlow() {
    var _this4 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const loading = yield _this4.loadingController.create({
        showBackdrop: false,
        cssClass: 'custom-loading'
      });
      yield loading.present();
      yield _this4.closeSelectDayModal();
      yield _this4.closeDailyRoutineModal();
      yield _this4.workoutState.updateWorkoutData({
        todayWorkout: _this4.todayWorkout,
        bodyPart: _this4.selectedTab,
        dayIndex: _this4.selectedDay - 1
      });
      yield _this4.workoutState.updateWorkoutData({
        bodyPart: _this4.selectedTab
      });
      yield loading.dismiss();
      yield _this4.router.navigateByUrl('/full-workout-flow', {
        replaceUrl: true
      });
    })();
  }

};

Tab2Page.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController
}, {
  type: _services_workout_data_service__WEBPACK_IMPORTED_MODULE_3__.WorkoutDataService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router
}, {
  type: _services_workout_state_service__WEBPACK_IMPORTED_MODULE_4__.WorkoutStateService
}];

Tab2Page = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-tab2',
  template: _tab2_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_tab2_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], Tab2Page);


/***/ }),

/***/ 1597:
/*!************************************************!*\
  !*** ./src/app/tab2/tab2.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = ".title {\n  display: block;\n  text-align: center;\n  padding-top: 2rem;\n  font-size: 30px;\n  font-family: Teko-Medium;\n  text-transform: uppercase;\n}\n\n.modal-title {\n  display: block;\n  text-align: center;\n  padding-top: 2rem;\n  font-size: 35px;\n  color: #005b74;\n  font-family: Teko-Bold;\n  text-transform: uppercase;\n}\n\n.modal-subtitle {\n  display: block;\n  text-align: center;\n  font-size: 20px;\n  color: #454545;\n  padding-top: 2rem;\n  margin-left: 0.5rem;\n  font-family: Teko-Semibold;\n  text-transform: uppercase;\n}\n\n.subtitle {\n  display: block;\n  text-align: center;\n  font-size: 14px;\n  margin-top: -0.1rem;\n  font-family: RobotoCondensed-Light;\n  text-transform: capitalize;\n}\n\n.cards {\n  height: calc(100% - 56px - 63px);\n}\n\n.back-icon {\n  font-size: 40px;\n  margin-left: 1rem;\n  margin-top: 1rem;\n  position: fixed;\n  color: #444;\n  z-index: 1000;\n}\n\n.workout-card {\n  height: 25%;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  font-size: 40px;\n  text-transform: uppercase;\n  font-family: Teko-Light;\n  color: #efefef;\n}\n\n.workout-card span {\n  z-index: 2;\n}\n\n.background-mask {\n  width: 100%;\n  height: 100%;\n  background-color: #000;\n  position: absolute;\n  opacity: 0.5;\n}\n\nion-card#legs {\n  --background: url(/assets/images/legs.jpg) no-repeat center/100%;\n}\n\nion-card#abs {\n  --background: url(/assets/images/abs.jpg) no-repeat center/100%;\n}\n\nion-card#arms {\n  --background: url(/assets/images/arms.jpg) no-repeat center/100%;\n}\n\nion-card#chest {\n  --background: url(/assets/images/chest.jpg) no-repeat center/100%;\n}\n\n.header {\n  height: 10rem;\n}\n\n.header#legs {\n  background: url(/assets/images/legs.jpg) no-repeat center/100%;\n}\n\n.header#abs {\n  background: url(/assets/images/abs.jpg) no-repeat center/100%;\n}\n\n.header#arms {\n  background: url(/assets/images/arms.jpg) no-repeat center/100%;\n}\n\n.header#chest {\n  background: url(/assets/images/chest.jpg) no-repeat center/100%;\n}\n\n.day-card {\n  background-color: #e0e0e0;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  height: 3rem;\n  padding: 1rem;\n  border-radius: 1rem;\n  margin: 0.2rem;\n}\n\n.day-card .day-number {\n  font-size: 16px;\n}\n\n.day-card .workout-duration {\n  font-size: 12px;\n}\n\n.day-card-completed {\n  background-color: #005b74;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  height: 3rem;\n  padding: 1rem;\n  border-radius: 1rem;\n  margin: 0.2rem;\n}\n\n.day-card-completed .icon {\n  font-size: 26px;\n  color: white;\n}\n\nion-list {\n  overflow-y: scroll;\n  background-color: #efefef;\n  height: calc(100vh - 18.5rem);\n  background-color: transparent !important;\n}\n\n#select-day-modal ion-card {\n  color: #000;\n  box-shadow: none !important;\n}\n\n#workout-summary-modal ion-card {\n  display: flex;\n  align-items: center;\n}\n\n#workout-summary-modal .info {\n  margin-left: 6rem;\n}\n\n#workout-summary-modal .info .exercise-title,\n#workout-summary-modal .info .exercise-reps {\n  font-family: Roboto-Bold;\n  font-size: 16px;\n  text-transform: uppercase;\n}\n\n.gif-image {\n  width: 8rem;\n  height: 6rem;\n}\n\n.start-workout-button {\n  position: fixed;\n  bottom: 2rem;\n  left: 50%;\n  transform: translate(-50%);\n  width: 70%;\n  height: 2.5rem;\n  font-family: RobotoCondensed-Regular;\n  font-size: 16px;\n  --border-radius: 1rem;\n  text-transform: capitalize;\n  z-index: 4;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhYjIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0Esd0JBQUE7RUFDQSx5QkFBQTtBQUNGOztBQUVBO0VBQ0UsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLHNCQUFBO0VBQ0EseUJBQUE7QUFDRjs7QUFFQTtFQUNFLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLDBCQUFBO0VBQ0EseUJBQUE7QUFDRjs7QUFFQTtFQUNFLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGtDQUFBO0VBQ0EsMEJBQUE7QUFDRjs7QUFFQTtFQUNFLGdDQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtBQUNGOztBQUVBO0VBQ0UsV0FBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLHlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxjQUFBO0FBQ0Y7O0FBQ0U7RUFDRSxVQUFBO0FBQ0o7O0FBR0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FBQUY7O0FBSUU7RUFDRSxnRUFBQTtBQURKOztBQUdFO0VBQ0UsK0RBQUE7QUFESjs7QUFHRTtFQUNFLGdFQUFBO0FBREo7O0FBR0U7RUFDRSxpRUFBQTtBQURKOztBQUtBO0VBQ0UsYUFBQTtBQUZGOztBQUdFO0VBQ0UsOERBQUE7QUFESjs7QUFHRTtFQUNFLDZEQUFBO0FBREo7O0FBR0U7RUFDRSw4REFBQTtBQURKOztBQUdFO0VBQ0UsK0RBQUE7QUFESjs7QUFLQTtFQUNFLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtBQUZGOztBQUdFO0VBQ0UsZUFBQTtBQURKOztBQUlFO0VBQ0UsZUFBQTtBQUZKOztBQU1BO0VBQ0UseUJBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0FBSEY7O0FBSUU7RUFDRSxlQUFBO0VBQ0EsWUFBQTtBQUZKOztBQU1BO0VBQ0Usa0JBQUE7RUFDQSx5QkFBQTtFQUNBLDZCQUFBO0VBQ0Esd0NBQUE7QUFIRjs7QUFPRTtFQUNFLFdBQUE7RUFDQSwyQkFBQTtBQUpKOztBQVNFO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0FBTko7O0FBU0U7RUFDRSxpQkFBQTtBQVBKOztBQVFJOztFQUVFLHdCQUFBO0VBQ0EsZUFBQTtFQUNBLHlCQUFBO0FBTk47O0FBV0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtBQVJGOztBQVdBO0VBQ0UsZUFBQTtFQUNBLFlBQUE7RUFDQSxTQUFBO0VBQ0EsMEJBQUE7RUFDQSxVQUFBO0VBQ0EsY0FBQTtFQUNBLG9DQUFBO0VBQ0EsZUFBQTtFQUNBLHFCQUFBO0VBQ0EsMEJBQUE7RUFDQSxVQUFBO0FBUkYiLCJmaWxlIjoidGFiMi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudGl0bGUge1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBwYWRkaW5nLXRvcDogMnJlbTtcclxuICBmb250LXNpemU6IDMwcHg7XHJcbiAgZm9udC1mYW1pbHk6IFRla28tTWVkaXVtO1xyXG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbn1cclxuXHJcbi5tb2RhbC10aXRsZSB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIHBhZGRpbmctdG9wOiAycmVtO1xyXG4gIGZvbnQtc2l6ZTogMzVweDtcclxuICBjb2xvcjogIzAwNWI3NDtcclxuICBmb250LWZhbWlseTogVGVrby1Cb2xkO1xyXG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbn1cclxuXHJcbi5tb2RhbC1zdWJ0aXRsZSB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxuICBjb2xvcjogIzQ1NDU0NTtcclxuICBwYWRkaW5nLXRvcDogMnJlbTtcclxuICBtYXJnaW4tbGVmdDogMC41cmVtO1xyXG4gIGZvbnQtZmFtaWx5OiBUZWtvLVNlbWlib2xkO1xyXG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbn1cclxuXHJcbi5zdWJ0aXRsZSB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxuICBtYXJnaW4tdG9wOiAtMC4xcmVtO1xyXG4gIGZvbnQtZmFtaWx5OiBSb2JvdG9Db25kZW5zZWQtTGlnaHQ7XHJcbiAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XHJcbn1cclxuXHJcbi5jYXJkcyB7XHJcbiAgaGVpZ2h0OiBjYWxjKDEwMCUgLSA1NnB4IC0gNjNweCk7XHJcbn1cclxuXHJcbi5iYWNrLWljb24ge1xyXG4gIGZvbnQtc2l6ZTogNDBweDtcclxuICBtYXJnaW4tbGVmdDogMXJlbTtcclxuICBtYXJnaW4tdG9wOiAxcmVtO1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICBjb2xvcjogIzQ0NDtcclxuICB6LWluZGV4OiAxMDAwO1xyXG59XHJcblxyXG4ud29ya291dC1jYXJkIHtcclxuICBoZWlnaHQ6IDI1JTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZm9udC1zaXplOiA0MHB4O1xyXG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgZm9udC1mYW1pbHk6IFRla28tTGlnaHQ7XHJcbiAgY29sb3I6ICNlZmVmZWY7XHJcblxyXG4gICYgc3BhbiB7XHJcbiAgICB6LWluZGV4OiAyO1xyXG4gIH1cclxufVxyXG5cclxuLmJhY2tncm91bmQtbWFzayB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMwMDA7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIG9wYWNpdHk6IDAuNTtcclxufVxyXG5cclxuaW9uLWNhcmQge1xyXG4gICYjbGVncyB7XHJcbiAgICAtLWJhY2tncm91bmQ6IHVybCgvYXNzZXRzL2ltYWdlcy9sZWdzLmpwZykgbm8tcmVwZWF0IGNlbnRlci8xMDAlO1xyXG4gIH1cclxuICAmI2FicyB7XHJcbiAgICAtLWJhY2tncm91bmQ6IHVybCgvYXNzZXRzL2ltYWdlcy9hYnMuanBnKSBuby1yZXBlYXQgY2VudGVyLzEwMCU7XHJcbiAgfVxyXG4gICYjYXJtcyB7XHJcbiAgICAtLWJhY2tncm91bmQ6IHVybCgvYXNzZXRzL2ltYWdlcy9hcm1zLmpwZykgbm8tcmVwZWF0IGNlbnRlci8xMDAlO1xyXG4gIH1cclxuICAmI2NoZXN0IHtcclxuICAgIC0tYmFja2dyb3VuZDogdXJsKC9hc3NldHMvaW1hZ2VzL2NoZXN0LmpwZykgbm8tcmVwZWF0IGNlbnRlci8xMDAlO1xyXG4gIH1cclxufVxyXG5cclxuLmhlYWRlciB7XHJcbiAgaGVpZ2h0OiAxMHJlbTtcclxuICAmI2xlZ3Mge1xyXG4gICAgYmFja2dyb3VuZDogdXJsKC9hc3NldHMvaW1hZ2VzL2xlZ3MuanBnKSBuby1yZXBlYXQgY2VudGVyLzEwMCU7XHJcbiAgfVxyXG4gICYjYWJzIHtcclxuICAgIGJhY2tncm91bmQ6IHVybCgvYXNzZXRzL2ltYWdlcy9hYnMuanBnKSBuby1yZXBlYXQgY2VudGVyLzEwMCU7XHJcbiAgfVxyXG4gICYjYXJtcyB7XHJcbiAgICBiYWNrZ3JvdW5kOiB1cmwoL2Fzc2V0cy9pbWFnZXMvYXJtcy5qcGcpIG5vLXJlcGVhdCBjZW50ZXIvMTAwJTtcclxuICB9XHJcbiAgJiNjaGVzdCB7XHJcbiAgICBiYWNrZ3JvdW5kOiB1cmwoL2Fzc2V0cy9pbWFnZXMvY2hlc3QuanBnKSBuby1yZXBlYXQgY2VudGVyLzEwMCU7XHJcbiAgfVxyXG59XHJcblxyXG4uZGF5LWNhcmQge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNlMGUwZTA7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBoZWlnaHQ6IDNyZW07XHJcbiAgcGFkZGluZzogMXJlbTtcclxuICBib3JkZXItcmFkaXVzOiAxcmVtO1xyXG4gIG1hcmdpbjogMC4ycmVtO1xyXG4gICYgLmRheS1udW1iZXIge1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gIH1cclxuXHJcbiAgJiAud29ya291dC1kdXJhdGlvbiB7XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbiAgfVxyXG59XHJcblxyXG4uZGF5LWNhcmQtY29tcGxldGVkIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDA1Yjc0O1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBoZWlnaHQ6IDNyZW07XHJcbiAgcGFkZGluZzogMXJlbTtcclxuICBib3JkZXItcmFkaXVzOiAxcmVtO1xyXG4gIG1hcmdpbjogMC4ycmVtO1xyXG4gICYgLmljb24ge1xyXG4gICAgZm9udC1zaXplOiAyNnB4O1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gIH1cclxufVxyXG5cclxuaW9uLWxpc3Qge1xyXG4gIG92ZXJmbG93LXk6IHNjcm9sbDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWZlZmVmO1xyXG4gIGhlaWdodDogY2FsYygxMDB2aCAtIDE4LjVyZW0pO1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbiNzZWxlY3QtZGF5LW1vZGFsIHtcclxuICAmIGlvbi1jYXJkIHtcclxuICAgIGNvbG9yOiAjMDAwO1xyXG4gICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xyXG4gIH1cclxufVxyXG5cclxuI3dvcmtvdXQtc3VtbWFyeS1tb2RhbCB7XHJcbiAgJiBpb24tY2FyZCB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICB9XHJcblxyXG4gIC5pbmZvIHtcclxuICAgIG1hcmdpbi1sZWZ0OiA2cmVtO1xyXG4gICAgJiAuZXhlcmNpc2UtdGl0bGUsXHJcbiAgICAuZXhlcmNpc2UtcmVwcyB7XHJcbiAgICAgIGZvbnQtZmFtaWx5OiBSb2JvdG8tQm9sZDtcclxuICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuLmdpZi1pbWFnZSB7XHJcbiAgd2lkdGg6IDhyZW07XHJcbiAgaGVpZ2h0OiA2cmVtO1xyXG59XHJcblxyXG4uc3RhcnQtd29ya291dC1idXR0b24ge1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICBib3R0b206IDJyZW07XHJcbiAgbGVmdDogNTAlO1xyXG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUpO1xyXG4gIHdpZHRoOiA3MCU7XHJcbiAgaGVpZ2h0OiAyLjVyZW07XHJcbiAgZm9udC1mYW1pbHk6IFJvYm90b0NvbmRlbnNlZC1SZWd1bGFyO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICAtLWJvcmRlci1yYWRpdXM6IDFyZW07XHJcbiAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XHJcbiAgei1pbmRleDogNDtcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 1748:
/*!************************************************!*\
  !*** ./src/app/tab2/tab2.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-content [fullscreen]=\"true\">\n  <!-- workout page -->\n  <!-- <span class=\"title\">Select custom workout for today</span> -->\n  <span class=\"title\">Proba proba</span>\n\n  <div class=\"cards\">\n    <!-- legs card -->\n    <ion-card class=\"workout-card\" id=\"legs\" (click)=\"openModal('legs')\">\n      <span>Legs</span>\n      <div class=\"background-mask\"></div>\n    </ion-card>\n\n    <!-- abs card -->\n    <ion-card class=\"workout-card\" id=\"abs\" (click)=\"openModal('abs')\">\n      <span>Abs</span>\n      <div class=\"background-mask\"></div>\n    </ion-card>\n\n    <!-- arms card -->\n    <ion-card class=\"workout-card\" id=\"arms\" (click)=\"openModal('arms')\">\n      <span>Arms</span>\n      <div class=\"background-mask\"></div>\n    </ion-card>\n\n    <!-- chest card -->\n    <ion-card class=\"workout-card\" id=\"chest\" (click)=\"openModal('chest')\">\n      <span>Chest</span>\n      <div class=\"background-mask\"></div>\n    </ion-card>\n  </div>\n\n  <!-- Modal -->\n  <ion-modal id=\"select-day-modal\" [isOpen]=\"isModalOpen\">\n    <ng-template>\n      <ion-content [fullscreen]=\"true\">\n        <ion-icon\n          name=\"arrow-back-outline\"\n          class=\"back-icon\"\n          (click)=\"closeSelectDayModal()\"\n        ></ion-icon>\n        <div class=\"header\" [id]=\"selectedTab\"></div>\n        <span class=\"modal-title\">{{displayedTitle}}</span>\n        <span class=\"subtitle\">Full progressive Workout</span>\n        <ion-card>\n          <ion-list>\n            <ion-row>\n              <ng-container *ngFor=\"let i of numberOfDays\">\n                <ion-col size=\"6\">\n                  <div\n                    [class]=\"dailyWorkouts[selectedTab][i-1].completed ? 'day-card-completed' : 'day-card'\"\n                  >\n                    <ng-container\n                      *ngIf=\"!dailyWorkouts[selectedTab][i-1].completed\"\n                    >\n                      <span\n                        class=\"day-number\"\n                        (click)=\"openDailyRoutineModal(i)\"\n                        >Day {{i}}</span\n                      >\n                      <div style=\"display: flex; align-items: center\">\n                        <ion-icon name=\"time-outline\"></ion-icon>\n                        <span class=\"workout-duration\">11 min</span>\n                      </div>\n                    </ng-container>\n\n                    <ng-container\n                      *ngIf=\"dailyWorkouts[selectedTab][i-1].completed\"\n                    >\n                      <ion-icon\n                        class=\"icon\"\n                        name=\"checkmark-circle-outline\"\n                      ></ion-icon>\n                    </ng-container>\n                  </div>\n                </ion-col>\n              </ng-container>\n            </ion-row>\n          </ion-list>\n        </ion-card>\n      </ion-content>\n    </ng-template>\n  </ion-modal>\n\n  <ion-modal id=\"workout-summary-modal\" [isOpen]=\"isDailyRoutineSummaryOpen\">\n    <ng-template>\n      <ion-content\n        style=\"\n          --background: #efefef !important;\n          --padding-bottom: 6rem !important;\n        \"\n      >\n        <ion-icon\n          name=\"arrow-back-outline\"\n          class=\"back-icon\"\n          (click)=\"closeDailyRoutineModal()\"\n        ></ion-icon>\n        <div class=\"header\" [id]=\"selectedTab\"></div>\n        <div\n          style=\"display: flex; justify-content: center; align-items: center\"\n        >\n          <span class=\"modal-title\">{{displayedTitle}}</span>\n          <span class=\"modal-subtitle\">{{' - Day ' + selectedDay}}</span>\n        </div>\n        <p class=\"subtitle\">\n          {{todayWorkout.length + ' excercises - Estimated time: ' +\n          workoutEstimatedTime + ' min'}}\n        </p>\n        <ng-container *ngFor=\"let exercise of todayWorkout\">\n          <ion-card>\n            <img\n              class=\"gif-image\"\n              [src]=\"'/assets/gifs/'+ selectedTab + '/' + exercise.gif\"\n              alt=\"\"\n            />\n            <div class=\"info\">\n              <p class=\"exercise-title\">{{exercise.name}}</p>\n              <p class=\"exercise-reps\">x{{exercise.totalReps}}</p>\n            </div>\n          </ion-card>\n        </ng-container>\n        <ion-button\n          class=\"start-workout-button\"\n          color=\"primary\"\n          (click)=\"startFullWorkoutFlow()\"\n          >Start</ion-button\n        >\n      </ion-content>\n    </ng-template>\n  </ion-modal>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab2_tab2_module_ts.js.map