"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab3_tab3_module_ts"],{

/***/ 9818:
/*!*********************************************!*\
  !*** ./src/app/tab3/tab3-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab3PageRoutingModule": () => (/* binding */ Tab3PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _tab3_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab3.page */ 8592);




const routes = [
    {
        path: '',
        component: _tab3_page__WEBPACK_IMPORTED_MODULE_0__.Tab3Page,
    }
];
let Tab3PageRoutingModule = class Tab3PageRoutingModule {
};
Tab3PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], Tab3PageRoutingModule);



/***/ }),

/***/ 3746:
/*!*************************************!*\
  !*** ./src/app/tab3/tab3.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab3PageModule": () => (/* binding */ Tab3PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _tab3_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab3.page */ 8592);
/* harmony import */ var _tab3_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab3-routing.module */ 9818);
/* harmony import */ var ng2_search_filter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ng2-search-filter */ 9991);









let Tab3PageModule = class Tab3PageModule {
};
Tab3PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _angular_router__WEBPACK_IMPORTED_MODULE_8__.RouterModule.forChild([{ path: '', component: _tab3_page__WEBPACK_IMPORTED_MODULE_0__.Tab3Page }]),
            _tab3_routing_module__WEBPACK_IMPORTED_MODULE_1__.Tab3PageRoutingModule,
            ng2_search_filter__WEBPACK_IMPORTED_MODULE_2__.Ng2SearchPipeModule,
        ],
        declarations: [_tab3_page__WEBPACK_IMPORTED_MODULE_0__.Tab3Page],
    })
], Tab3PageModule);



/***/ }),

/***/ 8592:
/*!***********************************!*\
  !*** ./src/app/tab3/tab3.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab3Page": () => (/* binding */ Tab3Page)
/* harmony export */ });
/* harmony import */ var D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _tab3_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab3.page.html?ngResource */ 9769);
/* harmony import */ var _tab3_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tab3.page.scss?ngResource */ 7087);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_food_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/food.service */ 9785);







let Tab3Page = class Tab3Page {
  constructor(loadingController, alertController, foodService) {
    this.loadingController = loadingController;
    this.alertController = alertController;
    this.foodService = foodService;
    this.isFoodModalOpen = false;
    this.isBeveragesModalOpen = false;
    this.isSnacksModalOpen = false;
    this.searchKeyword = null;
    this.foodList = null;
    this.beveragesList = null;
    this.snackList = null;
  }

  ngOnInit() {
    this.loadAllData();
  }

  loadAllData() {
    var _this = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const loading = yield _this.loadingController.create({
        showBackdrop: false,
        cssClass: 'custom-loading'
      });
      yield loading.present();
      yield _this.getFoodList();
      yield _this.getBeveragesList();
      yield _this.getSnackList();
      yield loading.dismiss();
    })();
  }

  setFoodModalOpen(isOpen) {
    this.isFoodModalOpen = isOpen;
  }

  setBeveragesModalOpen(isOpen) {
    this.isBeveragesModalOpen = isOpen;
  }

  setSnacksModalOpen(isOpen) {
    this.isSnacksModalOpen = isOpen;
  }

  getFoodList() {
    var _this2 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.foodList = yield _this2.foodService.getFoodList();
    })();
  }

  getBeveragesList() {
    var _this3 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.beveragesList = yield _this3.foodService.getBeveragesList();
    })();
  }

  getSnackList() {
    var _this4 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this4.snackList = yield _this4.foodService.getSnackList();
    })();
  }

  addMeal(item) {
    let itemValues = {
      kcal: parseFloat(item.kcal) * (item.inputData / 100),
      carbs: parseFloat(item.carbs) * (item.inputData / 100),
      protein: parseFloat(item.protein) * (item.inputData / 100),
      fats: parseFloat(item.fats) * (item.inputData / 100),
      inputData: item.inputData,
      name: item.name
    };
    this.foodService.addMeal(itemValues);
  }

  addItemToTheList(type, inputData) {
    console.log(type, inputData);
    this.foodService.addNewItemToList(type, inputData);
  }

  enterQuantityAlert(item) {
    var _this5 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this5.alertController.create({
        header: item.name,
        message: 'Enter quantity',
        buttons: [{
          text: 'Add meal',
          role: 'confirm',
          handler: inputData => _this5.addMeal({ ...item,
            inputData: parseInt(inputData[0])
          })
        }],
        inputs: [{
          type: 'number',
          placeholder: 'e.g 120g',
          min: 1,
          max: 9999
        }],
        cssClass: 'alert-input',
        animated: true
      });
      yield alert.present();
    })();
  }

  addItemAlert(type) {
    var _this6 = this;

    return (0,D_MyPersonalTrainer_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this6.alertController.create({
        header: 'New item',
        message: "Enter new item's information",
        buttons: [{
          text: 'Add item',
          role: 'confirm',
          handler: inputData => _this6.addItemToTheList(type, {
            name: parseInt(inputData[0]),
            kcal: parseInt(inputData[1]),
            protein: parseInt(inputData[2]),
            carbs: parseInt(inputData[3]),
            fats: parseInt(inputData[4])
          })
        }],
        inputs: [{
          type: 'text',
          placeholder: 'Name'
        }, {
          type: 'number',
          placeholder: 'Calories per 100g',
          min: 1,
          max: 9999
        }, {
          type: 'number',
          placeholder: 'Protein per 100g',
          min: 1,
          max: 9999
        }, {
          type: 'number',
          placeholder: 'Carbohydrates per 100g',
          min: 1,
          max: 9999
        }, {
          type: 'number',
          placeholder: 'Fats per 100g',
          min: 1,
          max: 9999
        }],
        cssClass: 'alert-input',
        animated: true
      });
      yield alert.present();
    })();
  }

};

Tab3Page.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.LoadingController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AlertController
}, {
  type: _services_food_service__WEBPACK_IMPORTED_MODULE_3__.FoodService
}];

Tab3Page.propDecorators = {
  modal: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ViewChild,
    args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonModal]
  }]
};
Tab3Page = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
  selector: 'app-tab3',
  template: _tab3_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_tab3_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], Tab3Page);


/***/ }),

/***/ 7087:
/*!************************************************!*\
  !*** ./src/app/tab3/tab3.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = ".title {\n  display: block;\n  text-align: center;\n  padding-top: 2rem;\n  font-size: 30px;\n  font-family: Teko-Medium;\n  text-transform: uppercase;\n}\n\n.cards {\n  height: calc(100% - 56px - 63px);\n}\n\n.food-category {\n  height: 33%;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  font-size: 40px;\n  text-transform: uppercase;\n  font-family: Teko-Light;\n  color: #efefef;\n}\n\n.food-category span {\n  z-index: 2;\n}\n\n.background-mask {\n  width: 100%;\n  height: 100%;\n  background-color: #000;\n  position: absolute;\n  opacity: 0.5;\n}\n\nion-content {\n  --ion-background-color: #cee0e5 !important;\n  height: 100vh;\n}\n\nion-card#food {\n  --background: url(/assets/images/food.jpg) no-repeat center/100%;\n}\n\nion-card#beverages {\n  --background: url(/assets/images/beverages.jpg) no-repeat center/100%;\n}\n\nion-card#snacks {\n  --background: url(/assets/images/snacks.jpg) no-repeat center/100%;\n}\n\n.sc-ion-searchbar-md-h {\n  --background: #fff !important;\n  --border-radius: 0.8rem !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhYjMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0Esd0JBQUE7RUFDQSx5QkFBQTtBQUNGOztBQUVBO0VBQ0UsZ0NBQUE7QUFDRjs7QUFFQTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSx5QkFBQTtFQUNBLHVCQUFBO0VBQ0EsY0FBQTtBQUNGOztBQUNFO0VBQ0UsVUFBQTtBQUNKOztBQUdBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtBQUFGOztBQUdBO0VBQ0UsMENBQUE7RUFDQSxhQUFBO0FBQUY7O0FBSUU7RUFDRSxnRUFBQTtBQURKOztBQUdFO0VBQ0UscUVBQUE7QUFESjs7QUFHRTtFQUNFLGtFQUFBO0FBREo7O0FBS0E7RUFDRSw2QkFBQTtFQUNBLGtDQUFBO0FBRkYiLCJmaWxlIjoidGFiMy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudGl0bGUge1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBwYWRkaW5nLXRvcDogMnJlbTtcclxuICBmb250LXNpemU6IDMwcHg7XHJcbiAgZm9udC1mYW1pbHk6IFRla28tTWVkaXVtO1xyXG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbn1cclxuXHJcbi5jYXJkcyB7XHJcbiAgaGVpZ2h0OiBjYWxjKDEwMCUgLSA1NnB4IC0gNjNweCk7XHJcbn1cclxuXHJcbi5mb29kLWNhdGVnb3J5IHtcclxuICBoZWlnaHQ6IDMzJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZm9udC1zaXplOiA0MHB4O1xyXG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgZm9udC1mYW1pbHk6IFRla28tTGlnaHQ7XHJcbiAgY29sb3I6ICNlZmVmZWY7XHJcblxyXG4gICYgc3BhbiB7XHJcbiAgICB6LWluZGV4OiAyO1xyXG4gIH1cclxufVxyXG5cclxuLmJhY2tncm91bmQtbWFzayB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMwMDA7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIG9wYWNpdHk6IDAuNTtcclxufVxyXG5cclxuaW9uLWNvbnRlbnQge1xyXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNjZWUwZTUgIWltcG9ydGFudDtcclxuICBoZWlnaHQ6IDEwMHZoO1xyXG59XHJcblxyXG5pb24tY2FyZCB7XHJcbiAgJiNmb29kIHtcclxuICAgIC0tYmFja2dyb3VuZDogdXJsKC9hc3NldHMvaW1hZ2VzL2Zvb2QuanBnKSBuby1yZXBlYXQgY2VudGVyLzEwMCU7XHJcbiAgfVxyXG4gICYjYmV2ZXJhZ2VzIHtcclxuICAgIC0tYmFja2dyb3VuZDogdXJsKC9hc3NldHMvaW1hZ2VzL2JldmVyYWdlcy5qcGcpIG5vLXJlcGVhdCBjZW50ZXIvMTAwJTtcclxuICB9XHJcbiAgJiNzbmFja3Mge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB1cmwoL2Fzc2V0cy9pbWFnZXMvc25hY2tzLmpwZykgbm8tcmVwZWF0IGNlbnRlci8xMDAlO1xyXG4gIH1cclxufVxyXG5cclxuLnNjLWlvbi1zZWFyY2hiYXItbWQtaCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjZmZmICFpbXBvcnRhbnQ7XHJcbiAgLS1ib3JkZXItcmFkaXVzOiAwLjhyZW0gIWltcG9ydGFudDtcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 9769:
/*!************************************************!*\
  !*** ./src/app/tab3/tab3.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <span class=\"title\">Choose a category</span>\n  <div class=\"cards\">\n    <ion-card class=\"food-category\" id=\"food\" (click)=\"setFoodModalOpen(true)\">\n      <span>Food</span>\n      <div class=\"background-mask\"></div>\n    </ion-card>\n    <ion-card\n      class=\"food-category\"\n      id=\"beverages\"\n      (click)=\"setBeveragesModalOpen(true)\"\n    >\n      <span>Beverages</span>\n      <div class=\"background-mask\"></div>\n    </ion-card>\n    <ion-card\n      class=\"food-category\"\n      id=\"snacks\"\n      (click)=\"setSnacksModalOpen(true)\"\n    >\n      <span>Snacks & Supplements</span>\n      <div class=\"background-mask\"></div>\n    </ion-card>\n  </div>\n\n  <!-- Food Modal -->\n  <ion-modal id=\"food-modal\" [isOpen]=\"isFoodModalOpen\">\n    <ng-template>\n      <ion-header>\n        <ion-toolbar>\n          <ion-title>Food List</ion-title>\n          <ion-buttons slot=\"end\">\n            <ion-button (click)=\"setFoodModalOpen(false)\">Done</ion-button>\n          </ion-buttons>\n        </ion-toolbar>\n      </ion-header>\n      <ion-content [fullscreen]=\"true\">\n        <ion-searchbar\n          placeholder=\"Try 'Oatmeal'\"\n          [(ngModel)]=\"searchKeyword\"\n          showCancelButton=\"focus\"\n          animated\n        ></ion-searchbar>\n\n        <div>\n          <ion-list>\n            <ng-container *ngIf=\"(foodList | filter:searchKeyword) as result\">\n              <ion-card\n                *ngFor=\"let item of result\"\n                (click)=\"enterQuantityAlert(item)\"\n                style=\"background-color: #efefef\"\n              >\n                <ion-card-header>\n                  <ion-card-title>{{ item.name }}</ion-card-title>\n                </ion-card-header>\n                <ion-card-content\n                  >{{ item.kcal + ' kcal/100g' }}</ion-card-content\n                >\n              </ion-card>\n              <ng-container *ngIf=\"result.length === 0\">\n                <span style=\"display: block; text-align: center\"\n                  >Didn't find what you're looking for?</span\n                >\n                <ion-button\n                  style=\"margin-left: 50%; transform: translate(-50%)\"\n                  (click)=\"addItemAlert('FOOD')\"\n                >\n                  Add new item to the list\n                </ion-button>\n              </ng-container>\n            </ng-container>\n          </ion-list>\n        </div>\n      </ion-content>\n    </ng-template>\n  </ion-modal>\n\n  <!-- Beverages Modal -->\n  <ion-modal id=\"beverages-modal\" [isOpen]=\"isBeveragesModalOpen\">\n    <ng-template>\n      <ion-header>\n        <ion-toolbar>\n          <ion-title>Beverages List</ion-title>\n          <ion-buttons slot=\"end\">\n            <ion-button (click)=\"setBeveragesModalOpen(false)\">Done</ion-button>\n          </ion-buttons>\n        </ion-toolbar>\n      </ion-header>\n      <ion-content [fullscreen]=\"true\">\n        <ion-searchbar\n          placeholder=\"Try 'Coca-Cola'\"\n          [(ngModel)]=\"searchKeyword\"\n          showCancelButton=\"focus\"\n          animated\n        ></ion-searchbar>\n\n        <div style=\"height: 100px !important\">\n          <ion-list>\n            <ng-container\n              *ngFor=\"let item of beveragesList | filter:searchKeyword\"\n            >\n              <ion-card\n                (click)=\"enterQuantityAlert(item)\"\n                style=\"background-color: #efefef\"\n              >\n                <ion-card-header>\n                  <ion-card-title>{{ item.name }}</ion-card-title>\n                </ion-card-header>\n                <ion-card-content\n                  >{{ item.kcal + ' kcal/100ml' }}</ion-card-content\n                >\n              </ion-card>\n            </ng-container>\n          </ion-list>\n        </div>\n      </ion-content>\n    </ng-template>\n  </ion-modal>\n\n  <!-- Snacks Modal -->\n  <ion-modal id=\"snacks-modal\" [isOpen]=\"isSnacksModalOpen\">\n    <ng-template>\n      <ion-header>\n        <ion-toolbar>\n          <ion-title>Snacks & Supplements List</ion-title>\n          <ion-buttons slot=\"end\">\n            <ion-button (click)=\"setSnacksModalOpen(false)\">Done</ion-button>\n          </ion-buttons>\n        </ion-toolbar>\n      </ion-header>\n      <ion-content [fullscreen]=\"true\">\n        <ion-searchbar\n          placeholder=\"Try 'Coca-Cola'\"\n          [(ngModel)]=\"searchKeyword\"\n          showCancelButton=\"focus\"\n          animated\n        ></ion-searchbar>\n\n        <div style=\"height: 100px !important\">\n          <ion-list>\n            <ng-container *ngIf=\"(snackList | filter:searchKeyword) as result\">\n              <ion-card\n                *ngFor=\"let item of result\"\n                (click)=\"enterQuantityAlert(item)\"\n                style=\"background-color: #efefef\"\n              >\n                <ion-card-header>\n                  <ion-card-title>{{ item.name }}</ion-card-title>\n                </ion-card-header>\n                <ion-card-content\n                  >{{ item.kcal + ' kcal/100g' }}</ion-card-content\n                >\n              </ion-card>\n              <ng-container *ngIf=\"result.length === 0\">\n                <span style=\"display: block; text-align: center\"\n                  >Didn't find what you're looking for?</span\n                >\n                <ion-button\n                  style=\"margin-left: 50%; transform: translate(-50%)\"\n                  (click)=\"addItemAlert('snacks-supplements')\"\n                >\n                  Add new item to the list\n                </ion-button>\n              </ng-container>\n            </ng-container>\n          </ion-list>\n        </div>\n      </ion-content>\n    </ng-template>\n  </ion-modal>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab3_tab3_module_ts.js.map